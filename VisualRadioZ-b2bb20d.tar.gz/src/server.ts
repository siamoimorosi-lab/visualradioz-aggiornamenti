import { Remote, makeLogin } from './remote.ts';
import type { Vote } from './vote.ts';
import { parseDays, parseHours } from './schedule.ts';
import { RULE_OPS, type Rule, cleanCategories } from './filters.ts';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { type Config, type SequenceRule, resolvePath, rootDir, saveQuality, saveRemote, saveSettings, saveVote } from './config.ts';
import { presetValues } from './audioproc.ts';
import { type Schedule, saveSchedule } from './schedule.ts';
import type { Engine } from './engine.ts';
import type { Library } from './library.ts';
import type { Scheduler } from './scheduler.ts';
import type { AsRunLog } from './asrun.ts';
import type { Ticker } from './ticker.ts';

const MIME: Record<string, string> = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.m3u8': 'application/vnd.apple.mpegurl',
  '.ts': 'video/mp2t',
  '.svg': 'image/svg+xml',
};

interface Ctx {
  cfg: Config;
  engine: Engine;
  lib: Library;
  sched: Scheduler;
  asrun: AsRunLog;
  ticker: Ticker;
  remote: Remote;
  vote: Vote;
}

function send(res: http.ServerResponse, code: number, body: unknown) {
  res.writeHead(code, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
  res.end(JSON.stringify(body));
}

function serveFile(res: http.ServerResponse, file: string, extraHeaders: Record<string, string> = {}) {
  fs.readFile(file, (err, data) => {
    if (err) return send(res, 404, { error: 'non trovato' });
    res.writeHead(200, { 'content-type': MIME[path.extname(file)] ?? 'application/octet-stream', ...extraHeaders });
    res.end(data);
  });
}

async function body(req: http.IncomingMessage): Promise<any> {
  let raw = '';
  for await (const chunk of req) {
    raw += chunk;
    if (raw.length > 1e6) throw new Error('richiesta troppo grande');
  }
  return raw ? JSON.parse(raw) : {};
}

/** Resolve `rel` inside `dir`, refusing anything that escapes it. */
function inside(dir: string, rel: string): string | null {
  const full = path.resolve(dir, '.' + path.sep + decodeURIComponent(rel));
  return full.startsWith(path.resolve(dir) + path.sep) ? full : null;
}

const ROTATION_LIMITS = {
  artistSeparation: [0, 50], artistSeparationMinutes: [0, 720], titleSeparationMinutes: [0, 1440], jingleEvery: [0, 20],
} as const;

/** Only the known rotation fields, as whole numbers within sensible limits. */
function settingsRotation(r: Record<string, unknown>): Partial<Config['rotation']> {
  const out: Record<string, any> = {};
  for (const [k, [lo, hi]] of Object.entries(ROTATION_LIMITS)) {
    if (r[k] === undefined) continue;
    const n = Math.round(Number(r[k]));
    if (!Number.isFinite(n) || n < lo || n > hi) throw new Error(`${k}: valore fuori dai limiti (${lo}–${hi})`);
    out[k] = n;
  }
  if (r.backups !== undefined) {
    out.backups = (Array.isArray(r.backups) ? r.backups : [])
      .map((x: any) => ({ category: String(x?.category ?? '').trim(), backup: String(x?.backup ?? '').trim() }))
      .filter((x: { category: string; backup: string }) => x.category && x.backup && x.category !== x.backup);
  }
  if (r.sequence !== undefined) {
    out.sequence = (Array.isArray(r.sequence) ? r.sequence : [])
      .map((x: any) => ({ field: String(x?.field ?? '').trim(), value: String(x?.value ?? '').trim(), max: Math.round(Number(x?.max ?? 1)) }))
      .filter((x: SequenceRule) => x.field)
      .map((x: SequenceRule) => {
        if (!Number.isFinite(x.max) || x.max < 1 || x.max > 10) throw new Error(`regola di sequenza "${x.field}": di fila da 1 a 10`);
        return x;
      });
  }
  return out;
}

/** Rules from the panel (field, op, value), the empty ones dropped. */
function cleanRules(input: unknown, where: string): Rule[] {
  const rules = (Array.isArray(input) ? input : [])
    .map((r: any) => ({ field: String(r?.field ?? '').trim(), op: r?.op, value: String(r?.value ?? '').trim() }))
    .filter((r: Rule) => r.field && r.value);
  if (rules.some((r) => !RULE_OPS.includes(r.op))) throw new Error(`${where}: regola non valida`);
  return rules;
}

/** A number within limits, or a 400 with the field name. */
function num(v: unknown, name: string, lo: number, hi: number): number {
  const n = Number(v);
  if (!Number.isFinite(n) || n < lo || n > hi) throw new Error(`${name}: valore fuori dai limiti (${lo}–${hi})`);
  return n;
}

/** The Quality page form, checked field by field. */
function qualitySettings(b: any) {
  const v = b.video ?? {};
  const a = b.audio ?? {};
  const t = a.tuning ?? {};
  const pick = <T extends string>(x: unknown, allowed: readonly T[], name: string): T => {
    if (!allowed.includes(x as T)) throw new Error(`${name}: valore non valido`);
    return x as T;
  };
  const opt = (x: unknown, name: string, lo: number, hi: number) => (x === null || x === undefined ? null : num(x, name, lo, hi));
  return {
    video: {
      enhance: v.enhance ? ('light' as const) : ('off' as const),
      contrast: num(v.contrast, 'contrasto', 0.9, 1.25),
      saturation: num(v.saturation, 'saturazione', 0.7, 1.5),
      sharpness: num(v.sharpness, 'nitidezza', 0, 1.2),
      cleanup: pick(v.cleanup, ['off', 'light', 'strong'] as const, 'pulizia'),
      fillZoom: num(v.fillZoom, 'zoom bande', 1, 1.25),
    },
    audio: {
      processing: pick(a.processing, ['off', 'light', 'radio', 'loud'] as const, 'processore'),
      tuning: {
        loudness: opt(t.loudness, 'volume', -18, -8),
        compression: opt(t.compression, 'compressione', 0.5, 1.5),
        bassDb: opt(t.bassDb, 'bassi', 0, 8),
        airDb: opt(t.airDb, 'brillantezza', 0, 8),
      },
    },
    videoBitrate: `${Math.round(num(b.videoBitrate, 'bitrate', 3000, 9000))}k`,
  };
}

/** How often weather and traffic come back, in minutes (0 = on every music clip). */
function settingsCards(c: Record<string, unknown>) {
  const out: { weatherEveryMinutes?: number; trafficEveryMinutes?: number } = {};
  for (const k of ['weatherEveryMinutes', 'trafficEveryMinutes'] as const) {
    if (c[k] === undefined) continue;
    const n = Math.round(Number(c[k]));
    if (!Number.isFinite(n) || n < 0 || n > 240) throw new Error(`${k}: valore fuori dai limiti (0–240)`);
    out[k] = n;
  }
  return out;
}

/** Clocks, grid and default clock from the settings page; breaks are kept as they are in schedule.json. */
function settingsSchedule(s: any, current: Schedule): Schedule {
  if (!s || typeof s !== 'object') throw new Error('palinsesto mancante');
  const clocks: Schedule['clocks'] = {};
  for (const [name, c] of Object.entries<any>(s.clocks ?? {})) {
    const slots = (Array.isArray(c?.slots) ? c.slots : []).map((x: unknown) => String(x).trim()).filter(Boolean);
    if (!name.trim() || !slots.length) throw new Error(`l'orologio "${name}" non ha slot`);
    const exclude = cleanRules(c.exclude, `orologio "${name}"`);
    clocks[name.trim()] = { slots, ...(c.continuous ? { continuous: true } : {}), ...(exclude.length ? { exclude } : {}), ...(exclude.length && c.excludeMatch === 'all' ? { excludeMatch: 'all' as const } : {}) };
  }
  const grid = (Array.isArray(s.grid) ? s.grid : []).map((g: any) => ({ days: String(g.days || '*'), hours: String(g.hours || '*'), clock: String(g.clock) }));
  return { clocks, grid, defaultClock: String(s.defaultClock), breaks: current.breaks };
}

/** Resolves once the panel listens; rejects if the port is taken (e.g. the program is already running). */
export function startServer(ctx: Ctx): Promise<http.Server> {
  const { cfg, engine, lib, sched, asrun, ticker, remote, vote } = ctx;
  const publicDir = path.join(rootDir, 'public');
  const previewDir = path.join(resolvePath(cfg.dataDir), 'preview');

  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url ?? '/', 'http://localhost');
    const p = url.pathname;
    if (cfg.server.token) {
      const given = url.searchParams.get('token') ?? req.headers['x-token'];
      if (given !== cfg.server.token) return send(res, 401, { error: 'token mancante o errato' });
    }
    try {
      if (req.method === 'GET' && !p.startsWith('/api/') && !p.startsWith('/preview/')) {
        const f = inside(publicDir, p === '/' ? 'index.html' : p);
        // The panel changes with the program: always check for the current version.
        return f ? serveFile(res, f, { 'cache-control': 'no-cache' }) : send(res, 404, {});
      }
      if (p.startsWith('/preview/')) {
        const f = inside(previewDir, p.slice('/preview/'.length));
        return f ? serveFile(res, f, { 'cache-control': 'no-store' }) : send(res, 404, {});
      }

      if (p === '/api/status') return send(res, 200, engine.status());
      if (p === '/api/events') {
        res.writeHead(200, { 'content-type': 'text/event-stream', 'cache-control': 'no-store', connection: 'keep-alive' });
        const push = () => res.write(`data: ${JSON.stringify(engine.status())}\n\n`);
        push();
        const timer = setInterval(push, 1000);
        engine.on('status', push);
        req.on('close', () => {
          clearInterval(timer);
          engine.off('status', push);
        });
        return;
      }
      if (p === '/api/library') {
        return send(res, 200, lib.list().map((c) => ({
          id: c.id, type: c.type, artist: c.artist, title: c.title, duration: c.cueOut - c.cueIn,
          width: c.width, height: c.height, lufs: c.lufs, category: c.category,
          probed: c.probed, analyzed: c.analyzed, error: c.error ?? c.damaged ?? null, silentTail: c.silentTail ?? null,
          file: path.basename(c.file),
        })));
      }
      if (p === '/api/rescan' && req.method === 'POST') {
        lib.scan().catch((e) => console.error(e));
        return send(res, 202, { ok: true });
      }
      if (p === '/api/onair' && req.method === 'POST') {
        const on = !!(await body(req)).on;
        await (on ? engine.start() : engine.stop());
        engine.emit('status');
        return send(res, 200, { running: engine.running });
      }
      if (p === '/api/quit' && req.method === 'POST') {
        send(res, 200, { ok: true });
        // Closed on purpose: the watchdog must not start it again (the desktop icon does).
        fs.writeFileSync(path.join(resolvePath(cfg.dataDir), 'closed-by-user'), new Date().toISOString());
        await engine.stop();
        console.log('programma chiuso dal pannello');
        setTimeout(() => process.exit(0), 300);
        return;
      }
      if (p === '/api/skip' && req.method === 'POST') {
        engine.skip();
        return send(res, 200, { ok: true });
      }
      if (p === '/api/playnow' && req.method === 'POST') {
        const b = await body(req);
        engine.playNow(String(b.id), {
          uid: b.uid === undefined ? undefined : Number(b.uid),
          queueIndex: b.queueIndex === undefined ? undefined : Number(b.queueIndex),
        });
        return send(res, 200, { ok: true });
      }
      if (p === '/api/queue' && req.method === 'POST') {
        const b = await body(req);
        sched.enqueue(String(b.id), !!b.front);
        engine.emit('status');
        return send(res, 200, { ok: true });
      }
      if (p === '/api/queue/move' && req.method === 'POST') {
        const b = await body(req);
        sched.moveInQueue(Number(b.from), Number(b.to));
        engine.emit('status');
        return send(res, 200, { ok: true });
      }
      const qi = p.match(/^\/api\/queue\/(\d+)$/);
      if (qi && req.method === 'DELETE') {
        sched.removeFromQueue(Number(qi[1]));
        engine.emit('status');
        return send(res, 200, { ok: true });
      }
      if (p === '/api/cards/force' && req.method === 'POST') {
        const kind = String((await body(req)).kind);
        if (!['weatherToday', 'weatherWeek', 'traffic', 'headliner'].includes(kind)) return send(res, 400, { error: 'scheda sconosciuta' });
        return send(res, 200, { mode: engine.forceCard(kind as 'weatherToday' | 'weatherWeek' | 'traffic' | 'headliner') });
      }
      if (p === '/api/breaks/fire' && req.method === 'POST') {
        sched.fireNow(String((await body(req)).name));
        engine.emit('status');
        return send(res, 200, { ok: true });
      }
      if (p === '/api/ticker') {
        if (req.method === 'POST') {
          ticker.setManual(String((await body(req)).text ?? ''));
          return send(res, 200, { ok: true });
        }
        return send(res, 200, { ...ticker.status(), enabled: cfg.overlay.ticker.enabled });
      }
      if (p === '/api/playlist') {
        const v = engine.playlistView();
        // ?past=1&future=4: just around the clip on air (the sequencer under the preview).
        const past = url.searchParams.get('past');
        const future = url.searchParams.get('future');
        if (past !== null) v.past = v.past.slice(-Number(past) || v.past.length);
        if (future !== null) v.future = v.future.slice(0, Number(future));
        return send(res, 200, v);
      }
      if (p === '/api/playlist/regenerate' && req.method === 'POST') {
        sched.setSchedule(sched.book, engine.committed());
        engine.emit('status');
        return send(res, 200, { ok: true, planned: sched.playlist.items.length });
      }
      if (p === '/api/settings') {
        if (req.method === 'POST') {
          const b = await body(req);
          const rotation = settingsRotation(b.rotation ?? {});
          const cards = settingsCards(b.cards ?? {});
          const book = saveSchedule(settingsSchedule(b.schedule, sched.book.sched));
          const reserved = [...new Set(lib.list().flatMap((c) => [c.type, c.category]))];
          saveSettings(cfg, rotation, cards, b.filters === undefined ? undefined : cleanCategories(b.filters, reserved));
          lib.priority = new Set(Object.values(book.sched.clocks).flatMap((c) => c.slots));
          sched.setSchedule(book, engine.committed());
          engine.emit('status');
          return send(res, 200, { ok: true, planned: sched.playlist.items.length, warnings: sched.playlist.exclusionWarnings() });
        }
        const categories: Record<string, number> = {};
        for (const c of lib.playable()) {
          const k = c.type === 'music' ? c.category : c.type;
          categories[k] = (categories[k] ?? 0) + 1;
        }
        for (const f of cfg.library.categories) categories[f.name] = lib.playable(f.name).length;
        return send(res, 200, {
          rotation: cfg.rotation,
          cards: { weatherEveryMinutes: cfg.cards.weather.everyMinutes, trafficEveryMinutes: cfg.cards.traffic.everyMinutes },
          schedule: sched.book.sched,
          categories,
          filters: cfg.library.categories,
          tagFields: lib.tagFields(),
          tagNames: cfg.library.tagNames ?? {},
          warnings: sched.playlist.exclusionWarnings(),
        });
      }
      if (p === '/api/quality') {
        if (req.method === 'POST') {
          const q = qualitySettings(await body(req));
          const before = JSON.stringify([cfg.audio.processing, cfg.audio.tuning, cfg.output.videoBitrate]);
          saveQuality(cfg, q);
          // Video filters are per clip: they apply from the next one. Audio and bitrate live in the encoder.
          const encoderChanged = before !== JSON.stringify([cfg.audio.processing, cfg.audio.tuning, cfg.output.videoBitrate]);
          if (encoderChanged) engine.restartEncoder('encoder riavviato con le nuove impostazioni audio e bitrate');
          return send(res, 200, { ok: true, encoderRestarted: encoderChanged && engine.running });
        }
        return send(res, 200, {
          video: cfg.video,
          audio: { processing: cfg.audio.processing, tuning: cfg.audio.tuning },
          presets: Object.fromEntries((['light', 'radio', 'loud'] as const).map((k) => [k, presetValues(k)])),
          videoBitrate: parseInt(cfg.output.videoBitrate),
        });
      }
      if (p === '/api/vote') {
        if (req.method === 'POST') {
          const b = await body(req);
          if (b.action === 'start') return send(res, vote.startNow() ? 200 : 400, vote.round ? { ok: true } : { error: 'manca l’indirizzo della pagina (Controllo remoto) o non ci sono brani riposati' });
          if (b.action === 'stop') {
            vote.cancel();
            return send(res, 200, { ok: true });
          }
          const num = (v: unknown, min: number, max: number, def: number) => {
            const n = Math.round(Number(v));
            return Number.isFinite(n) ? Math.max(min, Math.min(max, n)) : def;
          };
          const cur = cfg.vote;
          const cats = (v: unknown) => (Array.isArray(v) ? v.map(String).filter(Boolean) : []);
          const hours = (Array.isArray(b.hours) ? b.hours : []).map((h: any) => ({ days: String(h?.days || '*').trim(), hours: String(h?.hours || '*').trim() }));
          for (const h of hours) {
            try {
              parseDays(h.days);
              parseHours(h.hours);
            } catch {
              return send(res, 400, { error: `fascia non valida: ${h.days} ${h.hours}` });
            }
          }
          const next = {
            enabled: !!b.enabled,
            hours,
            roundMinutes: num(b.roundMinutes, 2, 120, cur.roundMinutes),
            candidates: num(b.candidates, 2, 10, cur.candidates),
            groups: (Array.isArray(b.groups) ? b.groups : []).slice(0, 10)
              .map((g: any) => ({ categories: cats(g?.categories), count: num(g?.count, 0, 10, 0), tag: String(g?.tag ?? '').trim().slice(0, 12) }))
              .filter((g: { categories: string[]; count: number }) => g.categories.length && g.count > 0),
            newCount: num(b.newCount, 0, 10, cur.newCount),
            newCategories: cats(b.newCategories),
            otherCategories: cats(b.otherCategories),
            showEverySeconds: num(b.showEverySeconds, 30, 600, cur.showEverySeconds),
            showSeconds: num(b.showSeconds, 8, 60, cur.showSeconds),
          };
          if (next.enabled && !cfg.remote.url) return send(res, 400, { error: 'prima scrivi l’indirizzo della pagina in “Controllo remoto” e carica la cartella telecomando sul sito' });
          // The page knows the station by its key, also with the remote control off.
          if (!cfg.remote.key) saveRemote(cfg, { ...cfg.remote, key: (await import('node:crypto')).randomBytes(24).toString('hex') });
          saveVote(cfg, next);
        }
        const r = vote.round;
        return send(res, 200, {
          ...cfg.vote, page: vote.pageUrl(), inHours: vote.inHours(),
          round: r && { closesAt: r.closesAt, songs: r.songs.map((s, i) => ({ ...s, votes: vote.counts[i] ?? 0 })) },
          last: vote.last, connected: remote.state.lastOk > Date.now() - 15000, remoteError: remote.state.lastError,
        });
      }
      if (p === '/api/remote') {
        if (req.method === 'POST') {
          const b = await body(req);
          const cur = cfg.remote;
          const url = String(b.url ?? '').trim();
          if (url && !/^https?:\/\/[^\s]+$/i.test(url)) return send(res, 400, { error: 'indirizzo non valido' });
          const num = (v: unknown, min: number, max: number, def: number) => {
            const n = Math.round(Number(v));
            return Number.isFinite(n) ? Math.max(min, Math.min(max, n)) : def;
          };
          const l = b.limits ?? {};
          const pw = (v: unknown, label: string) => {
            const t = String(v ?? '');
            if (t && t.length < 6) throw new Error(`password ${label}: almeno 6 caratteri`);
            return t ? makeLogin(t) : null;
          };
          const next = {
            enabled: !!b.enabled,
            url,
            key: cur.key || (await import('node:crypto')).randomBytes(24).toString('hex'),
            admin: pw(b.adminPassword, 'admin') ?? cur.admin,
            user: b.userOff ? null : pw(b.userPassword, 'utente') ?? cur.user,
            limits: {
              skipsPerHour: num(l.skipsPerHour, 0, 60, cur.limits.skipsPerHour),
              clocks: (Array.isArray(l.clocks) ? l.clocks : []).map(String).filter((c: string) => sched.book.sched.clocks[c]),
              clockMinutes: num(l.clockMinutes, 5, 24 * 60, cur.limits.clockMinutes),
              disable: !!l.disable,
              report: !!l.report,
            },
          };
          if (next.enabled && !next.admin) return send(res, 400, { error: 'serve la password dell’amministratore' });
          saveRemote(cfg, next);
          if (next.enabled) remote.start();
        }
        const r = cfg.remote;
        return send(res, 200, {
          enabled: r.enabled, url: r.url, hasAdmin: !!r.admin, hasUser: !!r.user, limits: r.limits,
          clocks: Object.keys(sched.book.sched.clocks), state: remote.state,
        });
      }
      if (p === '/api/asrun') return send(res, 200, asrun.days());
      const day = p.match(/^\/api\/asrun\/(\d{4}-\d{2}-\d{2})$/);
      if (day) {
        return serveFile(res, asrun.fileFor(day[1]), {
          'content-type': 'text/csv; charset=utf-8',
          'content-disposition': `attachment; filename="asrun-${day[1]}.csv"`,
        });
      }
      send(res, 404, { error: 'non trovato' });
    } catch (e) {
      send(res, 400, { error: String((e as Error).message ?? e) });
    }
  });
  return new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(cfg.server.port, cfg.server.host, () => {
      console.log(`pannello: http://${cfg.server.host === '0.0.0.0' ? 'localhost' : cfg.server.host}:${cfg.server.port}/`);
      resolve(server);
    });
  });
}
