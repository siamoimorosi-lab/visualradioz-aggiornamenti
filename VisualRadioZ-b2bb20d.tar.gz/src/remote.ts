import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { type Config, type RemoteLogin, resolvePath } from './config.ts';
import type { Engine } from './engine.ts';
import type { Clip, Library } from './library.ts';
import type { Scheduler } from './scheduler.ts';
import type { Ticker } from './ticker.ts';
import type { Vote } from './vote.ts';

/**
 * Remote control through a small page on a web server (remote/api.php): every few seconds the
 * program sends the page what is on air and takes the commands people gave there. The computer
 * on air is never reachable from outside; the page only relays.
 *
 * Two levels: the admin does everything; the user does only what the admin allowed, within
 * the limits set here (skips per hour, which clocks and for how long, songs out of rotation).
 * The page checks the level at login, the program checks the limits again on every command.
 */
const EVERY_MS = 4000;
const ITERATIONS = 100_000;

export type Role = 'admin' | 'user';
interface Command { id: string; role: Role; by?: string; type: string; args?: Record<string, unknown> }
interface Report { id: string; artist: string; title: string; note: string; by: string; at: number }

/** Login check stored in the config and sent to the page: the password itself is never kept. */
export function makeLogin(password: string): RemoteLogin {
  const salt = crypto.randomBytes(16).toString('hex');
  return { salt, hash: crypto.pbkdf2Sync(password, salt, ITERATIONS, 32, 'sha256').toString('hex') };
}

export class Remote {
  private cfg: Config;
  private engine: Engine;
  private lib: Library;
  private sched: Scheduler;
  private ticker: Ticker;
  private file: string;
  private results: { id: string; ok: boolean; message: string }[] = [];
  private skips: number[] = [];
  private reports: Report[] = [];
  private actions: { at: number; role: Role; by: string; text: string }[] = [];
  private search: { q: string; items: unknown[] } | null = null;
  private timer: NodeJS.Timeout | null = null;
  private busy = false;
  state = { lastOk: 0, lastError: '', lastTry: 0 };

  private vote: Vote | null;

  constructor(cfg: Config, engine: Engine, lib: Library, sched: Scheduler, ticker: Ticker, vote: Vote | null = null) {
    this.vote = vote;
    this.cfg = cfg;
    this.engine = engine;
    this.lib = lib;
    this.sched = sched;
    this.ticker = ticker;
    this.file = path.join(resolvePath(cfg.dataDir), 'remote.json');
    try {
      const s = JSON.parse(fs.readFileSync(this.file, 'utf8'));
      this.reports = s.reports ?? [];
      this.actions = s.actions ?? [];
    } catch {
      // first run
    }
  }

  start() {
    this.timer ??= setInterval(() => this.tick().catch(() => {}), EVERY_MS);
  }

  private save() {
    try {
      fs.writeFileSync(this.file, JSON.stringify({ reports: this.reports.slice(-200), actions: this.actions.slice(-200) }));
    } catch {
      // not essential
    }
  }

  private async tick() {
    const r = this.cfg.remote;
    // The televoto travels through the same page, also with the remote control off.
    const voting = this.cfg.vote?.enabled || !!this.vote?.round || (this.vote?.talkUntil ?? 0) > Date.now();
    if ((!r.enabled && !voting) || !r.url || !r.key || this.busy) return;
    this.busy = true;
    this.state.lastTry = Date.now();
    try {
      const results = this.results;
      this.results = [];
      const res = await fetch(new URL('api.php?a=station', r.url.endsWith('/') ? r.url : r.url + '/'), {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-station-key': r.key },
        body: JSON.stringify({
          auth: r.enabled ? { admin: r.admin, user: r.user } : { admin: null, user: null }, limits: r.limits, state: this.view(), results,
          vote: this.vote ? { channel: this.cfg.channelName, ...this.vote.publicState() } : null,
        }),
        signal: AbortSignal.timeout(10000),
      });
      const text = await res.text();
      let body: { commands?: Command[]; error?: string; votes?: { round: string; counts: number[] } };
      try {
        body = JSON.parse(text);
      } catch {
        throw new Error(`risposta non valida dalla pagina (${res.status}): ${text.slice(0, 80)}`);
      }
      if (!res.ok) {
        this.results.unshift(...results);
        throw new Error(body.error ?? `errore ${res.status}`);
      }
      if (body.votes) this.vote?.setCounts(body.votes.round, body.votes.counts);
      for (const c of body.commands ?? []) this.results.push({ id: c.id, ...this.run(c) });
      this.state.lastOk = Date.now();
      this.state.lastError = '';
    } catch (e) {
      const msg = (e as Error).message ?? String(e);
      if (msg !== this.state.lastError) this.engine.note(`controllo remoto: ${msg}`);
      this.state.lastError = msg;
    } finally {
      this.busy = false;
    }
  }

  private skipsLeft(): number {
    const hourAgo = Date.now() - 3600_000;
    this.skips = this.skips.filter((t) => t > hourAgo);
    return Math.max(0, this.cfg.remote.limits.skipsPerHour - this.skips.length);
  }

  private clipView(c: Clip | null | undefined) {
    return c ? { id: c.id, type: c.type, artist: c.artist, title: c.title, category: c.category } : null;
  }

  /** What the page shows. */
  private view() {
    const st = this.engine.status();
    const pl = this.engine.playlistView();
    const now = Date.now();
    const o = this.sched.book.override;
    const lim = this.cfg.remote.limits;
    return {
      at: now,
      channel: st.channel,
      version: st.version,
      running: st.running,
      onAir: st.onAir?.clip ? { ...st.onAir.clip, endsAt: st.onAir.endsAt, startedAt: st.onAir.startedAt, slot: pl.onAir?.slot } : null,
      next: pl.future.slice(0, 8).map((r) => ({ id: r.id, type: r.type, artist: r.artist, title: r.title, at: r.at, slot: r.slot })),
      history: pl.past.slice(-8).reverse().map((r) => ({ id: r.id, type: r.type, artist: r.artist, title: r.title, at: r.at })),
      clock: {
        now: st.schedule.clock,
        override: o && o.until > now ? o : null,
        all: Object.keys(this.sched.book.sched.clocks),
        user: lim.clocks.filter((c) => this.sched.book.sched.clocks[c]),
      },
      limits: lim,
      skipsLeft: this.skipsLeft(),
      queue: st.queue,
      breaks: st.schedule.breaks,
      ticker: this.ticker.status().manual ?? '',
      disabled: this.lib.list().filter((c) => c.disabled).slice(0, 300).map((c) => ({ ...this.clipView(c), by: c.disabled!.by, at: c.disabled!.at })),
      reports: this.reports.slice(-100),
      actions: this.actions.slice(-40).reverse(),
      log: st.log.slice(-15).reverse(),
      health: { encoder: st.encoder, outputs: st.outputs },
      search: this.search,
      vote: this.vote ? { ...this.vote.publicState(), counts: this.vote.counts, inHours: this.vote.inHours(), page: this.vote.pageUrl() } : null,
    };
  }

  private did(c: Command, text: string) {
    const by = String(c.by || (c.role === 'admin' ? 'admin' : 'utente')).slice(0, 40);
    this.actions.push({ at: Date.now(), role: c.role, by, text });
    this.engine.note(`da remoto (${by}): ${text}`);
    this.save();
  }

  private replan() {
    this.sched.setSchedule(this.sched.book, this.engine.committed());
    this.engine.emit('status');
  }

  /** One command from the page; the user's limits are checked here as well. */
  run(c: Command): { ok: boolean; message: string } {
    const admin = c.role === 'admin';
    const lim = this.cfg.remote.limits;
    const a = c.args ?? {};
    const clip = typeof a.id === 'string' ? this.lib.get(a.id) : undefined;
    const name = (x: Clip) => (x.artist ? `${x.artist} - ${x.title}` : x.title);
    const no = (message: string) => ({ ok: false, message });
    try {
      switch (c.type) {
        case 'skip': {
          if (!admin) {
            if (this.skipsLeft() <= 0) return no(`limite di ${lim.skipsPerHour} salti all'ora raggiunto`);
            this.skips.push(Date.now());
          }
          const on = this.engine.status().onAir?.clip;
          this.engine.skip();
          this.did(c, `saltato ${on ? name(on as Clip) : 'il brano'}`);
          return { ok: true, message: 'brano saltato' };
        }
        case 'clock': {
          const clock = String(a.clock ?? '');
          const minutes = Math.round(Number(a.minutes ?? 60));
          if (!this.sched.book.sched.clocks[clock]) return no('orologio sconosciuto');
          if (!admin && !lim.clocks.includes(clock)) return no('orologio non permesso');
          const max = admin ? 24 * 60 : lim.clockMinutes;
          if (!(minutes > 0)) return no('durata non valida');
          const m = Math.min(minutes, max);
          this.sched.book.override = { clock, until: Date.now() + m * 60_000, by: String(c.by || c.role) };
          this.replan();
          this.did(c, `orologio "${clock}" per ${m} minuti`);
          return { ok: true, message: `orologio "${clock}" fino alle ${new Date(Date.now() + m * 60_000).toTimeString().slice(0, 5)}` };
        }
        case 'clockReset': {
          if (!this.sched.book.override) return { ok: true, message: 'già sul palinsesto' };
          this.sched.book.override = null;
          this.replan();
          this.did(c, 'tornato all’orologio del palinsesto');
          return { ok: true, message: 'palinsesto ripristinato' };
        }
        case 'disable': {
          if (!clip) return no('brano sconosciuto');
          if (!admin && (!lim.disable || clip.type !== 'music')) return no('non permesso');
          this.lib.setDisabled(clip.id, String(c.by || c.role));
          if (this.engine.status().onAir?.clip?.id === clip.id) this.engine.skip();
          this.did(c, `tolto dalla rotazione ${name(clip)}`);
          return { ok: true, message: `${name(clip)} tolto dalla rotazione` };
        }
        case 'report': {
          if (!clip) return no('brano sconosciuto');
          if (!admin && !lim.report) return no('non permesso');
          this.reports.push({ id: clip.id, artist: clip.artist, title: clip.title, note: String(a.note ?? '').slice(0, 300), by: String(c.by || c.role).slice(0, 40), at: Date.now() });
          this.did(c, `segnalato ${name(clip)}${a.note ? `: ${String(a.note).slice(0, 80)}` : ''}`);
          return { ok: true, message: 'segnalazione inviata' };
        }
      }
      if (!admin) return no('solo per l’amministratore');
      switch (c.type) {
        case 'enable': {
          if (!clip) return no('brano sconosciuto');
          this.lib.setDisabled(clip.id, null);
          this.reports = this.reports.filter((r) => r.id !== clip.id);
          this.did(c, `rimesso in rotazione ${name(clip)}`);
          return { ok: true, message: `${name(clip)} di nuovo in rotazione` };
        }
        case 'dismissReport': {
          const at = Number(a.at);
          this.reports = this.reports.filter((r) => !(r.id === a.id && r.at === at));
          this.save();
          return { ok: true, message: 'segnalazione archiviata' };
        }
        case 'search': {
          const q = String(a.q ?? '').trim().toLowerCase();
          const words = q.split(/\s+/).filter(Boolean);
          const items = words.length
            ? this.lib.list().filter((x) => words.every((w) => `${x.artist} ${x.title}`.toLowerCase().includes(w))).slice(0, 40)
              .map((x) => ({ ...this.clipView(x), disabled: !!x.disabled, playable: this.lib.isPlayable(x) }))
            : [];
          this.search = { q, items };
          return { ok: true, message: `${items.length} risultati` };
        }
        case 'queue':
        case 'playnow': {
          if (!clip || !this.lib.isPlayable(clip)) return no('brano non riproducibile');
          if (c.type === 'queue') {
            this.sched.enqueue(clip.id, !!a.front);
            this.engine.emit('status');
            this.did(c, `in coda ${name(clip)}`);
          } else {
            this.engine.playNow(clip.id);
            this.did(c, `in onda subito ${name(clip)}`);
          }
          return { ok: true, message: 'fatto' };
        }
        case 'unqueue': {
          this.sched.removeFromQueue(Number(a.index));
          this.engine.emit('status');
          return { ok: true, message: 'tolto dalla coda' };
        }
        case 'ticker': {
          this.ticker.setManual(String(a.text ?? '').slice(0, 500));
          this.did(c, 'testo della barra cambiato');
          return { ok: true, message: 'barra aggiornata' };
        }
        case 'card': {
          const kind = String(a.kind);
          if (!['weatherToday', 'weatherWeek', 'traffic', 'headliner'].includes(kind)) return no('scheda sconosciuta');
          const mode = this.engine.forceCard(kind as 'weatherToday');
          this.did(c, `scheda ${kind}`);
          return { ok: true, message: mode === 'now' ? 'scheda in onda' : mode === 'next' ? 'scheda al prossimo brano' : 'scheda non disponibile' };
        }
        case 'break': {
          this.sched.fireNow(String(a.name));
          this.engine.emit('status');
          this.did(c, `blocco "${a.name}" mandato`);
          return { ok: true, message: 'blocco in arrivo' };
        }
        case 'voteStart': {
          if (!this.vote?.startNow()) return no('televoto non disponibile: manca l’indirizzo della pagina o non ci sono brani');
          this.did(c, 'televoto avviato');
          return { ok: true, message: 'televoto aperto' };
        }
        case 'voteStop': {
          this.vote?.cancel();
          this.did(c, 'televoto annullato');
          return { ok: true, message: 'televoto annullato' };
        }
        case 'replan': {
          this.replan();
          this.did(c, 'playlist ripianificata');
          return { ok: true, message: 'playlist ripianificata' };
        }
      }
      return no('comando sconosciuto');
    } catch (e) {
      return no((e as Error).message ?? String(e));
    }
  }
}
