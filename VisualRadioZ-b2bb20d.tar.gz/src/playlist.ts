import fs from 'node:fs';
import path from 'node:path';
import { EventEmitter } from 'node:events';
import { type Config, resolvePath } from './config.ts';
import type { Clip, Library } from './library.ts';
import type { ScheduleBook } from './schedule.ts';
import { fieldValue, fieldsOf, fold, ruleMatches } from './filters.ts';

/** One entry of the planned playlist. `at` is the start time estimated when it was planned. */
export interface PlannedItem {
  uid: number;
  id: string;
  /** Clock slot it fills ("1SH", "5CT"…) or "jingle". */
  slot: string;
  /** Clock and position of the slot in it (-1 for jingles), to continue the clock. */
  clock: string;
  index: number;
  at: number;
}

/** A clip that went to air (scheduler history). */
export interface Played {
  id: string;
  artist: string;
  type: string;
  at: number;
}

/** The playlist always reaches this far ahead. */
const HORIZON_MS = 72 * 3600_000;
/** Extend it once less than this is left, so planning happens about once an hour. */
const REFILL_MS = HORIZON_MS - 3600_000;
/** Planned in one go when the playlist is empty; the rest follows in the background. */
const FIRST_MS = 3600_000;
/** Items planned per step in the background; steps run for at most STEP_BUDGET_MS, then the stream gets the computer for STEP_PAUSE_MS. */
const STEP_ITEMS = 4;
const STEP_BUDGET_MS = 8;
const STEP_PAUSE_MS = 30;
/** The same planning warning (slot, rule, clip) is told once in this time. */
const WARN_EVERY_MS = 15 * 60_000;
/** If the channel runs this far ahead of or behind the plan, plan again from now. */
const MAX_DRIFT_MS = 20 * 60_000;
/** Plays older than this no longer affect the rotation (same hour on previous days). */
const MEMORY_MS = 4 * 24 * 3600_000;

/** How long a clip holds the air, in seconds: the next one starts at its mix point. */
export function airTime(c: Clip): number {
  return Math.max(1, Math.min(c.cueOut, c.mixOut || c.cueOut) - c.cueIn);
}

const hourOfDay = (ms: number) => {
  const d = new Date(ms);
  return d.getHours() + d.getMinutes() / 60;
};

/** Rotation memory, rebuilt from the history plus what is already planned. */
interface State {
  last: Map<string, number>;
  plays: Map<string, number[]>;
  artistLast: Map<string, number>;
  recentArtists: string[][];
  /** The last music clips, oldest first, for the rules on consecutive songs. */
  recentMusic: Clip[];
  musicSinceJingle: number;
  lastJingle: Clip | undefined;
  lastType: string;
  cursor: { hour: string; index: number; clock: string };
}

/**
 * The playlist planned ahead (3 days), so the panel shows exactly what will
 * play. The engine takes clips from its head; manual queue and breaks are
 * inserted at air time and simply push it later.
 *
 * Music rotation, per slot category:
 * - hard rules: each artist (of multi-artist tags too) and each title kept
 *   apart by the configured minutes; relaxed only when nothing satisfies them;
 * - every song rests at least half of its category's turnover, i.e. how long
 *   the category takes to play all its songs (11 songs played 3 times an hour
 *   come back about every 4 hours, 3000 songs once in days);
 * - among those, the most rested wins, minus a penalty for having played at
 *   the same time of day on the previous days and for artists heard recently,
 *   plus a little noise, so the order never settles into a fixed pattern.
 */
export class Playlist extends EventEmitter {
  items: PlannedItem[] = [];
  private nextUid = 1;
  /** The last clock slot taken off the playlist: a new plan continues the clock from it. */
  private taken: PlannedItem | null = null;
  /** Taken off the playlist but maybe not aired yet (the engine prepares the next clip early). */
  private recentlyTaken: PlannedItem[] = [];
  private file: string;
  private cfg: Config;
  private lib: Library;
  book: ScheduleBook;
  private history: () => Played[];
  /** Clip id → slot for clips taken from the playlist, for the panel. */
  slotOf = new Map<string, string>();
  rng: () => number = Math.random;

  constructor(cfg: Config, lib: Library, book: ScheduleBook, history: () => Played[]) {
    super();
    this.cfg = cfg;
    this.lib = lib;
    this.book = book;
    this.history = history;
    this.file = path.join(resolvePath(cfg.dataDir), 'playlist.json');
    try {
      const s = JSON.parse(fs.readFileSync(this.file, 'utf8'));
      this.items = s.items ?? [];
      this.nextUid = s.nextUid ?? 1;
      this.taken = s.taken ?? null;
    } catch {
      // first run
    }
  }

  private save() {
    fs.writeFileSync(this.file, JSON.stringify({ items: this.items, nextUid: this.nextUid, taken: this.taken }));
  }

  /**
   * The next clip to air at `at`. `locked` = clips already committed to air
   * (they count for the rotation even though they are not in the history yet).
   */
  take(locked: Clip[], at: number): Clip | null {
    const head = this.items[0];
    if (!head || Math.abs(head.at - at) > MAX_DRIFT_MS) {
      if (head) this.emit('replanned', Math.round((at - head.at) / 60_000));
      this.regenerate(locked, at);
    }
    const afterJingle = locked.some((c) => c.type === 'jingle');
    while (this.items.length) {
      const item = this.items.shift()!;
      let c = this.lib.get(item.id);
      // Never two jingles in a row (a jingle queued by hand already took this one's place).
      if (c?.type === 'jingle' && afterJingle) continue;
      if (!c || !this.lib.isPlayable(c)) {
        const st = this.state(locked, at);
        c = (item.slot === 'jingle' ? this.pickJingle(st, new Map()) : this.pickFor(item.slot, st, at, new Map())) ?? undefined;
        if (!c) continue;
      }
      this.slotOf.set(c.id, item.slot);
      if (item.index >= 0) this.taken = item;
      this.recentlyTaken = [...this.recentlyTaken, { ...item, id: c.id }].slice(-5);
      if (this.slotOf.size > 50) this.slotOf.delete(this.slotOf.keys().next().value!);
      if (!this.filling) this.fillInBackground(locked);
      this.save();
      return c;
    }
    return null;
  }

  /** Drop a planned item (it was put on air by hand). */
  remove(uid: number) {
    const i = this.items.findIndex((it) => it.uid === uid);
    if (i >= 0) this.items.splice(i, 1);
    this.save();
  }

  /** Clips taken but not aired (a clip was put on air by hand) go back to the head, in order. */
  putBack(clips: Clip[]) {
    const at = this.items[0]?.at ?? Date.now();
    const ids = new Set(clips.map((c) => c.id));
    this.recentlyTaken = this.recentlyTaken.filter((it) => !ids.has(it.id));
    this.items.unshift(...clips.map((c) => ({
      uid: this.nextUid++, id: c.id, slot: this.slotOf.get(c.id) ?? (c.type === 'music' ? c.category : c.type), clock: '', index: -1, at,
    })));
    this.save();
  }

  /**
   * Throw away the plan and make a new one starting at `at`: the first hour
   * at once, the rest in the background (or all at once with `background` false).
   */
  regenerate(locked: Clip[] = [], at = Date.now(), background = true) {
    this.items = [];
    this.generation++;
    if (!background) {
      this.extend(locked, at);
    } else {
      // Only the next few items at once: a long plan with strict rest rules takes seconds.
      this.extend(locked, at, at + FIRST_MS - Date.now(), STEP_ITEMS);
      this.fillInBackground(locked);
    }
    this.save();
  }

  private generation = 0;
  private filling = false;

  /** Plan the rest up to the horizon a few items at a time, yielding to the stream in between. */
  private fillInBackground(locked: Clip[]) {
    if (this.filling) return;
    this.filling = true;
    const gen = this.generation;
    const step = () => {
      if (gen !== this.generation) {
        this.filling = false;
        return this.fillInBackground([]);
      }
      const t0 = Date.now();
      let more = true;
      while (more && Date.now() - t0 < STEP_BUDGET_MS) more = this.extend(locked, Date.now(), HORIZON_MS, STEP_ITEMS);
      if (more) return setTimeout(step, STEP_PAUSE_MS);
      this.filling = false;
      this.save();
      this.emit('planned', this.items.length);
    };
    setTimeout(step, STEP_PAUSE_MS);
  }

  /**
   * Plan up to `ahead` ms from now, at most `maxItems` items. `from` = start of the
   * first item when the playlist is empty. Returns true if there is more to plan.
   */
  extend(locked: Clip[] = [], from = Date.now(), ahead = HORIZON_MS, maxItems = Infinity): boolean {
    const now = Date.now();
    const lastItem = this.items[this.items.length - 1];
    let at = lastItem ? lastItem.at + airTime(this.lib.get(lastItem.id) ?? ({ cueIn: 0, cueOut: 200, mixOut: 200 } as Clip)) * 1000 : from;
    if (lastItem && ahead === HORIZON_MS && maxItems === Infinity && at > now + REFILL_MS) return false;
    const st = this.state(locked, at);
    const pools = new Map<string, Clip[]>();
    this.avgCache = null;
    let n = 0;
    for (; at < now + ahead; n++) {
      if (n >= maxItems) return true;
      const every = this.cfg.rotation.jingleEvery;
      let c: Clip | null = null;
      let slot = 'jingle';
      let index = -1;
      if (every > 0 && st.musicSinceJingle >= every && st.lastType !== 'jingle') c = this.pickJingle(st, pools);
      if (!c) {
        // A slot with no song rested enough (nor in its backup) gives way to the next slot of the clock.
        // Moving on after a skipped slot never lands twice in a row on the category just played
        // (a small category skipped before a big one gave runs of the same category), unless
        // no other slot has a song.
        const tries = this.book.clockAt(at).clock.slots.length;
        const prev = this.items[this.items.length - 1]?.slot;
        let same: [Clip, string, number] | null = null;
        for (let n = 0; n < tries && !c; n++) {
          [slot, index] = this.nextSlot(st, at);
          c = this.pickFor(slot, st, at, pools, false);
          if (!c) this.warn('slot-skipped', slot);
          else if (n > 0 && slot === prev && n < tries - 1) {
            same ??= [c, slot, index];
            c = null;
          }
        }
        if (!c && same) [c, slot, index] = same;
        c ??= this.pickFor(slot, st, at, pools);
      }
      if (!c) break; // empty library
      this.items.push({ uid: this.nextUid++, id: c.id, slot, clock: st.cursor.clock, index, at });
      this.record(st, c, at);
      at += airTime(c) * 1000;
    }
    return false;
  }

  private warned = new Map<string, number>();
  /** A planning warning, at most once per WARN_EVERY_MS for the same slot, rule or clip. */
  private warn(event: string, ...args: unknown[]) {
    const key = event + ' ' + args.map((a) => (a && typeof a === 'object' ? (a as Clip).id : String(a))).join(' ');
    const now = Date.now();
    if (now - (this.warned.get(key) ?? 0) < WARN_EVERY_MS) return;
    this.warned.set(key, now);
    if (this.warned.size > 500) this.warned.delete(this.warned.keys().next().value!);
    this.emit(event, ...args);
  }

  private artistCache = new Map<string, string[]>();
  /** Average air time per music clip (jingles included), computed once per planning run. */
  private avgCache: number | null = null;

  /** Playable clips of `group` (only the music ones with `musicOnly`), once per planning run. */
  private pool(group: string, pools: Map<string, Clip[]>, musicOnly = false): Clip[] {
    const key = musicOnly ? `music:${group}` : group;
    let p = pools.get(key);
    if (!p) {
      p = this.lib.playable(group);
      if (musicOnly) p = p.filter((c) => c.type === 'music');
      pools.set(key, p);
    }
    return p;
  }

  private artistsOf(artist: string): string[] {
    let a = this.artistCache.get(artist);
    if (!a) {
      const sep = this.cfg.rotation.artistSplit;
      a = (sep ? artist.split(sep) : [artist]).map((x) => x.trim().toLowerCase()).filter(Boolean);
      this.artistCache.set(artist, a);
    }
    return a;
  }

  private state(locked: Clip[], at: number): State {
    const st: State = {
      last: new Map(), plays: new Map(), artistLast: new Map(), recentArtists: [], recentMusic: [],
      musicSinceJingle: 0, lastJingle: undefined, lastType: '', cursor: { hour: '', index: 0, clock: '' },
    };
    const since = at - MEMORY_MS;
    for (const h of this.history()) {
      if (h.at < since) continue;
      const c = this.lib.get(h.id);
      if (c) this.record(st, c, h.at);
    }
    for (const c of locked) this.record(st, c, at);
    // Taken but not in the history yet: they count too, at their planned time.
    const aired = new Set(this.history().filter((h) => h.at >= at - 3600_000).map((h) => h.id));
    for (const it of this.recentlyTaken) {
      const c = this.lib.get(it.id);
      if (c && !aired.has(it.id) && !locked.includes(c) && it.at >= at - 3600_000) this.record(st, c, Math.min(it.at, at));
    }
    // Planned before `at` (when picking again for the head of the plan, the hours planned after
    // it must not count: every song and artist placed there would look just played).
    for (const item of this.items) {
      if (item.at > at) continue;
      const c = this.lib.get(item.id);
      if (c) this.record(st, c, item.at);
    }
    // The clock continues from the last planned slot, or from the last one aired.
    const base = [...this.items].reverse().find((it) => it.index >= 0) ?? this.taken;
    if (base) st.cursor = { hour: this.hourKey(base.at, base.clock), index: base.index + 1, clock: base.clock };
    return st;
  }

  private hourKey(at: number, clock: string): string {
    if (this.book.sched.clocks[clock]?.continuous) return '';
    const d = new Date(at);
    return `${d.toDateString()} ${d.getHours()}`;
  }

  private record(st: State, c: Clip, at: number) {
    st.last.set(c.id, at);
    const p = st.plays.get(c.id);
    if (p) p.push(at);
    else st.plays.set(c.id, [at]);
    st.lastType = c.type;
    if (c.type === 'jingle') {
      st.musicSinceJingle = 0;
      st.lastJingle = c;
    } else if (c.type === 'music') {
      st.musicSinceJingle++;
      const artists = this.artistsOf(c.artist);
      for (const a of artists) st.artistLast.set(a, at);
      st.recentArtists.push(artists);
      if (st.recentArtists.length > 50) st.recentArtists.shift();
      st.recentMusic.push(c);
      if (st.recentMusic.length > 12) st.recentMusic.shift();
    }
  }

  /** Slot of the clock for a clip starting at `at`; clocks restart every hour unless `continuous`. */
  private nextSlot(st: State, at: number): [string, number] {
    const { name, clock } = this.book.clockAt(at);
    const hour = this.hourKey(at, name);
    if (st.cursor.hour !== hour || st.cursor.clock !== name) st.cursor = { hour, index: 0, clock: name };
    const index = st.cursor.index % clock.slots.length;
    st.cursor.index = index + 1;
    return [clock.slots[index], index];
  }

  /** Average time between two plays of a clip of `group`, if every one played in turn. */
  private turnover(group: string, size: number, at: number, pools: Map<string, Clip[]>): number {
    if (this.avgCache === null) {
      const music = this.pool('music', pools);
      const jingles = this.pool('jingle', pools);
      const every = this.cfg.rotation.jingleEvery;
      const jingleShare = every > 0 && jingles.length ? jingles.reduce((s, c) => s + airTime(c), 0) / jingles.length / every : 0;
      this.avgCache = (music.length ? music.reduce((s, c) => s + airTime(c), 0) / music.length : 210) + jingleShare;
    }
    const slots = this.book.clockAt(at).clock.slots;
    const share = slots.filter((s) => s === group).length / slots.length || 1 / Math.max(1, slots.length);
    return (size * this.avgCache * 1000) / share;
  }

  /** Fields of each clip, worked out once (a rescan makes new clip objects, so new tags count). */
  private fieldsCache = new WeakMap<Clip, Map<string, string>>();

  private fields(c: Clip): Map<string, string> {
    let f = this.fieldsCache.get(c);
    if (!f) {
      f = fieldsOf(c);
      this.fieldsCache.set(c, f);
    }
    return f;
  }

  /** Would `c` break a rule on consecutive songs, after the songs in `recent`? */
  sequenceOk(c: Clip, recent: Clip[]): boolean {
    for (const r of this.cfg.rotation.sequence ?? []) {
      const max = Math.max(1, r.max);
      let same: (x: Clip) => boolean;
      if (r.value) {
        same = (x) => ruleMatches(this.fields(x), { field: r.field, op: 'is', value: r.value });
      } else {
        const v = fold(fieldValue(this.fields(c), r.field));
        if (!v) continue;
        same = (x) => fold(fieldValue(this.fields(x), r.field)) === v;
      }
      if (!same(c)) continue;
      let run = 0;
      for (let i = recent.length - 1; i >= 0 && same(recent[i]); i--) run++;
      if (run >= max) return false;
    }
    return true;
  }

  /** Slots of each clock whose songs are all left out by the clock's exclusions (the exclusion is then ignored). */
  exclusionWarnings(): string[] {
    const out: string[] = [];
    for (const [name, clock] of Object.entries(this.book.sched.clocks)) {
      if (!clock.exclude?.length) continue;
      const match = clock.excludeMatch === 'all' ? 'every' : 'some';
      for (const slot of new Set(clock.slots)) {
        if (slot === 'jingle') continue;
        const all = this.lib.playable(slot).filter((c) => c.type === 'music');
        if (all.length && all.every((c) => clock.exclude![match]((r) => ruleMatches(this.fields(c), r)))) {
          out.push(`orologio "${name}": le esclusioni tolgono tutti i ${all.length} brani di "${slot}", quindi non vengono applicate`);
        }
      }
    }
    return out;
  }

  /** Songs the clock on air at `at` leaves out. */
  private excluded(at: number): (c: Clip) => boolean {
    const { exclude: rules = [], excludeMatch } = this.book.clockAt(at).clock;
    if (!rules.length) return () => false;
    if (excludeMatch === 'all') return (c) => rules.every((r) => ruleMatches(this.fields(c), r));
    return (c) => rules.some((r) => ruleMatches(this.fields(c), r));
  }

  /**
   * The song for a clock slot. The time before a song comes back is kept without exception:
   * first a song of the slot's category keeping every rule, then one from all the music,
   * then (still keeping the song's time) one whose artist came back too soon; all logged.
   * Only when no song at all is rested enough (a very small library) one is repeated, the
   * longest rested, with an error in the log.
   */
  private pickFor(slot: string, st: State, at: number, pools: Map<string, Clip[]>, last = true): Clip | null {
    // Only the slot's category and the backup chosen for it: never the whole library.
    const backup = (this.cfg.rotation.backups ?? []).find((b) => b.category === slot)?.backup;
    for (const keep of ['strict', 'title'] as const) {
      let c = this.pickMusic(slot, st, at, pools, keep);
      if (c) {
        if (keep === 'title') this.warn('relaxed', 'di separazione artista');
        return c;
      }
      if (backup && backup !== slot && (c = this.pickMusic(backup, st, at, pools, keep))) {
        this.warn('backup', slot, backup);
        return c;
      }
    }
    if (!last) return null;
    // Nothing rested enough in the whole clock: the longest rested song of the slot, as an error.
    const c = this.pickMusic(slot, st, at, pools) ?? (backup ? this.pickMusic(backup, st, at, pools) : null) ?? this.pickMusic('music', st, at, pools);
    if (c) this.warn('repeat', c);
    return c;
  }

  /**
   * `keep`: 'strict' gives null rather than a song breaking the song or artist time,
   * 'title' null rather than one breaking the song time; without it the best there is.
   */
  pickMusic(group: string, st: State, at: number, pools: Map<string, Clip[]>, keep?: 'strict' | 'title'): Clip | null {
    let all = this.pool(group, pools, true);
    if (!all.length) return null;
    const out = this.excluded(at);
    const kept = all.filter((c) => !out(c));
    if (kept.length) all = kept;
    else this.warn('relaxed', 'di esclusione dell’orologio');
    const { artistSeparation, artistSeparationMinutes, titleSeparationMinutes } = this.cfg.rotation;
    const sepMs = artistSeparationMinutes * 60_000;
    const recent = new Set(artistSeparation > 0 ? st.recentArtists.slice(-artistSeparation).flat() : []);
    const artistOk = (c: Clip) =>
      this.artistsOf(c.artist).every((a) => !recent.has(a) && (sepMs <= 0 || at - (st.artistLast.get(a) ?? -Infinity) >= sepMs));
    const titleOk = (c: Clip) => at - (st.last.get(c.id) ?? -Infinity) >= titleSeparationMinutes * 60_000;
    const T = this.turnover(group, all.length, at, pools);
    const restOk = (c: Clip) => at - (st.last.get(c.id) ?? -Infinity) >= T / 2;
    const seqOk = (c: Clip) => this.sequenceOk(c, st.recentMusic);
    // Strictest rules first; each looser set is only worked out when the stricter one is empty.
    const rules = [
      (c: Clip) => artistOk(c) && titleOk(c) && seqOk(c) && restOk(c),
      (c: Clip) => artistOk(c) && titleOk(c) && seqOk(c),
      (c: Clip) => artistOk(c) && titleOk(c),
      titleOk,
      artistOk,
      () => true,
    ];
    const relaxedNames = ['', '', 'di sequenza', 'di separazione artista', 'di separazione titolo', 'di separazione titolo e artista'];
    let tier = 0;
    let candidates: Clip[] = [];
    for (; tier < rules.length; tier++) {
      candidates = all.filter(rules[tier]);
      if (candidates.length) break;
    }
    if ((keep === 'strict' && tier > 2) || (keep === 'title' && tier > 3)) return null;
    // Relaxing the separations is told by pickFor; a looser sequence rule is told here.
    if (tier === 2) this.warn('relaxed', relaxedNames[tier]);

    const hod = hourOfDay(at);
    const score = (c: Clip) => {
      const last = st.last.get(c.id);
      // Songs not heard in the last days come first, then the most rested.
      let s = last === undefined ? 3.5 : Math.min(3, (at - last) / T);
      // Same time of day on the previous days (the closer and the more recent, the worse).
      for (const t of st.plays.get(c.id) ?? []) {
        const daysAgo = (at - t) / 86_400_000;
        if (daysAgo < 0.5) continue;
        const diff = Math.abs(hod - hourOfDay(t));
        const d = Math.min(diff, 24 - diff);
        if (d < 1.25) s -= (3 * (1 - d / 1.25)) / Math.ceil(daysAgo);
      }
      // Artists heard recently (within twice the minimum separation) count against it.
      if (sepMs > 0) {
        for (const a of this.artistsOf(c.artist)) {
          const ago = at - (st.artistLast.get(a) ?? -Infinity);
          if (ago < 2 * sepMs) s -= 0.3 * (1 - ago / (2 * sepMs));
        }
      }
      return s + this.rng() * 0.25;
    };
    let best: Clip | null = null;
    let bestScore = -Infinity;
    for (const c of candidates) {
      const s = score(c);
      if (s > bestScore) [best, bestScore] = [c, s];
    }
    return best;
  }

  /**
   * Jingles rotate without repeats (least recently played first) and change
   * length each time: short (< 5 s), medium (5–12 s), long, short… and never
   * two of the same family (the name before " - ") in a row.
   */
  pickJingle(st: State, pools: Map<string, Clip[]>): Clip | null {
    const all = [...this.pool('jingle', pools)].sort((a, b) => (st.last.get(a.id) ?? 0) - (st.last.get(b.id) ?? 0));
    if (!all.length) return null;
    const band = (c: Clip) => {
      const d = c.cueOut - c.cueIn;
      return d < 5 ? 0 : d < 12 ? 1 : 2;
    };
    const last = st.lastJingle;
    const target = last ? (band(last) + 1) % 3 : 0;
    const family = (c: Clip) => c.artist.toLowerCase();
    const otherFamily = (c: Clip) => !last || family(c) !== family(last);
    return (
      all.find((c) => band(c) === target && otherFamily(c)) ??
      all.find((c) => band(c) === target) ??
      all.find(otherFamily) ??
      all[0]
    );
  }
}
