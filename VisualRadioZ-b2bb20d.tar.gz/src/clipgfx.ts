import fs from 'node:fs';
import path from 'node:path';
import { type Config, gfxScale } from './config.ts';
import type { Clip } from './library.ts';
import { filterValue, sec } from './ffmpeg.ts';
import { tickerLayout, topLeftLayout } from './graphics.ts';
import { Library } from './library.ts';
import { fitWidth, shrinkToFit, textWidth, twoLines } from './textfit.ts';
import type { VoteOverlay } from './vote.ts';


/**
 * Graphics drawn by the decoder over one clip, in segment time (t = 0 at the
 * segment start):
 * - lower third: "ORA IN ONDA", artist and title, left-aligned on one edge
 *   with a thin white bar, cascading in from the left;
 * - "A seguire": the next clip under the logo, title over artist in a compact card,
 *   with a bar that fills up to the moment it starts.
 */
export interface ClipGfxPlan {
  id: number;
  clip: Clip | null;
  length: number;
  titleAt: number | null;
  upNext?: Clip | null;
  /** Segment time at which the next clip starts. */
  nextAt?: number;
  /** Lower third kicker instead of "ORA IN ONDA" (e.g. the song most voted). */
  kicker?: string;
  /** Televoto panel: the round's songs and the QR (ffmpeg input `qrInput`). */
  vote?: VoteOverlay & { qrInput?: number };
}

const easeOut = (p: string) => `(1-pow(1-${p},3))`;
const ramp = (from: number, dur: number) => `clip((t-${sec(from)})/${sec(dur)},0,1)`;

function textFile(tmpDir: string, id: number, name: string, text: string) {
  const f = path.join(tmpDir, `seg${id}-${name}.txt`);
  fs.writeFileSync(f, text || ' ');
  return filterValue(f);
}

/** A window [s, e] in which an element slides `dx` px from the left (or `dy` from above) and fades. */
function windowMotion(s: number, e: number, { dx = 0, dy = 0, inDur = 0.55, outDur = 0.35 } = {}) {
  const pin = ramp(s, inDur);
  const pout = ramp(e - outDur, outDur);
  return {
    x: `-${dx}*(1-${easeOut(pin)})-${dx}*pow(${pout},2)`,
    y: `-${dy}*(1-${easeOut(pin)})`,
    alpha: `${pin}*(1-${pout})`,
    enable: `between(t,${sec(s)},${sec(e)})`,
  };
}

function lowerThird(cfg: Config, plan: ClipGfxPlan, tmpDir: string, input: string, output: string): string {
  const clip = plan.clip!;
  const { width: W, height: H, fps } = cfg.output;
  const ov = cfg.overlay;
  const S = plan.titleAt!;
  const E = Math.min(plan.length - 0.5, S + ov.nowPlaying.showSeconds);
  const x0 = ov.logo.marginX ?? Math.round(W * 0.05);
  // Sizes (1080p: kicker 20, artist 66, title 36).
  const sc = gfxScale(cfg);
  const kick = Math.round(H * 0.0185 * sc);
  const big = Math.round(H * 0.061 * sc);
  const small = Math.round(H * 0.0335 * sc);
  const padX = Math.round(H * 0.024 * sc);
  const padBig = Math.round(big * 0.2);
  const padSmall = Math.round(small * 0.32);
  const barW = Math.max(4, Math.round(H * 0.0055));
  const gapBar = Math.round(H * 0.008);
  // Every box starts at the same left edge, right of the white bar.
  const boxX = x0 + barW + gapBar;
  const textX = boxX + padX;
  const bottom = H - tickerLayout(cfg).bar - Math.round(H * 0.045); // above the ticker
  const titleBoxH = small + 2 * padSmall;
  const artistBoxH = big + 2 * padBig;
  const yTitle = bottom - titleBoxH + padSmall;
  const yArtist = yTitle - padSmall - Math.round(H * 0.004) - artistBoxH + padBig;
  const yKick = yArtist - padBig - Math.round(H * 0.014) - kick;
  const blockTop = yArtist - padBig;
  const slide = Math.round(H * 0.045);
  const box = (pad: number) => `:box=1:boxcolor=0x0b0e17@0.85:boxborderw=${pad}|${padX}`;
  const draw = (font: string, file: string, size: number, color: string, x: number, y: number, delay: number, extra = '') => {
    const m = windowMotion(S + delay, E - delay / 2, { dx: slide });
    return `drawtext=fontfile=${filterValue(font)}:textfile=${file}:expansion=none:fontsize=${size}:fontcolor=${color}${extra}:` +
      `x='${x}+${m.x}':y=${y}:alpha='${m.alpha}':enable='${m.enable}'`;
  };
  // Long names are drawn a little smaller to fit whole; cut only if still too long.
  const room = Math.round(W * 0.74) - textX;
  // "A feat. B" too long for the artist line: the guest goes to the title line, so both read whole.
  let artistName = clip.artist || clip.title;
  let titleText = clip.artist ? clip.title : '';
  const feat = /^(.+?)\s+((?:feat\.?|ft\.?|featuring)\s+.+)$/i.exec(clip.artist ?? '');
  if (feat && textWidth(ov.fontBold, Math.round(big * 0.75), artistName) > room) {
    artistName = feat[1];
    titleText = `${clip.title} · ${feat[2]}`;
  }
  const artistFit = shrinkToFit(ov.fontBold, big, artistName, room);
  const titleFit = titleText ? shrinkToFit(ov.font, small, titleText, room, 0.65) : { text: '', size: small };
  const artist = artistFit.text;
  const title = titleFit.text;
  // The year as a tag of its own after "ORA IN ONDA", labelled so it reads as a year.
  const year = Library.yearOf(clip);
  const tagPad = Math.round(kick * 0.38);
  const kicker = plan.kicker ?? 'ORA IN ONDA';
  const tagX = textX + Math.round(textWidth(ov.fontSemiBold, kick, kicker)) + Math.round(H * 0.018) + tagPad;
  const texts = [
    draw(ov.fontSemiBold, textFile(tmpDir, plan.id, 'kicker', kicker), kick, plan.kicker ? ov.accentText : '0xe9ebf0', textX, yKick, 0,
      plan.kicker ? `:box=1:boxcolor=${ov.accent}:boxborderw=${tagPad}|${Math.round(tagPad * 1.6)}` : ''),
    ...(year
      ? [draw(ov.fontSemiBold, textFile(tmpDir, plan.id, 'year', `ANNO ${year}`), kick, 'white', tagX, yKick, 0.04,
          `:box=1:boxcolor=white@0.18:boxborderw=${tagPad}|${Math.round(tagPad * 1.6)}`)]
      : []),
    // A smaller size keeps the box the same height: the text sits in its middle.
    draw(ov.fontBold, textFile(tmpDir, plan.id, 'artist', artist), artistFit.size, 'white', textX, yArtist + Math.round((big - artistFit.size) / 2), 0.08,
      box(padBig + Math.round((big - artistFit.size) / 2))),
    ...(title ? [draw(ov.font, textFile(tmpDir, plan.id, 'title', title), titleFit.size, '0xe2e5eb', textX, yTitle + Math.round((small - titleFit.size) / 2), 0.16,
      box(padSmall + Math.round((small - titleFit.size) / 2)))] : []),
  ];
  // The white bar grows down from the top of the block.
  const barH = (title ? bottom : yArtist - padBig + artistBoxH) - blockTop;
  const grow = windowMotion(S, E, { inDur: 0.45 });
  return [
    `color=c=white:s=${barW}x${barH}:r=${fps}:d=${sec(plan.length)},format=rgba[ltbar]`,
    `[${input}][ltbar]overlay=x=${x0}:y='${blockTop}-${barH}*(1-${easeOut(ramp(S, 0.45))})':eval=frame:` +
      `enable='${grow.enable}'[ltb]`,
    `[ltb]${texts.join(',')}[${output}]`,
  ].join(';');
}

function upNext(cfg: Config, plan: ClipGfxPlan, tmpDir: string, input: string, output: string): string {
  const next = plan.upNext!;
  const T = plan.nextAt!;
  const { width: W, height: H, fps } = cfg.output;
  const ov = cfg.overlay;
  const mx = ov.logo.marginX ?? ov.logo.margin;
  const my = ov.logo.marginY ?? ov.logo.margin;
  // Under the logo, right-aligned with it: a compact card, title over artist, never wider
  // than a quarter of the screen; a long title goes on two lines.
  const top = my + Math.round(ov.logo.width * (ov.logo.ratio ?? 0.42)) + Math.round(H * 0.022);
  const sc = gfxScale(cfg);
  const kick = Math.round(H * 0.0135 * sc);
  const tSize = Math.round(H * 0.0175 * sc);
  const aSize = Math.round(H * 0.0145 * sc);
  const maxW = Math.round(W * 0.25);
  const barH = Math.max(3, Math.round(H * 0.0035));
  const padK = Math.round(kick * 0.4);
  const padX = Math.round(tSize * 0.7);
  const padY = Math.round(tSize * 0.55);
  const lead = (size: number) => Math.round(size * 1.3);
  // Shown halfway through the clip for a while, then again before the change.
  const windows: [number, number][] = [];
  const len = ov.upNext.showSeconds;
  if (T > 90) windows.push([T * 0.5, T * 0.5 + len]);
  if (T > 20) windows.push([Math.max(1, T - ov.upNext.beforeSeconds), T - 0.4]);
  if (!windows.length) return `[${input}]null[${output}]`;

  const lines: { text: string; font: string; size: number; color: string }[] = [];
  const title = next.title || next.artist;
  if (textWidth(ov.fontSemiBold, tSize, title) <= maxW) {
    lines.push({ text: title, font: ov.fontSemiBold, size: tSize, color: 'white' });
  } else {
    const small = Math.round(tSize * 0.92);
    const [l1, l2] = twoLines(ov.fontSemiBold, small, title, maxW);
    for (const l of [l1, l2].filter(Boolean)) lines.push({ text: l, font: ov.fontSemiBold, size: small, color: 'white' });
  }
  if (next.artist && next.title) {
    const a = shrinkToFit(ov.font, aSize, next.artist, maxW, 0.85);
    lines.push({ text: a.text, font: ov.font, size: a.size, color: '0xb9bec8' });
  }
  const textW = Math.max(...lines.map((l) => textWidth(l.font, l.size, l.text)));
  const boxW = Math.round((Math.ceil(textW) + 2 * padX) / 2) * 2;
  const boxH = Math.round((lines.reduce((h, l) => h + lead(l.size), 0) + 2 * padY - Math.round(lines[lines.length - 1].size * 0.3)) / 2) * 2;
  const boxX = W - mx - boxW;
  const yKick = top + padK;
  const yBox = yKick + kick + padK + Math.round(H * 0.005);
  const yBar = yBox + boxH;
  const kickFile = textFile(tmpDir, plan.id, 'next-kicker', 'A SEGUIRE');
  const lineFiles = lines.map((l, i) => textFile(tmpDir, plan.id, `next-${i}`, l.text));
  const parts: string[] = [];
  let cur = input;
  windows.forEach(([s, e], i) => {
    const m = windowMotion(s, e, { dy: Math.round(H * 0.012), inDur: 0.5, outDur: 0.4 });
    const fades = `fade=t=in:st=${sec(s)}:d=0.5:alpha=1,fade=t=out:st=${sec(e - 0.4)}:d=0.4:alpha=1`;
    // The bar shows how much is left of the song: in the last window it fills from empty to
    // full right at the change, so the end coming up reads at a glance.
    const from = i === windows.length - 1 ? s : 0;
    const fill = `clip((t-${sec(from)})/${sec(T - from)},0,1)`;
    parts.push(
      `color=c=0x0b0e17@0.82:s=${boxW}x${boxH}:r=${fps}:d=${sec(plan.length)},format=rgba,${fades}[unbox${i}]`,
      `color=c=0x3a3f4a:s=${boxW}x${barH}:r=${fps}:d=${sec(plan.length)},format=rgba[untrack${i}]`,
      `color=c=${ov.accent}:s=${boxW}x${barH}:r=${fps}:d=${sec(plan.length)},format=rgba[unfill${i}]`,
      `[untrack${i}][unfill${i}]overlay=x='-w+w*${fill}':y=0:eval=frame,format=rgba,${fades}[unbar${i}]`,
      `[${cur}][unbox${i}]overlay=x=${boxX}:y='${yBox}+${m.y}':eval=frame:enable='${m.enable}'[unx${i}]`,
      `[unx${i}][unbar${i}]overlay=x=${boxX}:y='${yBar}+${m.y}':eval=frame:enable='${m.enable}'[unb${i}]`,
    );
    const draws = [
      `drawtext=fontfile=${filterValue(ov.fontSemiBold)}:textfile=${kickFile}:expansion=none:fontsize=${kick}:fontcolor=${ov.accentText}` +
        `:box=1:boxcolor=${ov.accent}:boxborderw=${padK}|${padX}:x=${boxX + padX}:y='${yKick}+${m.y}':alpha='${m.alpha}':enable='${m.enable}'`,
    ];
    let y = yBox + padY;
    lines.forEach((l, j) => {
      draws.push(`drawtext=fontfile=${filterValue(l.font)}:textfile=${lineFiles[j]}:expansion=none:fontsize=${l.size}:fontcolor=${l.color}` +
        `:x=${boxX + padX}:y='${y}+${m.y}':alpha='${m.alpha}':enable='${m.enable}'`);
      y += lead(l.size);
    });
    parts.push(`[unb${i}]${draws.join(',')}[unt${i}]`);
    cur = `unt${i}`;
  });
  parts.push(`[${cur}]null[${output}]`);
  return parts.join(';');
}

/** A picture with transparency (PAM), for shapes drawtext and drawbox cannot draw: rounded cards, circles. */
function writePam(file: string, w: number, h: number, paint: (img: Buffer, w: number) => void) {
  if (fs.existsSync(file)) return;
  const img = Buffer.alloc(w * h * 4);
  paint(img, w);
  fs.writeFileSync(file, Buffer.concat([Buffer.from(`P7\nWIDTH ${w}\nHEIGHT ${h}\nDEPTH 4\nMAXVAL 255\nTUPLTYPE RGB_ALPHA\nENDHDR\n`), img]));
}
/** Fill a rounded rectangle (or a circle: r = half the side), edges smoothed. */
function roundRect(img: Buffer, W: number, x0: number, y0: number, w: number, h: number, r: number, [cr, cg, cb, ca]: number[]) {
  for (let y = y0; y < y0 + h; y++) {
    for (let x = x0; x < x0 + w; x++) {
      const dx = Math.max(x0 + r - x - 0.5, 0, x + 0.5 - (x0 + w - r));
      const dy = Math.max(y0 + r - y - 0.5, 0, y + 0.5 - (y0 + h - r));
      const d = Math.hypot(dx, dy);
      const cover = dx > 0 && dy > 0 ? Math.max(0, Math.min(1, r - d + 0.5)) : 1;
      if (cover <= 0) continue;
      const o = (y * W + x) * 4;
      img[o] = cr;
      img[o + 1] = cg;
      img[o + 2] = cb;
      img[o + 3] = Math.round(ca * cover);
    }
  }
}

/**
 * Televoto. Now and then the screen becomes the vote, fading in over the clip: the clip
 * blurred behind, a large QR on the left with the time left counting down, the round's songs
 * on the right as cards, each filling up with its live share of the votes (files the program
 * rewrites every few seconds). In between, a small card with the QR invites to vote.
 */
function votePanel(cfg: Config, plan: ClipGfxPlan, tmpDir: string, input: string, output: string): string {
  const v = plan.vote!;
  const { width: W, height: H, fps } = cfg.output;
  const ov = cfg.overlay;
  const gold = ov.accent.toLowerCase() === '0xffffff' ? '0xf2c14e' : ov.accent;
  const avail = H - tickerLayout(cfg).bar;
  const u = (k: number) => Math.round(H * k);
  const m = u(0.052);
  const head = u(0.037);
  const Q = Math.round(Math.min(H * 0.555, avail - m - u(0.075) - u(0.2)) / 2) * 2;
  const qrY = m + u(0.075);
  const colX = m + Q + u(0.065);
  const colW = W - m - colX;
  const n = v.songs.length;
  const gap = u(0.009);
  const rowH = Math.floor((avail - 2 * m + gap) / Math.max(1, n));
  const cardH = rowH - gap;
  const circle = Math.round(Math.min(cardH * 0.68, u(0.046)) / 2) * 2;
  const tSize = Math.min(u(0.023), Math.round(cardH * 0.3));
  const aSize = Math.round(tSize * 0.76);
  const tagSize = Math.round(tSize * 0.56);
  const pSize = Math.round(tSize * 1.12);
  const textX = colX + u(0.02) + circle + u(0.018);
  const pctW = Math.round(textWidth(ov.fontBold, pSize, '100%'));
  const textW = colX + colW - u(0.02) - pctW - u(0.02) - textX;
  const say = u(0.031);
  const small = u(0.02);
  const cdSize = u(0.028);
  // The share bar: as many letters "M" as half the share, invisible on a coloured box; 50 of
  // them span the card. Their box is as tall as a capital (0.72 of the size), padded to the card.
  const mW = textWidth(ov.fontSemiBold, 100, 'M') / 100;
  const barSize = Math.max(6, Math.floor(colW / 50 / mW));
  const barPad = Math.max(0, Math.round((cardH - barSize * 0.72) / 2));

  const cards = path.join(tmpDir, `voto-schede-${W}x${H}-${n}-${colW}-${rowH}.pam`);
  writePam(cards, colW, n * rowH, (img, w) => {
    for (let j = 0; j < n; j++) {
      roundRect(img, w, 0, j * rowH, colW, cardH, u(0.013), [27, 33, 48, 250]);
      roundRect(img, w, u(0.02), j * rowH + Math.round((cardH - circle) / 2), circle, circle, circle / 2, [42, 49, 66, 255]);
    }
  });
  const fit = (font: string, size: number, text: string, max: number) => fitWidth(font, size, text, Math.max(10, max));
  const songFiles = v.songs.map((sg, i) => {
    const tag = sg.tag ?? (sg.isNew ? 'NUOVO' : '');
    const tagW = tag ? Math.round(textWidth(ov.fontBold, tagSize, tag)) + u(0.009) : 0;
    return {
      n: textFile(tmpDir, plan.id, `vote-n${i}`, String(sg.n)),
      tag: tag ? textFile(tmpDir, plan.id, `vote-g${i}`, tag) : '',
      tagW,
      title: textFile(tmpDir, plan.id, `vote-t${i}`, fit(ov.fontSemiBold, tSize, sg.title || sg.artist, textW - tagW)),
      artist: textFile(tmpDir, plan.id, `vote-a${i}`, sg.title ? fit(ov.font, aSize, sg.artist, textW) : ' '),
    };
  });
  const files = {
    head: textFile(tmpDir, plan.id, 'vote-head', 'VOTA IL PROSSIMO BRANO'),
    say: textFile(tmpDir, plan.id, 'vote-say', fit(ov.fontBold, say, 'Inquadra il QR e scegli il numero', Q)),
    url: textFile(tmpDir, plan.id, 'vote-url', fit(ov.font, small, v.url.replace(/^https?:\/\//, ''), Q)),
    inv1: textFile(tmpDir, plan.id, 'vote-inv1', 'Scegli tu il prossimo brano'),
    inv2: textFile(tmpDir, plan.id, 'vote-inv2', `vota entro le ${v.closesAt}`),
  };
  const dt = (font: string, file: string, size: number, color: string, x: number | string, y: number | string, extra = '') =>
    `drawtext=fontfile=${filterValue(font)}:textfile=${file}:expansion=none:fontsize=${size}:fontcolor=${color}${extra}:x=${x}:y=${y}`;

  const invites = v.invites ?? [];
  const qrSplit = Math.max(1, v.windows.length + invites.length);
  const parts: string[] = [`[${v.qrInput}:v]format=rgba,split=${qrSplit}${Array.from({ length: qrSplit }, (_, i) => `[vqr${i}]`).join('')}`];
  let cur = input;
  let q = 0;

  // The invitation: a small card bottom right, above the ticker.
  const bq = u(0.11);
  const bpad = u(0.011);
  const b1 = u(0.024);
  const b2 = u(0.018);
  const bw = bq + 3 * bpad + Math.round(Math.max(textWidth(ov.fontBold, b1, 'Scegli tu il prossimo brano'), textWidth(ov.font, b2, `vota entro le ${v.closesAt}`)));
  const bh = bq + 2 * bpad;
  const bx = W - (ov.logo.marginX ?? ov.logo.margin) - bw;
  const by = avail - u(0.03) - bh;
  invites.forEach(([s, e], i) => {
    const fades = `fade=t=in:st=${sec(s)}:d=0.5:alpha=1,fade=t=out:st=${sec(e - 0.5)}:d=0.5:alpha=1`;
    const en = `enable='between(t,${sec(s)},${sec(e)})'`;
    const alpha = `alpha='clip(min((t-${sec(s)})/0.5,(${sec(e)}-t)/0.5),0,1)'`;
    parts.push(
      `color=c=0x0b0e17@0.88:s=${bw}x${bh}:r=${fps}:d=${sec(plan.length)},format=rgba,${fades}[vib${i}]`,
      `[vqr${q++}]scale=${bq}:${bq}:flags=area,${fades}[viq${i}]`,
      `[${cur}][vib${i}]overlay=x=${bx}:y=${by}:${en}[vix${i}]`,
      `[vix${i}][viq${i}]overlay=x=${bx + bpad}:y=${by + bpad}:${en}[viy${i}]`,
      `[viy${i}]${dt(ov.fontBold, files.inv1, b1, 'white', bx + bq + 2 * bpad, by + Math.round(bh / 2) - b1 - u(0.004), `:${alpha}:${en}`)},` +
        `${dt(ov.font, files.inv2, b2, gold, bx + bq + 2 * bpad, by + Math.round(bh / 2) + u(0.006), `:${alpha}:${en}`)}[viz${i}]`,
    );
    cur = `viz${i}`;
  });

  v.windows.forEach(([s, e], i) => {
    const len = e - s;
    const fades = `fade=t=in:st=0:d=0.6:alpha=1,fade=t=out:st=${sec(len - 0.6)}:d=0.6:alpha=1`;
    // Time left, counted by ffmpeg itself on the window's clock, so it matches what is on air.
    const C = (v.closesIn ?? plan.length) - s;
    const cd = path.join(tmpDir, `seg${plan.id}-vote-cd${i}.txt`);
    fs.writeFileSync(cd, `%{eif:trunc(max(0,${C.toFixed(2)}-t)/60):d}:%{eif:mod(trunc(max(0,${C.toFixed(2)}-t)),60):d:2}`);
    const cdW = Math.round(textWidth(ov.fontBold, cdSize, '00:00'));
    const barX = m + cdW + u(0.016);
    const barW = Math.max(10, m + Q - barX);
    const barH = u(0.0075);
    const cdY = qrY + Q + u(0.024) + Math.round(say * 1.55);
    const total = Math.max(1, v.roundSecs ?? 600);
    const draws = [
      dt(ov.fontBold, files.head, head, 'white', m, m),
      dt(ov.fontBold, files.say, say, 'white', m, qrY + Q + u(0.024)),
      `drawtext=fontfile=${filterValue(ov.fontBold)}:textfile=${filterValue(cd)}:expansion=normal:fontsize=${cdSize}:fontcolor=${gold}:x=${m}:y=${cdY}`,
      dt(ov.font, files.url, small, '0xa9b0bd', m, cdY + Math.round(cdSize * 1.55)),
    ];
    songFiles.forEach((f, j) => {
      const cy = m + j * rowH;
      const mid = cy + Math.round(cardH / 2);
      if (v.bars?.[j]) {
        draws.push(`drawtext=fontfile=${filterValue(ov.fontSemiBold)}:textfile=${filterValue(v.bars[j])}:reload=${fps}:expansion=none:` +
          `fontsize=${barSize}:fontcolor=white@0:box=1:boxcolor=${gold}@0.32:boxborderw=${barPad}|0:x=${colX}:y=${cy + barPad}`);
      }
      const ty = cy + Math.round(cardH * 0.2);
      draws.push(
        dt(ov.fontBold, f.n, Math.round(circle * 0.48), 'white', `${colX + u(0.02) + circle / 2}-tw/2`, `${mid}-th/2`),
        ...(f.tag ? [dt(ov.fontBold, f.tag, tagSize, gold, textX, ty + Math.round(tSize * 0.36))] : []),
        dt(ov.fontSemiBold, f.title, tSize, 'white', textX + f.tagW, ty),
        dt(ov.font, f.artist, aSize, '0xb9bec8', textX, ty + Math.round(tSize * 1.35)),
        `drawtext=fontfile=${filterValue(ov.fontBold)}:textfile=${filterValue(v.counts[j])}:reload=${fps}:expansion=none:fontsize=${pSize}:fontcolor=white:` +
          `x=${colX + colW - u(0.02)}-tw:y=${mid}-${Math.round(pSize * 0.36)}`,
      );
    });
    parts.push(
      `[${cur}]split=3[vw${i}a][vw${i}b][vw${i}c]`,
      `[vw${i}a]trim=end=${sec(s)},setpts=PTS-STARTPTS[vpre${i}]`,
      `[vw${i}b]trim=start=${sec(s)}:end=${sec(e)},setpts=PTS-STARTPTS,split[vm${i}a][vm${i}b]`,
      `[vw${i}c]trim=start=${sec(e)},setpts=PTS-STARTPTS[vpost${i}]`,
      // Behind: the clip blurred and darkened.
      `[vm${i}b]scale=${Math.round(W / 4 / 2) * 2}:${Math.round(H / 4 / 2) * 2}:flags=fast_bilinear,gblur=sigma=12,` +
        `eq=brightness=-0.3:saturation=0.7,scale=${W}:${H}:flags=fast_bilinear,format=rgba[vbg${i}]`,
      `[vqr${q++}]scale=${Q}:${Q}:flags=neighbor,setpts=PTS-STARTPTS[vqq${i}]`,
      `[vbg${i}][vqq${i}]overlay=x=${m}:y=${qrY}:eof_action=pass[vb1${i}]`,
      `movie=${filterValue(cards)},format=rgba[vcards${i}]`,
      `[vb1${i}][vcards${i}]overlay=x=${colX}:y=${m}[vb2${i}]`,
      // The countdown bar: shrinks to nothing at the close.
      `color=c=white@0.18:s=${barW}x${barH}:r=${fps}:d=${sec(len)},format=rgba[vtr${i}]`,
      `color=c=${gold}:s=${barW}x${barH}:r=${fps}:d=${sec(len)},format=rgba[vfl${i}]`,
      `[vtr${i}][vfl${i}]overlay=x='-w*(1-clip((${C.toFixed(2)}-t)/${total},0,1))':y=0:eval=frame[vcb${i}]`,
      `[vb2${i}][vcb${i}]overlay=x=${barX}:y=${cdY + Math.round((cdSize * 0.72 - barH) / 2)}[vb3${i}]`,
      `[vb3${i}]format=rgb24,${draws.join(',')},format=yuva420p,${fades}[vsc${i}]`,
      `[vm${i}a][vsc${i}]overlay=0:0[vmid${i}]`,
      `[vpre${i}][vmid${i}][vpost${i}]concat=n=3:v=1:a=0[vt${i}]`,
    );
    cur = `vt${i}`;
  });
  parts.push(`[${cur}]null[${output}]`);
  return parts.join(';');
}

/**
 * Next to the clock (drawn by the encoder on the same grid, see
 * topLeftLayout): a thin divider, the title, and "Artist · year" below it.
 * Fades in with a short rise when the clip starts, out when it ends.
 */
function nowBadge(cfg: Config, plan: ClipGfxPlan, tmpDir: string, input: string, output: string): string {
  const clip = plan.clip!;
  const { fps, width: W } = cfg.output;
  const ov = cfg.overlay;
  const T = topLeftLayout(cfg);
  const year = Library.yearOf(clip);
  const sc = gfxScale(cfg);
  const roomTop = Math.round(W * 0.55) - T.textX;
  const titleFit = shrinkToFit(ov.fontSemiBold, T.titleSize, clip.title, roomTop);
  const title = titleFit.text;
  const metaFit = shrinkToFit(ov.font, T.metaSize, [clip.artist, year].filter(Boolean).join('  ·  '), roomTop);
  const S = 0.6;
  const E = plan.length - 0.3;
  const pin = ramp(S, 0.4);
  const pout = ramp(E - 0.3, 0.3);
  const alpha = `'${pin}*(1-${pout})'`;
  const rise = (y: number) => `'${y}+8*(1-${easeOut(pin)})'`;
  const shadow = ':shadowcolor=black@0.4:shadowx=0:shadowy=2';
  return [
    `color=c=white@0.45:s=${T.sepW}x${T.sepH}:r=${fps}:d=${sec(plan.length)},format=rgba,` +
      `fade=t=in:st=${sec(S)}:d=0.4:alpha=1,fade=t=out:st=${sec(E - 0.3)}:d=0.3:alpha=1[npsep]`,
    `[${input}][npsep]overlay=x=${T.sepX}:y=${T.sepY}:eof_action=pass[nps]`,
    `[nps]drawtext=fontfile=${filterValue(ov.fontSemiBold)}:textfile=${textFile(tmpDir, plan.id, 'np', title)}:expansion=none:` +
      `fontsize=${titleFit.size}:fontcolor=white${shadow}:x=${T.textX}:y=${rise(T.titleBaseline)}:y_align=baseline:alpha=${alpha},` +
      `drawtext=fontfile=${filterValue(ov.font)}:textfile=${textFile(tmpDir, plan.id, 'npy', metaFit.text || ' ')}:expansion=none:` +
      `fontsize=${metaFit.size}:fontcolor=0xb9bec8${shadow}:x=${T.textX}:y=${rise(T.metaBaseline)}:y_align=baseline:alpha=${alpha}[${output}]`,
  ].join(';');
}

/** All clip graphics from `[input]` to `[output]`. */
export function clipGraphics(cfg: Config, plan: ClipGfxPlan, tmpDir: string, input: string, output: string): string {
  const parts: string[] = [];
  let cur = input;
  const clip = plan.clip;
  if (clip && plan.titleAt !== null && cfg.overlay.nowPlaying.enabled && Math.min(plan.length - 0.5, plan.titleAt + cfg.overlay.nowPlaying.showSeconds) - plan.titleAt >= 2) {
    parts.push(lowerThird(cfg, plan, tmpDir, cur, 'cg1'));
    cur = 'cg1';
  }
  if (clip && cfg.overlay.nowPlaying.enabled && clip.type === 'music') {
    parts.push(nowBadge(cfg, plan, tmpDir, cur, 'cg0'));
    cur = 'cg0';
  }
  if (cfg.overlay.upNext.enabled && plan.upNext && plan.nextAt) {
    parts.push(upNext(cfg, plan, tmpDir, cur, 'cg2'));
    cur = 'cg2';
  }
  // Last, so the vote screen shrinks the picture together with its graphics.
  if (plan.vote && plan.vote.qrInput !== undefined && (plan.vote.windows.length || plan.vote.invites?.length)) {
    parts.push(votePanel(cfg, plan, tmpDir, cur, 'cg3'));
    cur = 'cg3';
  }
  parts.push(`[${cur}]null[${output}]`);
  return parts.join(';');
}
