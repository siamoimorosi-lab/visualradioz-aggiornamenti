// Just enough MPEG-TS parsing to cut a decoder's output on a frame boundary.

export const TS_PACKET = 188;
/** ffmpeg's mpegts muxer gives the first stream (our video) this PID, the second (the sound) the next. */
export const VIDEO_PID = 0x100;
export const AUDIO_PID = 0x101;
/** Bytes of one MP2 frame of the decoders' sound (384 kb/s at 48 kHz) and its samples. */
const MP2_BYTES = (144 * 384000) / 48000;
const MP2_SAMPLES = 1152;

/**
 * If the packet at `off` starts a sound PES, the PTS where its sound starts and where it
 * ends, in seconds (from its length: whole MP2 frames). Otherwise null.
 */
export function audioPesSpan(buf: Buffer, off: number): { start: number; end: number } | null {
  if (buf[off] !== 0x47) return null;
  const pusi = buf[off + 1] & 0x40;
  const pid = ((buf[off + 1] & 0x1f) << 8) | buf[off + 2];
  if (!pusi || pid !== AUDIO_PID) return null;
  const afc = (buf[off + 3] >> 4) & 3;
  let p = off + 4;
  if (afc === 2) return null;
  if (afc === 3) p += 1 + buf[p];
  if (p + 14 > off + TS_PACKET) return null;
  if (buf[p] !== 0 || buf[p + 1] !== 0 || buf[p + 2] !== 1) return null;
  if (!(buf[p + 7] & 0x80)) return null;
  const length = (buf[p + 4] << 8) | buf[p + 5];
  if (!length) return null;
  const payload = length - 3 - buf[p + 8];
  const b = buf.subarray(p + 9, p + 14);
  const start = ((b[0] & 0x0e) * 2 ** 29 + b[1] * 2 ** 22 + (b[2] & 0xfe) * 2 ** 14 + b[3] * 2 ** 7 + (b[4] >> 1)) / 90000;
  return { start, end: start + (Math.round(payload / MP2_BYTES) * MP2_SAMPLES) / 48000 };
}

/**
 * If the packet at `off` starts a video PES, return its PTS in seconds,
 * otherwise null. A video PES start is where a new frame begins.
 */
export function videoPesStartPts(buf: Buffer, off: number): number | null {
  if (buf[off] !== 0x47) return null;
  const pusi = buf[off + 1] & 0x40;
  const pid = ((buf[off + 1] & 0x1f) << 8) | buf[off + 2];
  if (!pusi || pid !== VIDEO_PID) return null;
  const afc = (buf[off + 3] >> 4) & 3;
  let p = off + 4;
  if (afc === 2) return null; // adaptation field only, no payload
  if (afc === 3) p += 1 + buf[p];
  if (p + 14 > off + TS_PACKET) return null;
  if (buf[p] !== 0 || buf[p + 1] !== 0 || buf[p + 2] !== 1) return null;
  if (!(buf[p + 7] & 0x80)) return null; // no PTS
  const b = buf.subarray(p + 9, p + 14);
  const pts =
    (b[0] & 0x0e) * 2 ** 29 + b[1] * 2 ** 22 + (b[2] & 0xfe) * 2 ** 14 + b[3] * 2 ** 7 + (b[4] >> 1);
  return pts / 90000;
}
