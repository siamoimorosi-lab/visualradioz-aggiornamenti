import fs from 'node:fs';
import path from 'node:path';
import type { Config } from './config.ts';
import { resolvePath } from './config.ts';
import type { Clip } from './library.ts';
import { filterValue, sec } from './ffmpeg.ts';
import { type StingerStyle, stingerGraph, stingerInput } from './stinger.ts';
import { clipGraphics } from './clipgfx.ts';
import { squeezeWindow } from './squeeze.ts';
import { animatedLogoGraph, logoInputArgs } from './logo.ts';
import type { Card } from './cards.ts';

/**
 * One decoder run. It plays `clip` from `start` for `length` seconds and,
 * when `next` is set, crossfades into the first `next.duration` seconds of
 * the following clip during its last seconds.
 */
export interface SegmentPlan {
  id: number;
  clip: Clip | null; // null = filler slate
  start: number;
  length: number;
  fadeIn: number; // from black, seconds
  fadeOut: number; // to black, seconds
  /** duration: audio overlap; video: picture dissolve; tailFade: fade on this clip's cut tail. */
  next?: { clip: Clip; start: number; duration: number; video: number; tailFade: number; stinger?: { style: StingerStyle; logo: string } };
  /** Segment-relative time when the lower third appears, or null. */
  titleAt: number | null;
  /** The clip after this one, shown as "A seguire", and when it starts (segment time). */
  upNext?: Clip | null;
  nextAt?: number;
  card?: { files: string[]; at: number; seconds: number; progress?: Card['progress'] };
  tsOffset: number;
  /**
   * MP2 frames of sound the encoder already has beyond the picture (a clip cut on a skip
   * leaves some): this segment holds that much less sound, taken off its start, so sound
   * and picture are level again. Negative: that much silence first.
   */
  audioShift?: number;
}

const MP2_FRAME = 1152;

const even = (n: number) => Math.max(2, Math.round(n / 2) * 2);

/**
 * Picture enhancement on the output raster: contrast and saturation and an
 * unsharp mask on luma. Chosen for cost: adaptive levels (normalize) and CAS
 * sharpening each took a third of a core per stream.
 */
function videoEnhance(cfg: Config): string {
  const v = cfg.video;
  if (v.enhance === 'off') return '';
  const eq = v.contrast !== 1 || v.saturation !== 1 ? `,eq=contrast=${v.contrast}:saturation=${v.saturation}` : '';
  const sharp = v.sharpness > 0 ? `,unsharp=5:5:${v.sharpness}:5:5:0` : '';
  return eq + sharp;
}

/**
 * Clean-up of grainy or blocky clips, before scaling: light = temporal and
 * spatial denoise (hqdn3d), strong = also smoothing of compression blocks
 * (deblock). Measured on a 1080p clip: about 0.13 s and 0.28 s of CPU per
 * second of video, on top of 0.13 s for the rest of the chain; heavier filters
 * (fspp, pp7, nlmeans) cannot keep up in real time.
 */
const CLEANUP = {
  off: '',
  light: 'hqdn3d=2:1.5:4:3,',
  strong: 'deblock=filter=strong:block=8,hqdn3d=3:2:6:4,',
};

function gainDb(cfg: Config, clip: Clip): number {
  if (clip.lufs === null) return 0;
  return Math.max(-20, Math.min(cfg.audio.maxGainDb, cfg.audio.targetLufs - clip.lufs));
}

/** Normalise one input's video to the output raster, pillar/letterboxing over a blurred copy. */
/**
 * Picture that does not fill the frame: fit it, then enlarge it a little
 * (at most `video.fillZoom`, so it does not get soft) and trim what spills
 * over, so the blurred side bars get narrower.
 */
function fillZoom(cfg: Config, ar: number): string {
  const { width: W, height: H } = cfg.output;
  const [fw, fh] = ar > W / H ? [W, W / ar] : [H * ar, H];
  // No more zoom than needed to fill the frame completely.
  const z = Math.min(cfg.video.fillZoom, Math.max(W / fw, H / fh));
  const w = even(fw * z);
  const h = even(fh * z);
  const trim = w > W || h > H ? `,crop=${Math.min(w, W)}:${Math.min(h, H)}` : '';
  return `scale=${w}:${h}${trim}`;
}

/**
 * Exactly `duration` seconds of picture, whatever the file holds: a picture track that starts
 * late or ends early is filled with its first or last frame. The encoder counts frames and
 * samples, so a segment with less picture than sound moves the two apart for good.
 */
function exactVideo(fps: number, duration: number): string {
  return `,tpad=stop=-1:stop_mode=clone,trim=end_frame=${Math.round(duration * fps)},setpts=N/(${fps}*TB)`;
}

function videoChain(cfg: Config, input: number, clip: Clip, duration: number, label: string): string {
  const { width: W, height: H, fps } = cfg.output;
  const exact = exactVideo(fps, duration);
  // Cut away black bars baked into the file; the blurred fill takes their place.
  const crop = clip.crop ? `crop=${clip.crop.join(':')},` : '';
  const [cw, ch] = clip.crop ?? [clip.width, clip.height];
  const ar = cw && ch ? cw / ch : W / H;
  const enhance = videoEnhance(cfg);
  const cleanup = CLEANUP[cfg.video.cleanup] ?? '';
  if (Math.abs(ar - W / H) < 0.02) {
    return `[${input}:v:0]${crop}${cleanup}scale=${W}:${H},setsar=1,fps=${fps}:start_time=0${exact}${enhance},format=yuv420p[${label}]`;
  }
  const bw = even(W / 4);
  const bh = even(H / 4);
  return (
    `[${input}:v:0]${crop}${cleanup}fps=${fps}:start_time=0${exact},split[${label}a][${label}b];` +
    `[${label}a]scale=${bw}:${bh}:force_original_aspect_ratio=increase,crop=${bw}:${bh},` +
    `gblur=sigma=10,eq=brightness=-0.12:saturation=0.8,scale=${W}:${H}[${label}bg];` +
    `[${label}b]${fillZoom(cfg, ar)},setsar=1[${label}fg];` +
    `[${label}bg][${label}fg]overlay=(W-w)/2:(H-h)/2,setsar=1${enhance},format=yuv420p[${label}]`
  );
}

/**
 * Exactly `duration` seconds of sound: silence fills a sound track that starts late, has holes
 * or ends before the picture (common in music videos), and anything longer is cut.
 */
function audioChain(cfg: Config, input: number, clip: Clip, duration: number, label: string, start = 0): string {
  const samples = Math.round(duration * 48000);
  // Started past the end of the file's sound (a picture far longer than its sound): reading the
  // sound track would give no sound at all and hold up the whole decoder, so silence instead.
  if (!clip.hasAudio || (clip.soundEnd != null && start >= clip.soundEnd - 0.2)) return `anullsrc=r=48000:cl=stereo,atrim=end_sample=${samples}[${label}]`;
  return (
    `[${input}:a:0]aresample=48000:async=1:first_pts=0,aformat=sample_fmts=fltp:channel_layouts=stereo,` +
    `apad,atrim=end_sample=${samples},asetpts=N/SR/TB,volume=${gainDb(cfg, clip).toFixed(2)}dB[${label}]`
  );
}

export function decoderArgs(cfg: Config, plan: SegmentPlan): string[] {
  const { width: W, height: H, fps } = cfg.output;
  const tmpDir = path.join(resolvePath(cfg.dataDir), 'tmp');
  fs.mkdirSync(tmpDir, { recursive: true });
  const L = plan.length;
  const args = ['-hide_banner', '-nostdin', '-v', 'error'];
  const graph: string[] = [];

  if (!plan.clip) {
    // Filler slate: channel name on a dark background, silence.
    args.push('-f', 'lavfi', '-i', `color=c=0x10131c:s=${W}x${H}:r=${fps}:d=${sec(L)}`);
    graph.push(
      `[0:v]drawtext=fontfile=${filterValue(cfg.overlay.fontBold)}:text=${filterValue(cfg.channelName)}:` +
        `fontsize=${Math.round(H / 12)}:fontcolor=white:x=(w-tw)/2:y=(h-th)/2,format=yuv420p[v]`,
      `anullsrc=r=48000:cl=stereo,atrim=duration=${sec(L)}[a]`,
    );
  } else {
    args.push('-ss', sec(plan.start), '-t', sec(L), '-i', plan.clip.file);
    if (plan.next) args.push('-ss', sec(plan.next.start), '-t', sec(plan.next.duration), '-i', plan.next.clip.file);
    if (plan.next?.stinger) args.push(...stingerInput(cfg, plan.next.stinger.style, plan.next.stinger.logo));
    // Inputs: 0 clip, then next clip, stinger logo and card when present.
    const cardInput = plan.card ? 1 + (plan.next ? 1 : 0) + (plan.next?.stinger ? 1 : 0) : -1;
    for (const f of plan.card?.files ?? []) args.push('-loop', '1', '-framerate', String(fps), '-t', sec(plan.card!.seconds), '-i', f);

    let v = videoChain(cfg, 0, plan.clip, L, 'v0raw') + ';' + (plan.card ? squeezeWindow(cfg, plan.card.at, plan.card.seconds, cardInput, plan.card.files.length, 'v0raw', 'v0sq', plan.card.progress) + ';' : '') +
      clipGraphics(cfg, plan, tmpDir, plan.card ? 'v0sq' : 'v0raw', 'v0g') + ';[v0g]null';
    let a = audioChain(cfg, 0, plan.clip, L, 'a0raw', plan.start) + ';[a0raw]anull';
    if (plan.fadeIn > 0) {
      v += `,fade=t=in:st=0:d=${sec(plan.fadeIn)}`;
      a += `,afade=t=in:st=0:d=${sec(plan.fadeIn)}`;
    }
    if (plan.fadeOut > 0) {
      v += `,fade=t=out:st=${sec(L - plan.fadeOut)}:d=${sec(plan.fadeOut)}`;
      a += `,afade=t=out:st=${sec(L - plan.fadeOut)}:d=${sec(plan.fadeOut)}`;
    }
    if (plan.next) {
      // Segue: during the last D seconds the next clip plays at full level over
      // this clip's tail, which keeps its own fade; the picture dissolves at the
      // start of the overlap.
      const { duration: D, video: Dv, tailFade } = plan.next;
      if (tailFade > 0) a += `,afade=t=out:st=${sec(L - tailFade)}:d=${sec(tailFade)}`;
      // xfade needs both sides on the same timebase; the squeeze's trim/concat leaves 1/1000000.
      graph.push(v + `,settb=1/${fps}[v0]`, a + '[a0]');
      graph.push(videoChain(cfg, 1, plan.next.clip, D, 'v1'), audioChain(cfg, 1, plan.next.clip, D, 'a1', plan.next.start));
      if (plan.next.stinger) {
        graph.push(stingerGraph(cfg, plan.next.stinger.style, L - D, 2, 'v0', 'v1', 'v'));
      } else {
        graph.push(`[v0][v1]xfade=transition=fade:duration=${sec(Dv)}:offset=${sec(L - D)}[v]`);
      }
      graph.push(`[a0][a1]acrossfade=d=${sec(D)}:c1=nofade:c2=nofade[a]`);
    } else {
      graph.push(v + '[v]', a + '[a]');
    }
  }

  // Every segment describes its picture the same way (HD colours, TV range), whatever the
  // file said: the encoder restarts its picture clock when that description changes, and
  // from then on sound and picture carry different times.
  // An animated logo goes on top of everything the segment shows, transitions included.
  const logoArgs = logoInputArgs(cfg, plan.tsOffset, L);
  let vLast = 'v';
  if (logoArgs.length) {
    const logoInput = args.filter((a) => a === '-i').length;
    args.push(...logoArgs);
    graph.push(animatedLogoGraph(cfg, logoInput, 'v', 'vlogo'));
    vLast = 'vlogo';
  }
  graph.push(`[${vLast}]setparams=range=tv:color_primaries=bt709:color_trc=bt709:colorspace=bt709[vout]`);
  // The intermediate sound travels in frames of 1152 samples and the last one of a segment is
  // filled up, so a segment may only hold whole frames or every clip would add a few hundredths
  // of a second of sound. The count follows the timeline, so the sum over the segments stays
  // exact: each one starts at most 24 ms off its picture and the error never adds up.
  const frames = (t: number) => Math.floor((t * 48000) / MP2_FRAME + 1e-6);
  const samples = (frames(plan.tsOffset + L) - frames(plan.tsOffset)) * MP2_FRAME;
  const shift = Math.max(-200, Math.min(plan.audioShift ?? 0, samples / MP2_FRAME - 1)) * MP2_FRAME;
  if (shift > 0) graph.push(`[a]atrim=start_sample=${shift},asetpts=N/SR/TB,apad,atrim=end_sample=${samples - shift}[aout]`);
  else if (shift < 0) graph.push(`[a]adelay=delays=${-shift}S:all=1,apad,atrim=end_sample=${samples - shift}[aout]`);
  else graph.push(`[a]apad,atrim=end_sample=${samples}[aout]`);
  // No overall time limit: picture and sound are already cut to the frame and to the sample.
  args.push(
    '-filter_complex', graph.join(';'),
    '-map', '[vout]', '-map', '[aout]',
    '-color_range', 'tv', '-color_primaries', 'bt709', '-color_trc', 'bt709', '-colorspace', 'bt709',
    // Intermediate format: near-lossless and cheap to encode/decode.
    '-c:v', 'mpeg2video', '-q:v', '2', '-bf', '0', '-g', String(fps),
    '-c:a', 'mp2', '-b:a', '384k', '-ar', '48000',
    '-output_ts_offset', sec(plan.tsOffset),
    // Sound and picture strictly interleaved: when the picture is slow to start (a busy computer),
    // the sound must wait for it instead of running ahead, or the encoder starts without knowing
    // the picture and the two drift apart.
    '-max_interleave_delta', '0',
    '-f', 'mpegts', 'pipe:1',
  );
  return args;
}
