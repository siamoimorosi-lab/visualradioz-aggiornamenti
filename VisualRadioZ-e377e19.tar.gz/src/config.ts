import fs from 'node:fs';
import path from 'node:path';
import type { Preset } from './audioproc.ts';
import type { FilterCategory } from './filters.ts';

export type Transition = 'fade' | 'dip' | 'cut';

export interface TypeRule {
  transition: Transition;
  duration: number;
  /** Show the artist/title lower third; defaults to true for "music" only. */
  showTitle?: boolean;
}

export interface Config {
  channelName: string;
  output: {
    width: number;
    height: number;
    fps: number;
    videoEncoder: string;
    videoBitrate: string;
    audioBitrate: string;
    keyframeSeconds: number;
    targets: string[];
    preview: boolean;
    /** Where viewers watch the channel (HLS .m3u8): the app checks that it is really on line. */
    publicUrl?: string;
  };
  /** processing: broadcast processor on the final mix (see audioproc.ts). */
  /**
   * processing: broadcast processor preset; tuning overrides some of its values
   * (null = the preset's): loudness = output level in LUFS, compression = how hard
   * the four bands work (1 = as the preset), bass/air = boost in dB.
   */
  audio: {
    targetLufs: number; maxGainDb: number; processing: Preset;
    tuning: { loudness: number | null; compression: number | null; bassDb: number | null; airDb: number | null };
  };
  /**
   * category: optional genre/sub-group used by clock slots and breaks; defaults to the type.
   * categoryTag: take the category from this tag instead (only "album" for now), when present.
   */
  library: {
    folders: { path: string; type: string; category?: string; categoryTag?: 'album' }[];
    rescanMinutes: number;
    /** Categories made with rules on the clips' tags, usable in clock slots (see filters.ts). */
    categories: FilterCategory[];
    /** Names shown in the panel for the tags, when a tag is used for something else: { track: 'Energy' }. */
    tagNames?: Record<string, string>;
    /** Tags of the files holding the mix points as mm:ss, e.g. { start: 'composer', mixOut: 'lyricist' }. */
    cueTags?: { start?: string; mixOut?: string };
    /** true: start, end and mix point always measured on the sound, never taken from tags or Zetta. */
    measuredCues?: boolean;
    /** ZettaReload song archive (SQLite): mix points by song GUID in the file name. */
    zettaDb?: string;
  };
  /** enhance: picture clean-up applied to every clip (see segment.ts). */
  /** fillZoom: enlargement of pictures that do not fill the frame, to narrow the blurred bars (1 = off). */
  /**
   * enhance: 'off' or on ('light'/'strong' are the old presets, now the starting
   * values of contrast, saturation and sharpness); cleanup: smoothing of grainy
   * or blocky clips before scaling (see segment.ts).
   */
  video: {
    enhance: 'off' | 'light' | 'strong'; contrast: number; saturation: number; sharpness: number;
    cleanup: 'off' | 'light' | 'strong'; fillZoom: number;
  };
  types: Record<string, TypeRule>;
  rotation: {
    /** No artist may come back within this many music clips... */
    artistSeparation: number;
    /** ...nor within this many minutes. */
    artistSeparationMinutes: number;
    /** Splits multi-artist tags ("Avicii, Sandro Cavazza") so each artist is checked on its own. */
    artistSplit: string;
    titleSeparationMinutes: number;
    jingleEvery: number;
    /**
     * Rules on the clips' fields for consecutive songs: at most `max` in a row with `value`
     * in `field` ("Lingua Italiano at most 1 in a row"), or, with no value, with the same value.
     */
    sequence?: SequenceRule[];
  };
  overlay: {
    /** "auto" = the bundled Poppins fonts (assets/fonts), else a system font. */
    font: string;
    fontSemiBold: string;
    fontBold: string;
    /** Brand colour for graphics (ticker label, stinger band, kicker) and the text drawn on it. */
    accent: string;
    accentText: string;
    /** Size of every text and of the ticker bar: 1 = the original design, 1.3 = 30% larger. */
    scale: number;
    /** Logo transitions between music clips, rotating through `styles`; logoWidth as a fraction of the width. */
    stinger: { enabled: boolean; styles: string[]; logoWidth: number };
    /** marginX/marginY override margin (pixels from the right and top edges). */
    /** ratio (height/width of the visible logo) is measured at start-up, not configured. */
    /** path: a picture, or a looping video with transparency (see logo.ts). still and crop are found at start-up. */
    logo: {
      path: string; width: number; opacity: number; margin: number; marginX?: number; marginY?: number; ratio?: number;
      /** For logo transitions and the ticker: a picture of its own, or the second of an animated logo to take. */
      stillFile?: string; stillAt?: number;
      still?: string; crop?: string;
      /** An animated logo (found at start-up): drawn by each clip's decoder, `duration` seconds per loop. */
      animated?: string; duration?: number;
    };
    nowPlaying: { enabled: boolean; delaySeconds: number; showSeconds: number };
    /** "A seguire" under the logo: shown for showSeconds halfway, then the last beforeSeconds. */
    upNext: { enabled: boolean; showSeconds: number; beforeSeconds: number };
    clock: { enabled: boolean };
    /** Ticker: the text typed in the panel, then the headlines of each feed in order. */
    ticker: {
      enabled: boolean;
      text: string;
      speed: number;
      /** logo: optional file (SVG/PNG) shown instead of the label, see feedlogos.ts. */
      feeds: { url: string; label: string; logo?: string }[];
      itemsPerFeed: number;
      refreshMinutes: number;
      /** Each headline stays on screen this long. */
      seconds: number;
      /** Label shown next to the text typed in the panel. */
      label: string;
      /** Headlines per feed before moving to the next feed. */
      perBlock: number;
      /** News (the feeds) only between these times of day, "HH:MM"; both empty = all day. */
      newsFrom: string;
      newsTo: string;
    };
  };
  /** token: when set, the panel and API require it (needed if host is not 127.0.0.1). */
  /** Weather and traffic cards over clips; area = [south, west, north, east] in degrees. */
  cards: {
    enabled: boolean;
    /** Time on screen, including the moves in and out. */
    seconds: number;
    /** Size of the clip while squeezed (0.64 = 64%). */
    squeeze: number;
    /** Extra time per additional page (traffic with many events). */
    pageSeconds: number;
    /** everyMinutes: how often each card comes back (at most one card per music clip). */
    weather: { locations: { name: string; plz: string }[]; refreshMinutes: number; everyMinutes: number };
    traffic: { categories: number[]; area: [number, number, number, number]; refreshMinutes: number; everyMinutes: number };
  };
  /**
   * The programme of an event read from its web page (see events.ts): today and tomorrow in
   * the ticker under `label`, and a card with the coming main acts (`cardKinds`) and their pictures.
   */
  /** logo: shown next to the programme in the ticker; skipKinds: kinds of events left out of the ticker ('' = no kind); skipTowns: places left out of ticker and card. */
  events: { url: string; label: string; logo: string; refreshMinutes: number; card: boolean; cardEveryMinutes: number; cardKinds: string[]; skipKinds: string[]; skipTowns: string[] };
  server: { host: string; port: number; token: string };
  dataDir: string;
}

/** Default fonts per OS; "auto" in the config means "use these". */
const systemFonts: Record<string, { font: string; fontBold: string }> = {
  win32: { font: 'C:/Windows/Fonts/segoeui.ttf', fontBold: 'C:/Windows/Fonts/segoeuib.ttf' },
  darwin: {
    font: '/System/Library/Fonts/Supplemental/Arial.ttf',
    fontBold: '/System/Library/Fonts/Supplemental/Arial Bold.ttf',
  },
  linux: {
    font: '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
    fontBold: '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
  },
};

const defaults: Config = {
  channelName: 'WebTV',
  output: {
    width: 1920,
    height: 1080,
    fps: 30,
    videoEncoder: 'auto',
    videoBitrate: '6000k',
    audioBitrate: '160k',
    keyframeSeconds: 2,
    targets: [],
    preview: true,
  },
  audio: { targetLufs: -14, maxGainDb: 12, processing: 'radio', tuning: { loudness: null, compression: null, bassDb: null, airDb: null } },
  library: { folders: [], rescanMinutes: 5, categories: [] },
  video: { enhance: 'light', contrast: 1.04, saturation: 1.08, sharpness: 0.4, cleanup: 'off', fillZoom: 1.12 },
  types: {
    music: { transition: 'fade', duration: 2 },
    jingle: { transition: 'cut', duration: 0 },
  },
  rotation: { artistSeparation: 3, artistSeparationMinutes: 0, artistSplit: ',', titleSeparationMinutes: 120, jingleEvery: 3 },
  overlay: {
    font: 'auto',
    fontSemiBold: 'auto',
    fontBold: 'auto',
    accent: '0xFFFFFF',
    accentText: '0x0B0E17',
    scale: 1.3,
    stinger: { enabled: true, styles: ['pop', 'swipe', 'flash', 'slice', 'circle', 'band'], logoWidth: 0.45 },
    logo: { path: '', width: 200, opacity: 0.85, margin: 40 },
    nowPlaying: { enabled: true, delaySeconds: 1.5, showSeconds: 9 },
    upNext: { enabled: true, showSeconds: 10, beforeSeconds: 40 },
    clock: { enabled: true },
    ticker: { enabled: false, text: '', speed: 140, feeds: [], itemsPerFeed: 8, refreshMinutes: 10, seconds: 10, label: 'INFO', perBlock: 4, newsFrom: '', newsTo: '' },
  },
  cards: {
    enabled: true,
    seconds: 16,
    squeeze: 0.64,
    pageSeconds: 9,
    weather: {
      locations: [
        { name: 'Lugano', plz: '690000' },
        { name: 'Locarno', plz: '660000' },
        { name: 'Bellinzona', plz: '650000' },
      ],
      refreshMinutes: 15,
      everyMinutes: 8,
    },
    traffic: { categories: [12, 13, 21, 90], area: [45.8, 8.35, 46.75, 9.3], refreshMinutes: 3, everyMinutes: 8 },
  },
  events: { url: '', label: 'PROGRAMMA', logo: '', refreshMinutes: 30, card: true, cardEveryMinutes: 10, cardKinds: ['headliner'], skipKinds: ['resident-dj'], skipTowns: [] },
  server: { host: '127.0.0.1', port: 8080, token: '' },
  dataDir: 'data',
};

/** How much larger than the original design the on-air texts are drawn. */
export const gfxScale = (cfg: Config) => Math.min(2, Math.max(0.8, Number(cfg.overlay.scale) || 1));

function merge<T>(base: T, over: unknown): T {
  if (over === undefined || over === null) return base;
  if (typeof base !== 'object' || base === null || Array.isArray(base)) return over as T;
  const out: Record<string, unknown> = { ...(base as Record<string, unknown>) };
  for (const [k, v] of Object.entries(over as Record<string, unknown>)) {
    out[k] = merge((base as Record<string, unknown>)[k], v);
  }
  return out as T;
}

/** The program's own files (code, panel, fonts). */
export const rootDir = path.resolve(import.meta.dirname, '..');

/**
 * The station's folder: config, schedule, data. The multi-station app sets
 * WEBTV_HOME to one folder per station; run by hand it is the project root.
 */
export const homeDir = process.env.WEBTV_HOME ? path.resolve(process.env.WEBTV_HOME) : rootDir;

/**
 * Paths in the config are relative to the station's folder. Bundled assets
 * ("assets/…", e.g. the feed logos) come from the program when the station
 * has no file of its own there.
 */
export function resolvePath(p: string): string {
  if (path.isAbsolute(p)) return p;
  const own = path.join(homeDir, p);
  if (homeDir !== rootDir && /^assets[\\/]/.test(p) && !fs.existsSync(own)) return path.join(rootDir, p);
  return own;
}

/** A file shipped with the program. */
export const assetPath = (p: string) => path.join(rootDir, p);

export function loadConfig(file = process.env.WEBTV_CONFIG ?? 'config.json'): Config {
  const full = resolvePath(file);
  // Never fall back to the example: it points at other folders and outputs, and a scan
  // with it would rewrite the library.
  if (!fs.existsSync(full)) {
    throw new Error(`configurazione non trovata: ${full} (copia config.example.json in config.json)`);
  }
  const raw = JSON.parse(fs.readFileSync(full, 'utf8'));
  const cfg = merge(defaults, raw);
  // The old "strong" preset, when the file sets no values of its own.
  if (raw.video?.enhance === 'strong' && raw.video.contrast === undefined) Object.assign(cfg.video, { contrast: 1.07, saturation: 1.14, sharpness: 0.7 });
  const sys = systemFonts[process.platform] ?? systemFonts.linux;
  const bundled = (w: string) => {
    const f = assetPath(`assets/fonts/Poppins-${w}.ttf`);
    return fs.existsSync(f) ? f : null;
  };
  const ov = cfg.overlay;
  if (ov.font === 'auto') ov.font = bundled('Medium') ?? sys.font;
  if (ov.fontSemiBold === 'auto') ov.fontSemiBold = bundled('SemiBold') ?? sys.fontBold;
  if (ov.fontBold === 'auto') ov.fontBold = bundled('Bold') ?? sys.fontBold;
  fs.mkdirSync(resolvePath(cfg.dataDir), { recursive: true });
  return cfg;
}

export function typeRule(cfg: Config, type: string): TypeRule {
  return cfg.types[type] ?? cfg.types.music ?? { transition: 'cut', duration: 0 };
}

/**
 * Settings page changes: the rotation rules and how often weather and traffic
 * come back, written into the config file keeping everything else as written.
 */
export interface SequenceRule {
  field: string;
  /** Empty: the same value of the field, whatever it is. */
  value: string;
  max: number;
}

export function saveSettings(
  cfg: Config, rotation: Partial<Config['rotation']>, cards: { weatherEveryMinutes?: number; trafficEveryMinutes?: number },
  categories?: FilterCategory[],
  file = process.env.WEBTV_CONFIG ?? 'config.json',
) {
  const full = resolvePath(file);
  const text = fs.readFileSync(full, 'utf8');
  const raw = JSON.parse(text);
  raw.rotation = { ...raw.rotation, ...rotation };
  if (categories) {
    raw.library = { ...raw.library, categories };
    cfg.library.categories = categories;
  }
  raw.cards ??= {};
  for (const [key, value] of [['weather', cards.weatherEveryMinutes], ['traffic', cards.trafficEveryMinutes]] as const) {
    if (value === undefined) continue;
    raw.cards[key] = { ...raw.cards[key], everyMinutes: value };
    cfg.cards[key].everyMinutes = value;
  }
  const out = JSON.stringify(raw, null, 1) + '\n';
  fs.writeFileSync(full, text.includes('\r\n') ? out.replace(/\n/g, '\r\n') : out);
  Object.assign(cfg.rotation, rotation);
}

/** Quality page changes: video, audio and bitrate, written into the config file keeping everything else. */
export function saveQuality(
  cfg: Config, q: { video: Partial<Config['video']>; audio: Partial<Pick<Config['audio'], 'processing' | 'tuning'>>; videoBitrate?: string },
  file = process.env.WEBTV_CONFIG ?? 'config.json',
) {
  const full = resolvePath(file);
  const text = fs.readFileSync(full, 'utf8');
  const raw = JSON.parse(text);
  raw.video = { ...raw.video, ...q.video };
  raw.audio = { ...raw.audio, ...q.audio };
  if (q.videoBitrate) raw.output = { ...raw.output, videoBitrate: q.videoBitrate };
  const out = JSON.stringify(raw, null, 1) + '\n';
  fs.writeFileSync(full, text.includes('\r\n') ? out.replace(/\n/g, '\r\n') : out);
  Object.assign(cfg.video, q.video);
  Object.assign(cfg.audio, q.audio);
  if (q.videoBitrate) cfg.output.videoBitrate = q.videoBitrate;
}
