// The desktop app: one window with a tab per station, an icon next to the
// clock with the state of every station, notifications when one drops, and
// a supervisor that keeps the stations running (see stations.mjs).
//
// The program brings its own runtime/ (node, ffmpeg, ffprobe). The stations
// live in stations/<id>/ (config.json, schedule.json, data/) inside the app's
// home folder: the user's application data, or, for a portable copy on
// Windows, the folder of the exe when it already holds a stations/ folder.
import { app, BrowserWindow, Menu, Notification, Tray, dialog, ipcMain, nativeImage, shell } from 'electron';
import { execFileSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { Stations } from './stations.mjs';
import { checkOnline, findDownloaded, installUpdate, useInstalled, versionOf } from './update.mjs';
import { fileStamp } from './backup.mjs';

const APP_NAME = 'VisualRadioZ';
app.setName(APP_NAME);
const background = process.argv.includes('--background');

if (!app.requestSingleInstanceLock()) app.quit();

// boot.mjs says which code runs: an update, or the code of the installer.
const codeDir = globalThis.VRZ_CODE_DIR ?? app.getAppPath();
const bundledDir = globalThis.VRZ_BUNDLED_DIR ?? codeDir;
const updateStore = path.join(app.getPath('userData'), 'code');
/** "VisualRadioZ 0.2.0 · cb61e13", and whether it is an update over the installer. */
function versionLabel() {
  const v = versionOf(codeDir);
  return `${v.version}${v.commit ? ` · ${v.commit}` : ''}${codeDir !== bundledDir ? ' (aggiornamento)' : ''}`;
}
const windowTitle = () => `${APP_NAME} ${versionLabel()}`;
const exeDir = path.dirname(process.execPath);
const portable = app.isPackaged && process.platform === 'win32' && fs.existsSync(path.join(exeDir, 'stations'));
// From the sources: the "app-home" folder of the project.
const home = process.env.WEBTV_APP_HOME
  ?? (!app.isPackaged ? path.join(codeDir, 'app-home') : portable ? exeDir : app.getPath('userData'));
fs.mkdirSync(home, { recursive: true });
// node, ffmpeg and ffprobe: shipped with the app, else next to the stations, else from the PATH.
const runtimeDirs = [path.join(process.resourcesPath ?? '', 'runtime'), path.join(home, 'runtime'), path.join(codeDir, 'runtime')];
const bin = (name) => {
  const file = process.platform === 'win32' ? `${name}.exe` : name;
  return runtimeDirs.map((d) => path.join(d, file)).find((f) => fs.existsSync(f)) ?? name;
};
const env = { home, codeDir, node: bin('node'), ffmpeg: bin('ffmpeg'), ffprobe: bin('ffprobe') };
const stations = new Stations(env);
const icon = nativeImage.createFromPath(path.join(codeDir, 'assets', process.platform === 'win32' ? 'app.ico' : 'app.png'));
// Next to the clock: the menu bar on macOS wants a small picture.
const trayIcon = process.platform === 'darwin' ? icon.resize({ width: 18, height: 18 }) : icon;
/** Arguments for starting at login are a Windows thing; macOS says whether it was opened at login. */
const loginArgs = process.platform === 'win32' ? { args: ['--background'] } : {};

let win = null;
let tray = null;
let quitting = false;
let views = [];

function createWindow(show = true) {
  win = new BrowserWindow({
    width: 1500,
    height: 960,
    minWidth: 900,
    minHeight: 600,
    title: windowTitle(),
    icon,
    show,
    backgroundColor: '#0d1017',
    autoHideMenuBar: true,
    webPreferences: { preload: path.join(codeDir, 'manager', 'preload.cjs') },
  });
  // The title says which version runs, whatever the page says.
  win.on('page-title-updated', (e) => e.preventDefault());
  win.loadFile(path.join(codeDir, 'manager', 'ui', 'index.html'));
  win.on('close', (e) => {
    if (quitting) return;
    // Closing the window leaves the app (and the stations) running next to the clock.
    e.preventDefault();
    win.hide();
    if (!app.hiddenOnce) {
      app.hiddenOnce = true;
      notify('Continua a funzionare', 'I canali restano in onda. Riapri la finestra dall’icona vicino all’orologio.');
    }
  });
}

function showWindow() {
  if (!win) createWindow();
  win.show();
  win.focus();
}

function notify(title, body) {
  if (Notification.isSupported()) new Notification({ title, body, icon }).show();
}

const LIGHT = { green: '🟢', yellow: '🟡', red: '🔴', grey: '⚪' };

function updateTray() {
  if (!tray) return;
  const worst = ['red', 'yellow', 'green', 'grey'].find((l) => views.some((v) => v.light === l)) ?? 'grey';
  tray.setToolTip(`${APP_NAME}\n${views.map((v) => `${LIGHT[v.light]} ${v.name}: ${v.state}`).join('\n') || 'Nessuna stazione'}`);
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: `Apri ${APP_NAME}`, click: showWindow },
    { type: 'separator' },
    ...views.map((v) => ({ label: `${LIGHT[v.light]}  ${v.name} — ${v.state}`, click: () => { showWindow(); win.webContents.send('select', v.id); } })),
    { type: 'separator' },
    { label: 'Esci…', click: quitApp },
  ]));
  tray.setTitle?.(LIGHT[worst]);
}

async function quitApp() {
  const running = views.filter((v) => v.reachable);
  let stop = false;
  if (running.length) {
    const r = await dialog.showMessageBox(win?.isVisible() ? win : null, {
      type: 'question',
      title: APP_NAME,
      message: 'Chiudere il gestore?',
      detail: `${running.length} stazion${running.length > 1 ? 'i sono' : 'e è'} in onda. Possono restare in onda anche senza il gestore (che le ritrova alla riapertura), oppure fermarsi.`,
      buttons: ['Esci e lascia in onda', 'Ferma le stazioni ed esci', 'Annulla'],
      defaultId: 0,
      cancelId: 2,
    });
    if (r.response === 2) return;
    stop = r.response === 1;
  }
  if (stop) await Promise.all(stations.list.map((s) => s.close()));
  quitting = true;
  app.quit();
}

// ------------------------------------------------------------- Windows extras

/** Task Scheduler: start the app every 5 minutes in the background if it is not running. */
const TASK = `${APP_NAME} controllo`;
function watchdog(on) {
  if (process.platform !== 'win32' || !app.isPackaged) return false;
  try {
    if (on) {
      // The task asks Explorer to open a shortcut to the app instead of running it: started by
      // Task Scheduler directly, the app and the stations it launches would inherit the task's
      // low disk and memory priority (the stations then fall behind real time under load), and
      // its 3-day run limit.
      const lnk = path.join(home, `${APP_NAME} (controllo).lnk`);
      shell.writeShortcutLink(lnk, fs.existsSync(lnk) ? 'replace' : 'create', {
        target: process.execPath, args: '--background', cwd: home, description: `${APP_NAME}: avvio dal controllo periodico`,
      });
      execFileSync('schtasks', ['/Create', '/F', '/TN', TASK, '/SC', 'MINUTE', '/MO', '5',
        '/TR', `"${process.env.SystemRoot}\\explorer.exe" "${lnk}"`]);
    } else {
      execFileSync('schtasks', ['/Delete', '/F', '/TN', TASK]);
    }
  } catch {
    // not there
  }
  return watchdogOn();
}
function watchdogOn() {
  if (process.platform !== 'win32') return false;
  try {
    execFileSync('schtasks', ['/Query', '/TN', TASK], { stdio: 'ignore' });
    return true;
  } catch {
    return false;
  }
}

// --------------------------------------------------------------------- IPC

ipcMain.handle('info', () => ({
  name: APP_NAME,
  home,
  packaged: app.isPackaged,
  runtime: { node: env.node, ffmpeg: env.ffmpeg },
  platform: process.platform,
  autostart: app.getLoginItemSettings(loginArgs).openAtLogin,
  watchdog: watchdogOn(),
  stations: stations.list.map((s) => ({ id: s.id, name: s.name })),
  code: { ...versionOf(codeDir), label: versionLabel(), updated: codeDir !== bundledDir, installer: versionOf(bundledDir) },
}));

// --------------------------------------------------------- export, import, backups

ipcMain.handle('exportStation', async (_, id) => {
  const s = stations.get(id);
  if (!s) throw new Error('stazione non trovata');
  const r = await dialog.showSaveDialog(win, {
    title: `Esporta ${s.name}`,
    defaultPath: path.join(app.getPath('documents'), `${s.id}-${fileStamp().slice(0, 10)}.tar.gz`),
    filters: [{ name: 'Stazione di VisualRadioZ', extensions: ['gz'] }],
  });
  if (r.canceled || !r.filePath) return '';
  return stations.exportStation(id, r.filePath);
});
ipcMain.handle('importStation', async () => {
  const r = await dialog.showOpenDialog(win, {
    title: 'Importa una stazione',
    defaultPath: path.join(home, 'backups'),
    properties: ['openFile'],
    filters: [{ name: 'Stazione di VisualRadioZ', extensions: ['gz'] }],
  });
  if (r.canceled || !r.filePaths[0]) return null;
  const { name, tmp } = await stations.peek(r.filePaths[0]);
  // A station of the same name here: replace its settings (it is backed up first) or add a copy.
  const same = stations.list.find((s) => s.name === name);
  let replace = '';
  if (same) {
    const a = await dialog.showMessageBox(win, {
      type: 'question', buttons: ['Sostituisci le impostazioni', 'Aggiungi come stazione nuova', 'Annulla'], defaultId: 0, cancelId: 2,
      message: `C’è già una stazione “${name}”.`,
      detail: 'Sostituendo, prima viene fatto un backup della stazione attuale, poi prende le impostazioni del file. Se è in onda si riavvia.',
    });
    if (a.response === 2) {
      fs.rmSync(tmp, { recursive: true, force: true });
      return null;
    }
    if (a.response === 0) replace = same.id;
  }
  return stations.importStation(tmp, replace);
});
ipcMain.handle('backupNow', async (_, id) => {
  const s = stations.get(id);
  if (!s) throw new Error('stazione non trovata');
  return stations.backups.make(s, 'a-mano');
});
ipcMain.handle('openBackups', (_, id) => {
  const dir = id ? stations.backups.dirOf(id) : path.join(home, 'backups');
  fs.mkdirSync(dir, { recursive: true });
  return shell.openPath(dir);
});

// ------------------------------------------------------------------ updates

/**
 * Install an update file: the newest one in Downloads, after asking, or one picked by hand.
 * The stations on air restart with the new code, then the app opens again with it.
 */
ipcMain.handle('installUpdate', async () => {
  let file = findDownloaded(app.getPath('downloads'));
  if (file) {
    const r = await dialog.showMessageBox(win, {
      type: 'question', buttons: ['Installa', 'Scegli un altro file…', 'Annulla'], defaultId: 0, cancelId: 2,
      message: `Installare l’aggiornamento ${path.basename(file)}?`,
      detail: 'Le stazioni accese si riavviano con la versione nuova: la diretta si interrompe per qualche secondo.',
    });
    if (r.response === 2) return { ok: false };
    if (r.response === 1) file = '';
  }
  if (!file) {
    const r = await dialog.showOpenDialog(win, { properties: ['openFile'], defaultPath: app.getPath('downloads'), filters: [{ name: 'Aggiornamento di VisualRadioZ', extensions: ['gz'] }] });
    if (r.canceled) return { ok: false };
    file = r.filePaths[0];
  }
  const done = await installUpdate(file, bundledDir, updateStore);
  await restartWithCode(done.dir);
  return { ok: true, ...done };
});
// Every hour (and soon after start) the app looks for a new version and downloads it;
// installing waits for a click, since the stations stop for a few seconds.
let online = { state: 'none', checkedAt: 0, error: '' };
async function checkForUpdate() {
  try {
    online = { ...(await checkOnline(versionOf(codeDir), updateStore)), checkedAt: Date.now(), error: '' };
  } catch (e) {
    online = { ...online, checkedAt: Date.now(), error: String(e.message ?? e) };
  }
  win?.webContents.send('updateState', online);
  if (online.state === 'ready' && !online.notified) {
    online.notified = true;
    notify(`${APP_NAME}: aggiornamento pronto`, `Versione ${online.commit}. Apri il gestore e premi Installa quando vuoi.`);
  }
  return online;
}
if (app.isPackaged) {
  setTimeout(checkForUpdate, 60_000);
  setInterval(checkForUpdate, 3600_000);
}
ipcMain.handle('updateState', () => online);
ipcMain.handle('checkUpdate', () => checkForUpdate());
ipcMain.handle('installReady', async () => {
  if (online.state !== 'ready' || !fs.existsSync(online.file)) throw new Error('nessun aggiornamento scaricato');
  const done = await installUpdate(online.file, bundledDir, updateStore);
  await restartWithCode(done.dir);
  return { ok: true, ...done };
});
ipcMain.handle('useInstalled', async () => {
  useInstalled(updateStore);
  await restartWithCode(bundledDir);
  return true;
});

/** Stations on air go on with the code in `dir`; then the app itself opens again. */
async function restartWithCode(dir) {
  env.codeDir = dir;
  for (const s of stations.list) if (s.reachable) await s.restart();
  quitting = true;
  app.relaunch();
  app.exit(0);
}
ipcMain.handle('stations', () => views);
ipcMain.handle('start', (_, id) => stations.get(id)?.start());
ipcMain.handle('close', (_, id) => stations.get(id)?.close());
ipcMain.handle('restart', (_, id) => stations.get(id)?.restart());
ipcMain.handle('folder', (_, id) => shell.openPath(stations.get(id)?.dir ?? path.join(home, 'stations')));
ipcMain.handle('log', (_, id) => {
  const s = stations.get(id);
  return s ? shell.openPath(path.join(s.dataDir, 'run-live.log')) : '';
});
ipcMain.handle('pick', async (_, kind) => {
  const r = await dialog.showOpenDialog(win, kind === 'folder'
    ? { properties: ['openDirectory'] }
    : kind === 'db'
      ? { properties: ['openFile'], filters: [{ name: 'Archivio Zetta', extensions: ['db', 'sqlite'] }] }
      : kind === 'logo'
        ? { properties: ['openFile'], filters: [{ name: 'Logo (immagine o video con trasparenza)', extensions: ['png', 'jpg', 'jpeg', 'webp', 'mov', 'webm', 'gif', 'apng', 'mp4'] }] }
        : kind === 'feedLogo'
          ? { properties: ['openFile'], filters: [{ name: 'Logo della fonte', extensions: ['png', 'svg'] }] }
          : { properties: ['openFile'], filters: [{ name: 'Immagini', extensions: ['png', 'jpg', 'jpeg', 'webp'] }] });
  return r.canceled ? '' : r.filePaths[0];
});
ipcMain.handle('outputs', (_, id) => stations.get(id)?.outputs() ?? null);
ipcMain.handle('setOutputs', async (_, id, data) => {
  const s = stations.get(id);
  if (!s) throw new Error('canale non trovato');
  s.setOutputs(data);
  // The destinations are read when the program starts.
  if (s.reachable) await s.restart();
  return true;
});
ipcMain.handle('tags', (_, id) => stations.get(id)?.tags() ?? null);
ipcMain.handle('setTags', async (_, id, data) => {
  const s = stations.get(id);
  if (!s) throw new Error('canale non trovato');
  s.setTags(data);
  // Names and mix points are read when the program starts.
  if (s.reachable) await s.restart();
  return true;
});
// Graphics and news are read when the program starts: a running station restarts.
for (const [get, set] of [['graphics', 'setGraphics'], ['ticker', 'setTicker']]) {
  ipcMain.handle(get, (_, id) => stations.get(id)?.[get]() ?? null);
  ipcMain.handle(set, async (_, id, data) => {
    const s = stations.get(id);
    if (!s) throw new Error('canale non trovato');
    // The logo file may be open in the running program: change it with the program closed.
    await s.change(() => s[set](data));
    return true;
  });
}
ipcMain.handle('logo', async (_, id) => {
  const s = stations.get(id);
  if (!s) return false;
  const r = await dialog.showOpenDialog(win, { title: `Logo di ${s.name}`, properties: ['openFile'], filters: [{ name: 'Immagini', extensions: ['png', 'jpg', 'jpeg', 'webp'] }] });
  if (r.canceled) return false;
  // The logo is read when the program starts, and the old one may be open until then.
  await s.change(() => s.setLogo(r.filePaths[0]));
  return true;
});
ipcMain.handle('create', (_, form) => {
  const id = stations.create(form);
  if (form.startNow) stations.get(id).start();
  return id;
});
ipcMain.handle('autostart', (_, on) => {
  app.setLoginItemSettings({ openAtLogin: !!on, ...loginArgs });
  return app.getLoginItemSettings(loginArgs).openAtLogin;
});
ipcMain.handle('watchdog', (_, on) => watchdog(!!on));
ipcMain.handle('openHome', () => shell.openPath(home));

// --------------------------------------------------------------------- start

app.on('second-instance', (_e, argv) => {
  // The watchdog's periodic start finds the app already running: nothing to do.
  if (!argv.includes('--background')) showWindow();
});

app.whenReady().then(() => {
  app.setAppUserModelId(APP_NAME);
  tray = new Tray(trayIcon);
  tray.on('click', showWindow);
  stations.on('update', (v) => {
    views = v;
    updateTray();
    win?.webContents.send('update', v);
  });
  stations.on('change', (s, from, v) => {
    if (v.light === 'red') notify(`${s.name}: ${v.state}`, v.public.error || 'Controlla la stazione nel gestore.');
    else if (from === 'red' && v.light === 'green') notify(`${s.name}: di nuovo in onda`, v.onAir);
  });
  stations.on('alert', (_s, m) => notify(APP_NAME, m));
  stations.start();
  // Opened by the system at login: stay next to the clock without a window.
  const hidden = background || (process.platform === 'darwin' && app.getLoginItemSettings().wasOpenedAtLogin);
  createWindow(!hidden);
  // Checks without a person in front of the screen: a picture of the window, then quit.
  if (process.env.WEBTV_CAPTURE) {
    setTimeout(async () => {
      const img = await win.webContents.capturePage();
      fs.writeFileSync(process.env.WEBTV_CAPTURE, img.toPNG());
      quitting = true;
      app.quit();
    }, Number(process.env.WEBTV_CAPTURE_AFTER ?? 20000));
  }
});

// macOS: a click on the Dock icon brings the window back.
app.on('activate', showWindow);

app.on('window-all-closed', () => {
  // Stays next to the clock; quits only from "Esci".
});
