// Categories made with rules on the clips' tags ("Genere è Rock", "Commento
// ha la voce estate"). A category is used in a clock slot like a folder
// category; it always picks among the music clips.

export interface Rule {
  /** A tag name (genre, comment, composer…), a field found inside the comment, or artist/title/album/year/duration/file. */
  field: string;
  op: 'is' | 'not' | 'contains' | 'notContains' | 'has' | 'starts' | 'gte' | 'lte';
  value: string;
}

export interface FilterCategory {
  name: string;
  /** all: every rule must hold; any: one is enough. */
  match: 'all' | 'any';
  rules: Rule[];
}

export const RULE_OPS: Rule['op'][] = ['is', 'not', 'contains', 'notContains', 'has', 'starts', 'gte', 'lte'];

interface Tagged {
  file: string;
  artist: string;
  title: string;
  album: string;
  tagYear?: string;
  duration: number;
  tags?: Record<string, string>;
}

/** Lower case, no accents, single spaces: "Più  Lento" and "piu lento" compare equal. */
export function fold(s: unknown): string {
  return String(s ?? '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();
}

/** Tag names as written by different programs, brought to one name. */
const ALIASES: Record<string, string> = {
  date: 'year', genere: 'genre', commento: 'comment', description: 'comment', synopsis: 'comment',
  tracknumber: 'track', composer: 'composer', album_artist: 'albumartist', 'album artist': 'albumartist',
  tmpo: 'bpm', tbpm: 'bpm', grouping: 'grouping',
};

/** A comment holds several entries: one per line, or separated by ; or |. */
export function splitEntries(text: string): string[] {
  return String(text ?? '').split(/[;|\n\r]+/).map((s) => s.trim()).filter(Boolean);
}

/**
 * The single words or phrases of a value: also split on commas, slashes and
 * " + " ("Rock, Pop", "Rock/Pop", "CH Ticino + Italiano"); a list written in
 * brackets counts without them.
 */
export function parts(text: string): string[] {
  return splitEntries(text).flatMap((e) => e.split(/[,/]+|\s\+\s/))
    .map((t) => t.trim().replace(/^\(([^()]*)$/, '$1').replace(/^([^()]*)\)$/, '$1').replace(/^\(([^()]*)\)$/, '$1').trim())
    .filter(Boolean);
}

export function tokens(text: string): string[] {
  return parts(text).map(fold).filter(Boolean);
}

/**
 * Everything a rule can look at, by folded field name. Entries of the comment
 * written as "name: value" or "name=value" become fields of their own; the
 * others stay in "comment" and are found with "has" or "contains".
 */
export function fieldsOf(c: Tagged): Map<string, string> {
  const out = new Map<string, string>();
  const add = (k: string, v: unknown) => {
    const key = ALIASES[fold(k)] ?? fold(k);
    const val = String(v ?? '').trim();
    if (!key || !val) return;
    out.set(key, out.has(key) && out.get(key) !== val ? `${out.get(key)}; ${val}` : val);
  };
  for (const [k, v] of Object.entries(c.tags ?? {})) add(k, v);
  for (const entry of splitEntries(c.tags?.comment ?? c.tags?.description ?? '')) {
    const m = entry.match(/^([^:=]{1,40})[:=]\s*(.+)$/);
    if (m && !out.has(fold(m[1]))) add(m[1], m[2]);
  }
  // A comment written "(Content) ++, theme, theme": the bracket holds the contents (languages,
  // joined by " + "), the entries after it are the themes.
  // Also "(Content) + theme, theme", with the themes after a plus instead of a comma.
  const m = /^\s*\(([^()]*)\)[\s+]*[,;|]?\s*(.*)$/s.exec(c.tags?.comment ?? '');
  if (m) {
    if (m[1].trim() && !out.has('content')) out.set('content', m[1].trim());
    if (m[2]?.trim() && !out.has('temi')) out.set('temi', m[2].trim());
  }
  out.set('artist', c.artist);
  out.set('title', c.title);
  if (c.album) out.set('album', c.album);
  if (c.tagYear) out.set('year', c.tagYear);
  out.set('duration', String(Math.round(c.duration)));
  out.set('file', c.file);
  return out;
}

const number = (s: string): number | null => {
  const m = String(s).replace(',', '.').match(/-?\d+(\.\d+)?/);
  return m ? Number(m[0]) : null;
};

/** The value of a field, whatever name the panel used for it ("genere" or "genre"). */
export function fieldValue(fields: Map<string, string>, field: string): string {
  return fields.get(ALIASES[fold(field)] ?? fold(field)) ?? '';
}

export function ruleMatches(fields: Map<string, string>, r: Rule): boolean {
  const raw = fieldValue(fields, r.field);
  const have = fold(raw);
  const wanted = String(r.value).split(',').map(fold).filter(Boolean);
  // Negative rules hold for a clip without the field; the others do not.
  if (r.op === 'not') return !wanted.some((w) => tokens(raw).includes(w) || have === w);
  if (r.op === 'notContains') return !wanted.some((w) => have.includes(w));
  if (!have || !wanted.length) return false;
  switch (r.op) {
    case 'is': return wanted.some((w) => have === w || tokens(raw).includes(w));
    case 'has': return wanted.some((w) => tokens(raw).includes(w));
    case 'contains': return wanted.some((w) => have.includes(w));
    case 'starts': return wanted.some((w) => have.startsWith(w));
    case 'gte':
    case 'lte': {
      const a = number(raw);
      const b = number(r.value);
      return a !== null && b !== null && (r.op === 'gte' ? a >= b : a <= b);
    }
  }
}

export function categoryMatches(c: Tagged, cat: FilterCategory): boolean {
  if (!cat.rules.length) return false;
  const fields = fieldsOf(c);
  return cat.match === 'any' ? cat.rules.some((r) => ruleMatches(fields, r)) : cat.rules.every((r) => ruleMatches(fields, r));
}

/** Checks categories coming from the panel; throws with a message for the user. */
export function cleanCategories(input: unknown, reserved: string[] = []): FilterCategory[] {
  if (!Array.isArray(input)) return [];
  const out: FilterCategory[] = [];
  for (const c of input) {
    const name = String(c?.name ?? '').trim();
    if (!name) throw new Error('una categoria a filtri non ha il nome');
    if (reserved.includes(name)) throw new Error(`"${name}" è già il nome di una categoria delle cartelle`);
    if (out.some((x) => x.name === name)) throw new Error(`due categorie a filtri si chiamano "${name}"`);
    const rules: Rule[] = (Array.isArray(c.rules) ? c.rules : [])
      .map((r: any) => ({ field: String(r?.field ?? '').trim(), op: r?.op, value: String(r?.value ?? '').trim() }))
      .filter((r: Rule) => r.field && r.value);
    if (rules.some((r) => !RULE_OPS.includes(r.op))) throw new Error(`categoria "${name}": regola non valida`);
    if (!rules.length) throw new Error(`la categoria "${name}" non ha regole`);
    out.push({ name, match: c.match === 'any' ? 'any' : 'all', rules });
  }
  return out;
}
