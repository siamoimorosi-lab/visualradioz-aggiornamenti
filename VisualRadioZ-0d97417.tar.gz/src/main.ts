import os from 'node:os';
import { loadConfig } from './config.ts';
import { Library } from './library.ts';
import { Scheduler } from './scheduler.ts';
import { loadSchedule } from './schedule.ts';
import { AsRunLog } from './asrun.ts';
import { Engine } from './engine.ts';
import { startServer } from './server.ts';
import { Ticker } from './ticker.ts';
import { InfoCards } from './cards.ts';
import { EventProgram } from './events.ts';
import { Remote } from './remote.ts';
import { Vote } from './vote.ts';

const cfg = loadConfig();
// This process moves every frame from the decoders to the encoder: it must not wait behind
// other work. Started by Task Scheduler it would inherit a below-normal priority.
try {
  os.setPriority(os.constants.priority.PRIORITY_ABOVE_NORMAL);
} catch {
  // not allowed: keep the inherited priority
}
const lib = new Library(cfg);
const book = loadSchedule(cfg);
// Measure first the clips the clocks will actually play.
lib.priority = new Set(Object.values(book.sched.clocks).flatMap((c) => c.slots));
const sched = new Scheduler(cfg, lib, book);
const asrun = new AsRunLog(cfg);
const engine = new Engine(cfg, lib, sched, asrun);

const ticker = new Ticker(cfg);
const vote = new Vote(cfg, lib, sched);
vote.note = (m) => engine.note(m);
vote.onChange = () => engine.emit('status');
engine.setVote(vote);
sched.playlist.hold = () => vote.held();
vote.comingUp = () => engine.comingUp();
vote.queueStartsAt = () => engine.queueStartsAt();
vote.paused = () => engine.visualsOn(Date.now());
ticker.setVote(() => vote.tickerLine());
const remote = new Remote(cfg, engine, lib, sched, ticker, vote);

// The panel port first: if it is taken, another copy is already running, and this one
// must not scan the library or go on air.
try {
  await startServer({ cfg, engine, lib, sched, asrun, ticker, remote, vote });
} catch (e) {
  console.error(`porta ${cfg.server.port} già in uso: il programma è già acceso (${(e as Error).message})`);
  process.exit(1);
}

// With clips already in library.json the stream starts at once and the scan runs
// in the background; only a first run with an empty library waits for it.
if (!lib.playable().length) await lib.scan();
else lib.scan().catch((e) => console.error('scan:', e));
setInterval(() => lib.scan().catch((e) => console.error('scan:', e)), cfg.library.rescanMinutes * 60000);

ticker.setClock(() => engine.streamTime());
ticker.setDayOffset(() => engine.dayOffset());
const who = (c: { artist: string; title: string } | null | undefined) => (c ? (c.artist ? `${c.artist} – ${c.title}` : c.title) : '');
ticker.setNowPlaying(() => {
  const s = engine.status();
  // During the visuals no "now playing": the visuals have no title worth saying.
  return s.onAir?.clip && s.onAir.clip.type !== 'visual' ? { now: who(s.onAir.clip), next: s.next?.type === 'visual' ? '' : who(s.next) } : null;
});
const program = new EventProgram(cfg);
program.start();
ticker.setEvents(() => program.lines(), () => program.status());
const cards = new InfoCards(cfg);
cards.setEvents(program);
// Cards go on air for weather and traffic, and for the main acts of an event programme.
if (cfg.cards.enabled || (program.enabled && cfg.events.card)) {
  cards.start();
  engine.setCards(cards);
}
if (cfg.overlay.ticker.enabled) ticker.start();

await engine.start();
remote.start();
vote.start();

const shutdown = async () => {
  await engine.stop();
  process.exit(0);
};
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
