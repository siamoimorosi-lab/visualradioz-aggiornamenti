// Installs an update file (VisualRadioZ-aggiornamento-*.tar.gz from the release page):
// unpacked next to the earlier ones in <data>/code/<version>, checked against the
// installed engines, then made the current code (see boot.mjs).
import { execFile } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

const readJson = (f) => {
  try {
    return JSON.parse(fs.readFileSync(f, 'utf8'));
  } catch {
    return null;
  }
};

/** The installer's native modules, linked into an update's folder (a junction: no rights needed). */
export function linkModules(dir, bundled) {
  const modules = path.join(bundled, 'node_modules');
  const link = path.join(dir, 'node_modules');
  if (!fs.existsSync(modules) || fs.existsSync(path.join(link, '@resvg'))) return;
  try {
    fs.rmSync(link, { recursive: false, force: true });
  } catch {
    // not there
  }
  try {
    fs.symlinkSync(modules, link, process.platform === 'win32' ? 'junction' : 'dir');
  } catch {
    // made below by copying
  }
  if (!fs.existsSync(path.join(link, '@resvg'))) fs.cpSync(modules, link, { recursive: true });
}

/** Whether the code in `dir` can load the installer's native modules. */
export function modulesOk(dir, bundled) {
  return !fs.existsSync(path.join(bundled, 'node_modules')) || fs.existsSync(path.join(dir, 'node_modules', '@resvg'));
}

/** Run `fn`, trying again for up to ten seconds while Windows holds the files (EPERM, EBUSY). */
async function settle(fn) {
  for (let i = 0; ; i++) {
    try {
      return fn();
    } catch (e) {
      if (i >= 20 || !['EPERM', 'EBUSY', 'EACCES', 'ENOTEMPTY'].includes(e.code)) throw e;
      await new Promise((r) => setTimeout(r, 500));
    }
  }
}

/** The newest update file in the Downloads folder, or ''. */
export function findDownloaded(downloads) {
  try {
    return fs.readdirSync(downloads)
      .filter((f) => /^VisualRadioZ-aggiornamento.*\.tar\.gz$/i.test(f))
      .map((f) => path.join(downloads, f))
      .sort((a, b) => fs.statSync(b).mtimeMs - fs.statSync(a).mtimeMs)[0] ?? '';
  } catch {
    return '';
  }
}

/** What version the code in `dir` is (the commit it was built from). */
export function versionOf(dir) {
  const p = readJson(path.join(dir, 'package.json')) ?? {};
  return { version: p.version ?? '', commit: p.updateCommit ?? '', base: p.updateBase ?? '' };
}

const untar = (file, to) => new Promise((ok, fail) =>
  // tar is part of Windows 10 and later, and of macOS.
  execFile(process.platform === 'win32' ? path.join(process.env.SystemRoot ?? 'C:\\Windows', 'System32', 'tar.exe') : 'tar',
    ['-xzf', file, '-C', to], { windowsHide: true }, (e, _o, err) => (e ? fail(new Error(String(err || e.message).trim())) : ok())));

/**
 * Unpack and check `file`; returns the folder of the new code. `bundled` is the code that
 * came with the installer, `store` the folder of the updates.
 */
export async function installUpdate(file, bundled, store) {
  fs.mkdirSync(store, { recursive: true });
  const tmp = fs.mkdtempSync(path.join(store, 'nuovo-'));
  try {
    await untar(file, tmp);
    const v = versionOf(tmp);
    const base = versionOf(bundled).base;
    if (!fs.existsSync(path.join(tmp, 'manager', 'main.mjs')) || !fs.existsSync(path.join(tmp, 'src', 'main.ts'))) {
      throw new Error('il file non è un aggiornamento di VisualRadioZ');
    }
    if (!base || v.base !== base) {
      throw new Error('questo aggiornamento cambia anche i motori del programma (ffmpeg, Node o Electron): serve l’installer completo');
    }
    const name = `${v.version}-${v.commit || Date.now()}`;
    const dir = path.join(store, name);
    await settle(() => fs.rmSync(dir, { recursive: true, force: true }));
    // Windows (often its antivirus, looking at the files just unpacked) can hold the folder for a
    // moment: try again for a while, then copy it instead of moving it.
    try {
      await settle(() => fs.renameSync(tmp, dir));
    } catch {
      fs.cpSync(tmp, dir, { recursive: true });
    }
    // The native modules stay those of the installer.
    linkModules(dir, bundled);
    if (!modulesOk(dir, bundled)) throw new Error('aggiornamento incompleto (manca il collegamento ai moduli del programma): riprova');
    fs.writeFileSync(path.join(store, 'current.json'), JSON.stringify({ dir: name, at: new Date().toISOString() }));
    // Keep the last three.
    const old = fs.readdirSync(store).filter((d) => d !== name && fs.existsSync(path.join(store, d, 'package.json')))
      .sort((a, b) => fs.statSync(path.join(store, b)).mtimeMs - fs.statSync(path.join(store, a)).mtimeMs).slice(2);
    for (const d of old) {
      try {
        fs.rmSync(path.join(store, d), { recursive: true, force: true });
      } catch {
        // still in use: removed next time
      }
    }
    return { dir, ...v };
  } finally {
    try {
      fs.rmSync(tmp, { recursive: true, force: true });
    } catch {
      // held for a moment by Windows: harmless, removed with the next update
    }
  }
}

/** Back to the code of the installer. */
export function useInstalled(store) {
  fs.rmSync(path.join(store, 'current.json'), { force: true });
}


/** Where the app looks for new versions: a public repository holding only the update files. */
export const UPDATE_URL = process.env.VRZ_UPDATE_URL ?? 'https://raw.githubusercontent.com/siamoimorosi-lab/visualradioz-aggiornamenti/main/';

/**
 * Look for a newer version than `current` (see versionOf). When there is one that fits the
 * installed engines, download it into `store` and check it; returns what was found:
 * { state: 'none' } | { state: 'ready', file, version, commit, note } |
 * { state: 'installer', version, commit, note } (it needs the whole installer).
 */
export async function checkOnline(current, store) {
  const res = await fetch(`${UPDATE_URL}versione.json?t=${Date.now()}`, { signal: AbortSignal.timeout(20000), cache: 'no-store' });
  if (res.status === 404) return { state: 'none' };
  if (!res.ok) throw new Error(`controllo aggiornamenti: HTTP ${res.status}`);
  const v = await res.json();
  if (!v.commit || v.commit === current.commit) return { state: 'none' };
  const info = { version: v.version ?? '', commit: v.commit, note: v.note ?? '', date: v.date ?? '' };
  if (!current.base || v.base !== current.base) return { state: 'installer', ...info };
  fs.mkdirSync(store, { recursive: true });
  const file = path.join(store, `scaricato-${v.commit}.tar.gz`);
  if (!fs.existsSync(file)) {
    const r = await fetch(`${UPDATE_URL}${v.file}?t=${Date.now()}`, { signal: AbortSignal.timeout(120000) });
    if (!r.ok) throw new Error(`download aggiornamento: HTTP ${r.status}`);
    const data = Buffer.from(await r.arrayBuffer());
    const sum = (await import('node:crypto')).createHash('sha256').update(data).digest('hex');
    if (v.sha256 && sum !== v.sha256) throw new Error('aggiornamento scaricato ma rovinato (controllo non riuscito): riprovo più tardi');
    fs.writeFileSync(`${file}.parziale`, data);
    fs.renameSync(`${file}.parziale`, file);
    // Older downloads are no longer needed.
    for (const f of fs.readdirSync(store)) if (/^scaricato-.*\.tar\.gz$/.test(f) && path.join(store, f) !== file) fs.rmSync(path.join(store, f), { force: true });
  }
  return { state: 'ready', file, ...info };
}
