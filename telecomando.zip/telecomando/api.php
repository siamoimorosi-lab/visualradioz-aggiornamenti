<?php
// Remote control of a VisualRadioZ channel: this page only relays. The program on air calls
// it every few seconds (a=station) with what is on air and takes the commands people gave.
// People log in as admin or user with the passwords set in the program; the program sends
// only a salted hash of them and checks every command again against its own limits.
declare(strict_types=1);

const DATA = __DIR__ . '/dati';
const ONLINE_SECONDS = 20;
const ITERATIONS = 100000;
const USER_COMMANDS = ['skip', 'clock', 'clockReset', 'disable', 'report'];

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

function out($data, int $code = 200): void {
  http_response_code($code);
  echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  exit;
}

// Every data file is a .php file that stops at its first line: even on a server that ignores
// dati/.htaccess, opening it from the web shows nothing.
const GUARD = "<?php exit; ?>\n";
function data_path(string $name): string { return DATA . '/' . preg_replace('/\.json$/', '.php', $name); }
function decode(string $raw) { return json_decode(str_starts_with($raw, GUARD) ? substr($raw, strlen(GUARD)) : $raw, true); }

/** Read and change a JSON file under a lock, so the program and the people never overwrite each other. */
function with_file(string $name, callable $fn, $default = []) {
  $path = data_path($name);
  $h = fopen($path, 'c+');
  if (!$h) out(['error' => 'cartella dati non scrivibile'], 500);
  flock($h, LOCK_EX);
  $raw = stream_get_contents($h);
  $data = $raw ? decode($raw) : null;
  if ($data === null) $data = $default;
  $result = $fn($data);
  ftruncate($h, 0);
  rewind($h);
  fwrite($h, GUARD . json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
  fflush($h);
  flock($h, LOCK_UN);
  fclose($h);
  return $result;
}

function read_file(string $name, $default = []) {
  $raw = @file_get_contents(data_path($name));
  $data = $raw ? decode($raw) : null;
  return $data ?? $default;
}

function body(): array {
  $b = json_decode(file_get_contents('php://input') ?: '', true);
  return is_array($b) ? $b : [];
}

if (!is_dir(DATA)) @mkdir(DATA, 0700);
$a = $_GET['a'] ?? '';

// ------------------------------------------------------------------ the program on air
if ($a === 'station') {
  if ($_SERVER['REQUEST_METHOD'] !== 'POST') out(['error' => 'POST'], 405);
  $key = $_SERVER['HTTP_X_STATION_KEY'] ?? '';
  if (strlen($key) < 32) out(['error' => 'chiave mancante'], 403);
  // The first program that calls owns the page; to hand it to another, delete dati/chiave.php.
  $keyFile = data_path('chiave.json');
  if (!is_file($keyFile)) file_put_contents($keyFile, GUARD . json_encode(hash('sha256', $key)));
  if (!hash_equals((string)decode((string)file_get_contents($keyFile)), hash('sha256', $key))) out(['error' => 'chiave della stazione diversa da quella registrata sulla pagina'], 403);
  $b = body();
  file_put_contents(DATA . '/stato-tmp.php', GUARD . json_encode([
    'seen' => time(), 'state' => $b['state'] ?? null, 'auth' => $b['auth'] ?? null, 'limits' => $b['limits'] ?? null, 'vote' => $b['vote'] ?? null,
  ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
  rename(DATA . '/stato-tmp.php', data_path('stato.json'));
  if (!empty($b['results'])) {
    with_file('esiti.json', function (&$r) use ($b) {
      foreach ($b['results'] as $x) if (isset($x['id'])) $r[$x['id']] = ['ok' => !empty($x['ok']), 'message' => (string)($x['message'] ?? ''), 't' => time()];
      $r = array_slice($r, -200, null, true);
    });
  }
  $commands = with_file('comandi.json', function (&$c) {
    // Commands older than two minutes are dropped: nobody waits for them any more.
    $fresh = array_values(array_filter($c, fn($x) => ($x['t'] ?? 0) > time() - 120));
    $c = [];
    return $fresh;
  });
  // Televoto: the votes of the round on air, counted per song.
  $votes = null;
  $round = $b['vote']['round'] ?? null;
  if ($round && isset($round['id'])) {
    $votes = with_file('voti.json', function (&$v) use ($round) {
      if (($v['round'] ?? '') !== $round['id']) $v = ['round' => $round['id'], 'votes' => [], 'ips' => []];
      return ['round' => $round['id'], 'counts' => count_votes($v, count($round['songs'] ?? []))];
    });
  }
  out(['commands' => $commands, 'votes' => $votes]);
}

function shares(array $c): array {
  $t = array_sum($c);
  return array_map(fn($x) => $t ? (int)round(100 * $x / $t) : 0, $c);
}

function count_votes(array $v, int $n): array {
  $c = array_fill(0, max(0, $n), 0);
  foreach ($v['votes'] ?? [] as $x) if ($x >= 1 && $x <= $n) $c[$x - 1]++;
  return $c;
}

// ------------------------------------------------------------------ televoto (public, no login)
if ($a === 'round' || $a === 'vote') {
  $st = read_file('stato.json', null);
  $vote = $st['vote'] ?? null;
  $round = $vote['round'] ?? null;
  $online = time() - ($st['seen'] ?? 0) < ONLINE_SECONDS;
  $voter = $_COOKIE['vrz_voto'] ?? '';
  if (!preg_match('/^[a-f0-9]{32}$/', $voter)) {
    $voter = bin2hex(random_bytes(16));
    setcookie('vrz_voto', $voter, ['expires' => time() + 365 * 86400, 'path' => '/', 'httponly' => true, 'samesite' => 'Lax', 'secure' => !empty($_SERVER['HTTPS'])]);
  }
  $open = $online && $round && ($round['closesAt'] ?? 0) / 1000 > time();
  if ($a === 'vote') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST' || ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') !== 'vrz') out(['error' => 'richiesta non valida'], 400);
    $b = body();
    $n = (int)($b['n'] ?? 0);
    if (!$open || ($b['round'] ?? '') !== $round['id']) out(['error' => 'votazione chiusa'], 409);
    if ($n < 1 || $n > count($round['songs'])) out(['error' => 'numero non valido'], 400);
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    $err = with_file('voti.json', function (&$v) use ($round, $voter, $n, $ip) {
      if (($v['round'] ?? '') !== $round['id']) $v = ['round' => $round['id'], 'votes' => [], 'ips' => []];
      // One vote per phone (it can be changed); a generous cap per connection, for a whole
      // venue on the same wifi, against scripted voting.
      if (!isset($v['votes'][$voter])) {
        $v['ips'][$ip] = ($v['ips'][$ip] ?? 0) + 1;
        if ($v['ips'][$ip] > 400) return 'troppi voti da questa connessione';
      }
      $v['votes'][$voter] = $n;
      return '';
    });
    if ($err) out(['error' => $err], 429);
  }
  $v = read_file('voti.json');
  $mine = ($round && ($v['round'] ?? '') === $round['id']) ? ($v['votes'][$voter] ?? null) : null;
  out([
    'channel' => $vote['channel'] ?? '',
    'online' => $online,
    'open' => (bool)$open,
    'now' => (int)round(microtime(true) * 1000),
    'round' => $open ? ['id' => $round['id'], 'closesAt' => $round['closesAt'], 'songs' => array_map(fn($x) => ['n' => $x['n'], 'artist' => $x['artist'], 'title' => $x['title'], 'isNew' => !empty($x['isNew'])], $round['songs'])] : null,
    // Shares only, never counts: a handful of votes must not show.
    'shares' => ($open && ($v['round'] ?? '') === $round['id']) ? shares(count_votes($v, count($round['songs']))) : null,
    'mine' => $mine,
    'last' => isset($vote['last']['title']) ? ['artist' => $vote['last']['artist'], 'title' => $vote['last']['title'], 'at' => $vote['last']['at'],
      'share' => (int)round(100 * ($vote['last']['votes'] ?? 0) / max(1, $vote['last']['total'] ?? 1))] : null,
  ]);
}

// ------------------------------------------------------------------ people
session_name('vrz_remoto');
session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'httponly' => true, 'samesite' => 'Strict', 'secure' => !empty($_SERVER['HTTPS'])]);
session_start();
// A form on another site cannot send JSON with this header without the browser asking first.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') !== 'vrz') out(['error' => 'richiesta non valida'], 400);

if ($a === 'login') {
  $ip = $_SERVER['REMOTE_ADDR'] ?? '';
  $blocked = with_file('tentativi.json', function (&$f) use ($ip) {
    $f = array_filter($f, fn($t) => $t['t'] > time() - 900);
    return count(array_filter($f, fn($t) => $t['ip'] === $ip)) >= 10;
  });
  if ($blocked) out(['error' => 'troppi tentativi, riprova tra un quarto d’ora'], 429);
  $b = body();
  $role = ($b['role'] ?? '') === 'admin' ? 'admin' : 'user';
  $st = read_file('stato.json', null);
  $login = $st['auth'][$role] ?? null;
  $pw = (string)($b['password'] ?? '');
  if (!$login || !hash_equals((string)$login['hash'], hash_pbkdf2('sha256', $pw, (string)$login['salt'], ITERATIONS, 64))) {
    with_file('tentativi.json', function (&$f) use ($ip) { $f[] = ['ip' => $ip, 't' => time()]; });
    out(['error' => $login ? 'password errata' : ($role === 'admin' ? 'la stazione non ha ancora mandato la password' : 'accesso utente non attivo')], 401);
  }
  session_regenerate_id(true);
  $_SESSION['role'] = $role;
  $_SESSION['name'] = mb_substr(trim((string)($b['name'] ?? '')), 0, 40) ?: ($role === 'admin' ? 'admin' : 'utente');
  $_SESSION['hash'] = $login['hash'];
  out(['ok' => true, 'role' => $role]);
}

if ($a === 'logout') {
  $_SESSION = [];
  session_destroy();
  out(['ok' => true]);
}

$role = $_SESSION['role'] ?? null;
if (!$role) out(['error' => 'accesso richiesto'], 401);
$st = read_file('stato.json', null);
// A password changed in the program ends the sessions opened with the old one.
if (!$st || ($st['auth'][$role]['hash'] ?? '') !== ($_SESSION['hash'] ?? '')) {
  $_SESSION = [];
  out(['error' => 'accesso scaduto'], 401);
}

if ($a === 'state') {
  $s = $st['state'] ?? [];
  if ($role !== 'admin') {
    foreach (['log', 'health', 'search', 'disabled', 'reports', 'queue', 'breaks', 'ticker'] as $k) unset($s[$k]);
    $s['clock']['all'] = $s['clock']['user'] ?? [];
  }
  $mine = $_SESSION['cmds'] ?? [];
  $results = read_file('esiti.json');
  $done = [];
  foreach ($mine as $id) if (isset($results[$id])) $done[$id] = $results[$id];
  out(['role' => $role, 'name' => $_SESSION['name'], 'online' => time() - ($st['seen'] ?? 0) < ONLINE_SECONDS, 'seen' => $st['seen'] ?? 0, 'state' => $s, 'results' => $done]);
}

if ($a === 'cmd') {
  if ($_SERVER['REQUEST_METHOD'] !== 'POST') out(['error' => 'POST'], 405);
  $b = body();
  $type = (string)($b['type'] ?? '');
  if (!preg_match('/^[a-zA-Z]{2,20}$/', $type)) out(['error' => 'comando non valido'], 400);
  if ($role !== 'admin' && !in_array($type, USER_COMMANDS, true)) out(['error' => 'solo per l’amministratore'], 403);
  $id = bin2hex(random_bytes(8));
  $cmd = ['id' => $id, 'role' => $role, 'by' => $_SESSION['name'], 'type' => $type, 'args' => is_array($b['args'] ?? null) ? $b['args'] : [], 't' => time()];
  with_file('comandi.json', function (&$c) use ($cmd) {
    $c[] = $cmd;
    $c = array_slice($c, -50);
  });
  $_SESSION['cmds'] = array_slice(array_merge($_SESSION['cmds'] ?? [], [$id]), -30);
  out(['ok' => true, 'id' => $id]);
}

out(['error' => 'azione sconosciuta'], 404);
