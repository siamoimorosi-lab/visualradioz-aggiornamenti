import { spawn, type ChildProcess } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { EventEmitter } from 'node:events';
import { type Config, type Transition, resolvePath, rootDir, typeRule } from './config.ts';
import { FFMPEG, detectVideoEncoder, setPriority } from './ffmpeg.ts';
import { type Clip, Library } from './library.ts';
import { airTime } from './playlist.ts';
import type { Scheduler } from './scheduler.ts';
import type { AsRunLog } from './asrun.ts';
import { decoderArgs, type SegmentPlan } from './segment.ts';
import { encoderArgs, pusherArgs } from './encoder.ts';
import { prepareLogo } from './logo.ts';
import { STINGER_STYLES, type StingerStyle, stingerVideoDuration } from './stinger.ts';
import type { InfoCards, Kind as CardKind } from './cards.ts';
import { squeezeLayout } from './squeeze.ts';
import { prepareFeedLogos } from './feedlogos.ts';
import { type TickerBlock, tickerBlocks } from './graphics.ts';
import { AUDIO_PID, TS_PACKET, VIDEO_PID, audioPesSpan, pesStartPts, videoPesStartPts } from './tsparse.ts';
import { PublicCheck } from './publiccheck.ts';

/** Start the next decoder this many seconds before the current one ends. */
const PREPARE_LEAD = 8;
/** The last line of ffmpeg's messages that says something ("Last message repeated…" does not). */
const lastError = (stderr: string) => stderr.trim().split('\n').map((l) => l.trim()).filter((l) => l && !/^Last message repeated/i.test(l)).pop() ?? '';
/**
 * Pictures kept ready ahead of the encoder, in bytes (a few seconds): the clips run
 * ahead and the heavy moments (a crossfade with the logo and the title coming in) are
 * absorbed instead of leaving the encoder without pictures, which shows as a jerk.
 * Counted in bytes waiting for the encoder, not in seconds: the encoder always keeps a
 * few seconds inside it, and a limit in seconds left the two waiting for each other.
 */
/** "0.2.0 · cb61e13": the version and the commit the program was built from (see scripts/stamp.mjs). */
const PROGRAM_VERSION = (() => {
  try {
    const p = JSON.parse(fs.readFileSync(path.join(rootDir, 'package.json'), 'utf8'));
    return p.updateCommit ? `${p.version} · ${p.updateCommit}` : p.version;
  } catch {
    return '';
  }
})();
const CUSHION_BYTES = 8 * 1024 * 1024;
const FILLER_SECONDS = 10;
const SKIP_FADE = 0.5;
/** Seconds of the outgoing clip's tail kept under the next clip at a segue. */
const MIN_TAIL = 1;
const MAX_TAIL = 6;
const PUSHER_MAX_BACKLOG = 16 * 1024 * 1024;

interface Running {
  plan: SegmentPlan;
  proc: ChildProcess;
  activatedAt: number;
  /** When the next item takes the air (this clip's mix point). */
  endsAt: number;
  carry: Buffer;
  stderr: string;
  finished: boolean;
  /** PTS of the first and latest video frame forwarded, to place the next segment exactly. */
  firstPts: number | null;
  lastPts: number | null;
  /** Where the sound forwarded so far starts and ends (PTS), to level sound and picture after a cut. */
  audioFirst: number | null;
  audioEnd: number | null;
  /** Set while skipping: called at the next frame boundary with that frame's PTS. */
  cutAt: ((pts: number | null) => void) | null;
}

interface Upcoming {
  clip: Clip;
  /** Seconds after cue-in already shown by the previous segment's crossfade. */
  head: number;
  /** Fade from black at the start (after a dip, a skip or a failure). */
  fadeIn: number;
}

interface Pusher {
  target: string;
  label: string;
  proc: ChildProcess | null;
  state: 'avvio' | 'attivo' | 'riconnessione' | 'lento';
  restarts: number;
  lastError: string;
  since: number;
  /** When its backlog went over the limit (0 = keeping up). */
  slowSince: number;
}

/** An output that takes nothing for this long is stuck (the connection hangs): it is reconnected. */
const PUSHER_STUCK_MS = 20000;
/** An encoder whose time stands still for this long is stuck: it is restarted. */
const ENCODER_STUCK_MS = 30000;
/** Seconds behind the clock past which the encoder is restarted at the next clip change. */
const REALIGN_BEHIND = Number(process.env.VRZ_REALIGN_BEHIND ?? 8);
/** And not more often than this. */
const REALIGN_GAP_MS = 10 * 60000;
/** How often the state goes into the log. */
const HEALTH_EVERY_MS = 5 * 60000;

export interface ClipSummary {
  id: string;
  type: string;
  artist: string;
  title: string;
  duration: number;
}

const summary = (c: Clip | null | undefined): ClipSummary | null =>
  c ? { id: c.id, type: c.type, artist: c.artist, title: c.title, duration: c.cueOut - c.cueIn } : null;

function maskTarget(t: string): string {
  if (t === 'preview') return 'Anteprima (HLS locale)';
  const m = t.match(/^(\w+:\/\/[^/]+\/(?:[^/]+\/)?)(.*)$/);
  return m && m[2] ? `${m[1]}${'•'.repeat(6)}` : t;
}

export class Engine extends EventEmitter {
  private cfg: Config;
  private lib: Library;
  private sched: Scheduler;
  private asrun: AsRunLog;

  encoderName = '';
  private logoFile = '';
  /** A picture of the logo: the logo itself, or one frame of an animated one. */
  private get logoStill() {
    return this.logoFile && (this.cfg.overlay.logo.still ?? this.logoFile);
  }
  private tickerBlocks: TickerBlock[] = [];
  private encDayOffset = 0;

  /** Time of day (seconds) at the encoder's t = 0. */
  dayOffset() {
    return this.encDayOffset;
  }
  private stingerIndex = 0;
  private cards: InfoCards | null = null;

  setCards(cards: InfoCards) {
    this.cards = cards;
  }

  /** A card asked for from the panel, waiting for the next clip. */
  private forcedCard: CardKind | null = null;

  private renderCard(kind?: CardKind) {
    const L = squeezeLayout(this.cfg);
    return this.cards?.next(L.panelW, L.panelH, kind) ?? null;
  }

  /**
   * Show a card now: the clip on air is cut at the next frame and resumed
   * from the same point by a new decoder that carries the card. If too
   * little of the clip is left, the card goes with the next one.
   */
  forceCard(kind: CardKind): 'now' | 'next' | 'none' {
    const r = this.current;
    const seconds = this.cfg.cards.seconds;
    const elapsed = r ? Math.max(0, Date.now() - r.activatedAt) / 1000 : 0;
    const left = r ? (r.plan.nextAt ?? r.plan.length) - elapsed : 0;
    const card0 = this.renderCard(kind);
    const total = card0 ? seconds + (card0.files.length - 1) * this.cfg.cards.pageSeconds : seconds;
    if (!r || !r.plan.clip || r.plan.clip.type !== 'music' || r.cutAt || this.prepared || left < total + 12) {
      this.forcedCard = kind;
      return 'next';
    }
    const card = card0;
    if (!card) return 'none';
    const fps = this.cfg.output.fps;
    r.cutAt = (pts) => {
      r.cutAt = null;
      if (r !== this.current) return;
      const ts = this.tsAfter(r, pts);
      this.noteCut(r, ts);
      const offset = Math.round((ts - r.plan.tsOffset) * fps) / fps;
      const p = r.plan;
      const plan: SegmentPlan = {
        ...p,
        id: ++this.segId,
        start: p.start + offset,
        length: Math.round((p.length - offset) * fps) / fps,
        tsOffset: p.tsOffset + offset,
        fadeIn: 0,
        titleAt: p.titleAt !== null && p.titleAt > offset ? p.titleAt - offset : null,
        nextAt: p.nextAt !== undefined ? p.nextAt - offset : undefined,
        card: { files: card.files, at: 0.4, seconds: total, progress: card.progress },
      };
      r.finished = true; // the clip goes on: its as-run row comes from the continuation
      r.proc.kill('SIGKILL');
      this.current = null;
      const next = this.spawnSegment(plan);
      next.endsAt = r.endsAt;
      this.activate(next, r.activatedAt);
      this.note(`scheda ${kind === 'traffic' ? 'traffico' : kind === 'headliner' ? 'headliner' : 'meteo'} forzata dal pannello`);
    };
    setTimeout(() => r.cutAt?.(null), 1000);
    return 'now';
  }
  private enc: ChildProcess | null = null;
  private encStartedAt = 0;
  /** Seconds of content the encoder has consumed in this session. */
  private encTime = 0;

  /** Position on the encoder's output timeline, i.e. the `t` its filters see. */
  streamTime(): number {
    return this.enc ? this.encTime : 0;
  }
  private encStats = { fps: 0, speed: 0, bitrate: '' };
  private pushers: Pusher[] = [];

  private current: Running | null = null;
  private prepared: Running | null = null;
  private upcoming: Upcoming | null = null;
  /** A clip taken from the scheduler whose segment was discarded; reused before asking again. */
  private reserved: Clip | null = null;
  private tsCursor = 0;
  private segId = 0;
  private prepareTimer: NodeJS.Timeout | null = null;
  private waitingDrain = false;
  private stopping = false;
  startedAt = Date.now();
  log: string[] = [];

  constructor(cfg: Config, lib: Library, sched: Scheduler, asrun: AsRunLog) {
    super();
    this.cfg = cfg;
    this.lib = lib;
    this.sched = sched;
    this.asrun = asrun;
    const hhmm = (ms: number) => new Date(ms).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    sched.on('break', (o, block: Clip[]) =>
      this.note(`break "${o.rule.name}" delle ${hhmm(o.at)}: ${block.length} elementi in coda`));
    sched.on('break-empty', (o) => this.note(`break "${o.rule.name}" delle ${hhmm(o.at)} saltato: nessuno spot nella categoria "${o.rule.pool}"`));
    sched.on('break-missed', (o) => this.note(`break "${o.rule.name}" delle ${hhmm(o.at)} perso: troppo in ritardo`));
    sched.playlist.on('replanned', (min) => this.note(`playlist ripianificata: la diretta era ${min > 0 ? 'in ritardo' : 'in anticipo'} di ${Math.abs(min)} minuti sul piano`));
    sched.on('relaxed', (rule) => this.note(`regola ${rule} allentata: nessun clip disponibile che la rispetti`));
    sched.on('repeat', (c: Clip) => this.note(`ERRORE: nessun brano rispetta la distanza minima di ${this.cfg.rotation.titleSeparationMinutes} minuti tra due passaggi: ripetuto "${c.artist ? `${c.artist} - ` : ''}${c.title}" (servono più brani nella libreria)`));
    sched.on('backup', (slot, from) => this.note(`categoria "${slot}": nessun brano abbastanza riposato, preso dalla categoria di riserva "${from}"`));
    sched.on('slot-skipped', (slot) => this.note(`slot "${slot}" saltato: nessun brano abbastanza riposato né nella categoria né nella sua riserva`));
  }

  /** Wall-clock time (ms) at which content at timeline position `ts` will be on air. */
  private wallAt(ts: number): number {
    return Date.now() + (ts - this.encTime) * 1000;
  }

  private lastNote = { msg: '', at: 0, repeats: 0 };

  private note(msg: string) {
    // The same line again and again (e.g. a rule relaxed for every pick) is written once.
    const now = Date.now();
    const last = this.lastNote;
    if (msg === last.msg && now - last.at < 60000) {
      last.repeats++;
      last.at = now;
      return;
    }
    if (last.repeats) this.write(`(la riga precedente si è ripetuta altre ${last.repeats} volte)`);
    this.lastNote = { msg, at: now, repeats: 0 };
    this.write(msg);
  }

  private write(msg: string) {
    const line = `${new Date().toLocaleTimeString()}  ${msg}`;
    this.log.push(line);
    this.log = this.log.slice(-100);
    console.log(line);
    this.emit('status');
  }

  /** True while on air (between start() and stop()). */
  running = false;

  async start() {
    if (this.running) return;
    this.running = true;
    this.stopping = false;
    this.startedAt = Date.now();
    this.pushers = [];
    this.tsCursor = 0;
    this.writtenTs = 0;
    this.audioDebt = 0;
    // A wait for the old encoder's drain would never end: the new one starts empty.
    this.waitingDrain = false;
    const want = this.cfg.output.videoEncoder;
    this.encoderName = want === 'auto' ? await detectVideoEncoder() : want;
    this.note(`encoder video: ${this.encoderName}`);
    this.logoFile = await prepareLogo(this.cfg);
    if (this.cfg.overlay.ticker.enabled) {
      this.tickerBlocks = tickerBlocks(this.cfg, await prepareFeedLogos(this.cfg), this.logoStill);
    }
    const targets = [...this.cfg.output.targets];
    if (this.cfg.output.preview) targets.push('preview');
    for (const t of targets) {
      const p: Pusher = { target: t, label: maskTarget(t), proc: null, state: 'avvio', restarts: 0, lastError: '', since: Date.now(), slowSince: 0 };
      this.pushers.push(p);
      this.startPusher(p);
    }
    this.startEncoder();
    this.activate(this.spawnSegment(this.planNext()));
    this.watch();
    this.publicCheck = new PublicCheck(this.cfg.output.publicUrl ?? '', (m) => this.note(m), (why) => this.reconnectOutputs(why));
    this.publicCheck.start();
  }

  /**
   * Go off air: every ffmpeg is stopped; clips taken from the playlist but not
   * aired go back to its head, so start() continues the sequence.
   */
  async stop() {
    if (!this.running) return;
    this.running = false;
    this.stopping = true;
    if (this.prepareTimer) clearTimeout(this.prepareTimer);
    if (this.watchTimer) clearInterval(this.watchTimer);
    this.watchTimer = null;
    if (this.cushionTimer) clearInterval(this.cushionTimer);
    this.cushionTimer = null;
    this.publicCheck?.stop();
    if (this.current) this.finish(this.current, 'interrotto', this.encTime);
    const back = [this.prepared?.plan.clip, this.upcoming?.clip, this.reserved].filter((c): c is Clip => !!c);
    this.sched.playlist.putBack(back);
    const procs = [this.current?.proc, this.prepared?.proc, this.enc, ...this.pushers.map((p) => p.proc)]
      .filter((p): p is ChildProcess => !!p && p.exitCode === null);
    const exited = procs.map((p) => new Promise<void>((done) => {
      p.once('close', () => done());
      setTimeout(done, 3000);
    }));
    for (const p of procs) p.kill('SIGKILL');
    await Promise.all(exited);
    this.current = this.prepared = this.upcoming = this.airing = null;
    this.reserved = null;
    this.enc = null;
    this.encTime = 0;
    this.pushers = [];
    this.note('diretta spenta');
  }

  // ---------------------------------------------------------------- planning

  private transitionBetween(a: Clip, b: Clip): { kind: Transition; duration: number } {
    const ra = typeRule(this.cfg, a.type);
    const rb = typeRule(this.cfg, b.type);
    const rank = { fade: 0, dip: 1, cut: 2 } as const;
    const kind = rank[ra.transition] >= rank[rb.transition] ? ra.transition : rb.transition;
    const durations = [ra.duration, rb.duration].filter((d) => d > 0);
    const duration = durations.length ? Math.min(...durations) : 0;
    return duration > 0 ? { kind, duration } : { kind: 'cut', duration: 0 };
  }

  /** Next stinger style in rotation, when stingers are on and the overlap leaves room for one. */
  private nextStinger(overlap: number): { style: StingerStyle; logo: string } | undefined {
    const st = this.cfg.overlay.stinger;
    const styles = st.styles.filter((s): s is StingerStyle => (STINGER_STYLES as string[]).includes(s));
    if (!st.enabled || !this.logoFile || !styles.length) return undefined;
    const style = styles[this.stingerIndex++ % styles.length];
    return overlap >= stingerVideoDuration(style) ? { style, logo: this.logoStill } : undefined;
  }

  private showTitle(c: Clip): boolean {
    return typeRule(this.cfg, c.type).showTitle ?? c.type === 'music';
  }

  /** Build the next segment and advance the timestamp cursor. */
  private planNext(): SegmentPlan {
    const fps = this.cfg.output.fps;
    const id = ++this.segId;
    let up = this.upcoming;
    if (!up) {
      const locked = this.current?.plan.clip ? [this.current.plan.clip] : [];
      const c = this.reserved ?? this.sched.next(locked, this.wallAt(this.tsCursor));
      this.reserved = null;
      up = c ? { clip: c, head: 0, fadeIn: SKIP_FADE } : null;
    }
    if (!up) {
      const plan: SegmentPlan = { id, clip: null, start: 0, length: FILLER_SECONDS, fadeIn: 0.5, fadeOut: 0, titleAt: null, tsOffset: this.tsCursor };
      this.tsCursor += FILLER_SECONDS;
      this.upcoming = null;
      return plan;
    }
    const clip = up.clip;
    const start = clip.cueIn + up.head;
    let length = Math.round((clip.cueOut - start) * fps) / fps;
    // A hard break inside this clip cuts it short, with a fade, exactly at the break time.
    const startsAt = this.wallAt(this.tsCursor);
    const hard = this.sched.hardBreakBetween(startsAt, startsAt + length * 1000);
    const cutLength = hard === null ? length : Math.round(((hard - startsAt) / 1000) * fps) / fps;
    const truncated = cutLength < length - 1 / fps && cutLength > 1;
    if (truncated) length = cutLength;
    // Segue: the next clip starts at this clip's mix point, while its tail keeps fading underneath.
    const mix = Math.min(start + length, Math.max(start + 1, clip.mixOut));
    const tailEnd = Math.min(clip.duration, Math.max(mix + MIN_TAIL, Math.min(clip.cueOut, mix + MAX_TAIL)));
    const followingAt = truncated ? hard! : startsAt + (mix - start) * 1000;
    const following = this.reserved ?? this.sched.next([clip], followingAt);
    this.reserved = null;

    const plan: SegmentPlan = { id, clip, start, length, fadeIn: up.fadeIn, fadeOut: 0, titleAt: null, tsOffset: this.tsCursor };
    this.upcoming = null;
    if (truncated) {
      plan.fadeOut = Math.min(1, length / 3);
      if (following) this.upcoming = { clip: following, head: 0, fadeIn: SKIP_FADE };
      this.note(`${clip.title} accorciato di ${(clip.cueOut - start - length).toFixed(1)}s per un break a orario fisso`);
    } else if (following) {
      const t = this.transitionBetween(clip, following);
      const nextLen = following.cueOut - following.cueIn;
      if (t.kind === 'fade') {
        const segueLength = Math.round((tailEnd - start) * fps) / fps;
        const overlap = Math.round(Math.min(tailEnd - mix, nextLen / 2, segueLength / 2) * fps) / fps;
        if (overlap > 0.1) {
          length = segueLength;
          plan.length = length;
          const stinger = this.nextStinger(overlap);
          plan.next = {
            clip: following, start: following.cueIn, duration: overlap,
            video: stinger ? stingerVideoDuration(stinger.style) : Math.min(t.duration, overlap),
            stinger,
            // Cutting the tail before it has faded by itself: fade its last part.
            tailFade: tailEnd < clip.cueOut - 0.5 ? Math.min(1.5, overlap) : 0,
          };
          this.upcoming = { clip: following, head: overlap, fadeIn: 0 };
        }
      } else if (t.kind === 'dip') {
        plan.fadeOut = Math.min(t.duration / 2, length / 3);
        this.upcoming = { clip: following, head: 0, fadeIn: t.duration / 2 };
      }
      this.upcoming ??= { clip: following, head: 0, fadeIn: 0 };
    }
    plan.fadeIn = Math.min(plan.fadeIn, length / 3);
    if (following?.type === 'music' && !truncated) {
      plan.upNext = following;
      plan.nextAt = plan.next ? plan.length - plan.next.duration : plan.length;
    }
    // One info card per music clip, after the lower third and well before the change
    // (or right away when one was asked for from the panel).
    const forced = this.forcedCard;
    const cardSeconds = this.cfg.cards.seconds; // the longest a multi-page card may take is checked below
    const cardAt = forced ? 1.5 : Math.max(
      (plan.titleAt ?? 0) + this.cfg.overlay.nowPlaying.showSeconds + 4,
      plan.length * 0.3,
    );
    if (this.cards && clip.type === 'music' && cardAt + cardSeconds < (plan.nextAt ?? plan.length) - 5) {
      const card = this.renderCard(forced ?? undefined);
      // Extra pages take extra time, as long as the clip leaves room for them.
      const room = (plan.nextAt ?? plan.length) - 5 - cardAt;
      const pages = card ? Math.min(card.files.length, 1 + Math.floor((room - cardSeconds) / this.cfg.cards.pageSeconds)) : 0;
      if (card && pages > 0) {
        plan.card = {
          files: card.files.slice(0, pages), at: cardAt, seconds: cardSeconds + (pages - 1) * this.cfg.cards.pageSeconds,
          progress: pages > 1 && card.progress ? card.progress : undefined,
        };
        if (forced) this.forcedCard = null;
      }
    }
    if (this.showTitle(clip)) {
      plan.titleAt = up.head > 0 ? 0.8 : plan.fadeIn + this.cfg.overlay.nowPlaying.delaySeconds;
    }
    this.tsCursor += length;
    return plan;
  }

  // ---------------------------------------------------------------- decoders

  /** MP2 frames of sound the encoder has beyond the picture, left by cut clips; the next segment levels them. */
  private audioDebt = 0;

  /**
   * After `r` is cut with its picture ending at timeline `cutTs`: how much sound went to the
   * encoder beyond that, in MP2 frames, added to what the next segment takes off.
   */
  private noteCut(r: Running, cutTs: number) {
    const frames = (t: number) => Math.floor((t * 48000) / 1152 + 1e-6);
    const sent = r.audioFirst !== null && r.audioEnd !== null ? Math.round(((r.audioEnd - r.audioFirst) * 48000) / 1152) : 0;
    this.audioDebt += frames(r.plan.tsOffset) + (r.plan.audioShift ?? 0) + sent - frames(cutTs);
  }

  private driftFixedAt = 0;

  private spawnSegment(plan: SegmentPlan): Running {
    // Sound drifting from the picture in the output (some ffmpeg builds lose sound at every
    // clip change): this segment takes the gap back, silence when the sound is behind, a cut
    // when it is ahead. Once per 30 s at most, so a correction is seen before the next one.
    if (Math.abs(this.avDrift) > 0.25 && Date.now() - this.driftFixedAt > 30000 && this.encTime > 20) {
      const frames = Math.round((this.avDrift * 48000) / 1152);
      this.audioDebt += frames;
      this.driftFixedAt = Date.now();
      this.note(`audio ${this.avDrift < 0 ? 'indietro' : 'avanti'} di ${Math.round(Math.abs(this.avDrift) * 1000)} ms rispetto al video: riallineato al cambio brano`);
    }
    if (this.audioDebt) {
      plan.audioShift = (plan.audioShift ?? 0) + this.audioDebt;
      this.audioDebt = 0;
    }
    const proc = spawn(FFMPEG, decoderArgs(this.cfg, plan), { windowsHide: true });
    setPriority(proc, 'onAir');
    const r: Running = {
      plan, proc, activatedAt: 0, endsAt: 0, carry: Buffer.alloc(0), stderr: '', finished: false,
      firstPts: null, lastPts: null, cutAt: null, audioFirst: null, audioEnd: null,
    };
    proc.stdout!.pause();
    proc.stderr!.on('data', (d) => (r.stderr = (r.stderr + d).slice(-8000)));
    proc.on('error', (e) => (r.stderr += String(e)));
    proc.on('close', (code) => this.onSegmentClosed(r, code));
    return r;
  }

  /** `continuing` = the start time of a clip already on air, resumed by this segment. */
  /** Seconds behind the clock waiting for the next clip change to restart the encoder (0: none). */
  private realignPending = 0;
  private realignedAt = 0;

  private activate(r: Running, continuing?: number) {
    // The clip handed over until now is still on screen until the new one airs (pictures are kept ready ahead).
    this.airing = this.current && this.current !== r ? this.current : this.airing;
    this.current = r;
    const c = r.plan.clip;
    if (continuing !== undefined) {
      r.activatedAt = continuing;
    } else {
      // The encoder still has a few seconds queued: this segment airs when the timeline reaches it.
      r.activatedAt = Math.max(Date.now(), this.wallAt(r.plan.tsOffset));
      r.endsAt = r.activatedAt + (r.plan.next ? r.plan.length - r.plan.next.duration : r.plan.length) * 1000;
      if (c) this.sched.markPlayed(c, r.activatedAt);
      const msg = c ? `in onda: ${c.artist ? c.artist + ' - ' : ''}${c.title}` : 'in onda: riempitivo';
      setTimeout(() => this.running && this.note(msg), Math.max(0, r.activatedAt - Date.now()));
    }
    r.proc.stdout!.on('data', (chunk: Buffer) => this.forward(r, chunk));
    if (this.realignPending && continuing === undefined && this.enc && !this.encoderRestart) {
      const behind = this.realignPending;
      this.realignPending = 0;
      this.realignedAt = Date.now();
      this.restartEncoder(`ritardo sull'orologio di ${behind.toFixed(1)} s: encoder riavviato al cambio brano per riallinearlo (le uscite restano collegate)`);
      return;
    }
    if (!this.waitingDrain) r.proc.stdout!.resume();
    if (this.prepareTimer) clearTimeout(this.prepareTimer);
    const wait = Math.max(0, (r.plan.length - PREPARE_LEAD) * 1000);
    this.prepareTimer = setTimeout(() => this.prepare(), wait);
  }

  private prepare() {
    if (this.prepared || this.stopping) return;
    this.prepared = this.spawnSegment(this.planNext());
    this.emit('status');
  }

  /** Copy decoder output to the encoder in whole TS packets, honouring back-pressure. */
  private forward(r: Running, chunk: Buffer) {
    if (r !== this.current || !this.enc) return;
    const buf = r.carry.length ? Buffer.concat([r.carry, chunk]) : chunk;
    let n = buf.length - (buf.length % TS_PACKET);
    r.carry = buf.subarray(n);
    let cutPts: number | null | undefined;
    for (let off = 0; off < n; off += TS_PACKET) {
      const pts = videoPesStartPts(buf, off);
      if (pts === null) {
        const a = audioPesSpan(buf, off);
        if (a) {
          r.audioFirst ??= a.start;
          r.audioEnd = Math.max(r.audioEnd ?? 0, a.end);
        }
        continue;
      }
      if (r.cutAt) {
        // Stop right before this frame so the encoder never gets a partial picture.
        n = off;
        cutPts = pts;
        break;
      }
      r.firstPts ??= pts;
      r.lastPts = pts;
    }
    if (r.firstPts !== null && r.lastPts !== null) this.writtenTs = r.plan.tsOffset + (r.lastPts - r.firstPts) + 1 / this.cfg.output.fps;
    const stdin = this.enc.stdin!;
    if (n > 0) stdin.write(buf.subarray(0, n));
    if (!this.waitingDrain && stdin.writableLength > CUSHION_BYTES) {
      // Enough ready: the clip waits until the encoder has taken all of it.
      this.waitingDrain = true;
      r.proc.stdout!.pause();
      stdin.once('drain', () => {
        this.waitingDrain = false;
        this.current?.proc.stdout!.resume();
      });
    }
    if (cutPts !== undefined) r.cutAt!(cutPts);
  }

  /** Timeline position just after the last frame handed to the encoder. */
  private writtenTs = 0;

  /** Seconds of picture handed to the encoder and not yet out of it. */
  private ahead(): number {
    return this.writtenTs - this.encTime;
  }

  /** Timeline position just after the last frame of `r` that reached the encoder. */
  private tsAfter(r: Running, pts: number | null = null): number {
    if (r.firstPts === null) return this.encTime + 0.3;
    const end = pts ?? (r.lastPts ?? r.firstPts) + 1 / this.cfg.output.fps;
    return r.plan.tsOffset + (end - r.firstPts);
  }

  /** Write the as-run row; `endTs` is where the segment left the timeline (default: its planned end). */
  private finish(r: Running, outcome: string, endTs = r.plan.tsOffset + r.plan.length) {
    if (r.finished) return;
    r.finished = true;
    const end = Math.max(r.activatedAt, this.wallAt(endTs));
    if (r.plan.clip && r.activatedAt) this.asrun.write(r.plan.clip, r.activatedAt, end, outcome);
  }

  private onSegmentClosed(r: Running, code: number | null) {
    if (this.stopping) return;
    if (r === this.current) {
      if (code === 0) {
        this.finish(r, 'ok');
        this.airing = r;
        this.current = null;
        if (this.prepared) {
          const next = this.prepared;
          this.prepared = null;
          this.activate(next);
        } else {
          this.activate(this.spawnSegment(this.planNext()));
        }
      } else {
        // Without an ffmpeg message the decoder was killed from outside (e.g. shutdown).
        const msg = lastError(r.stderr);
        if (msg) this.logError(r);
        this.note(msg ? `errore in riproduzione: ${msg}` : `decoder interrotto (codice ${code})`);
        const at = this.tsAfter(r);
        this.finish(r, msg ? 'errore' : 'interrotto', at);
        this.current = null;
        this.flagFailure(r);
        // Cut short like a skip: level the sound it sent beyond its last picture.
        this.noteCut(r, at);
        this.recover(at);
      }
    } else if (r === this.prepared && code !== 0) {
      // The prepared clip cannot be played: undo its plan and plan again from the clip after it.
      this.note(`clip non riproducibile, salto: ${r.plan.clip?.title} (${lastError(r.stderr)})`);
      if (r.stderr.trim()) this.logError(r);
      this.prepared = null;
      this.flagFailure(r);
      this.tsCursor -= r.plan.length;
      if (this.upcoming) this.upcoming = { ...this.upcoming, head: 0, fadeIn: SKIP_FADE };
      this.prepare();
    }
    this.emit('status');
  }

  /** Full ffmpeg output of a failed decoder, for diagnosis (the event log keeps one line). */
  private logError(r: Running) {
    const file = path.join(resolvePath(this.cfg.dataDir), 'errors.log');
    const head = `\n=== ${new Date().toISOString()} ${r.plan.clip?.file ?? 'riempitivo'}\n`;
    try {
      fs.appendFileSync(file, head + r.stderr.slice(-6000) + '\n');
    } catch {
      // diagnostics only
    }
  }

  private failures = new Map<string, number>();

  /** Two real ffmpeg failures take a clip out of rotation until its file changes. */
  private flagFailure(r: Running) {
    const clip = r.plan.clip;
    // No ffmpeg message means the process was killed from outside (e.g. shutdown), not a bad file.
    if (!clip || !r.stderr.trim()) return;
    // The file's data are corrupt: out of rotation at once, and shown in the library, rather than
    // failing again every time it comes round.
    if (/Invalid data found|Invalid NAL unit|Error submitting packet|Reserved bit set|missing picture in access unit|corrupt decoded frame|moov atom not found/i.test(r.stderr)) {
      this.lib.markBroken(clip.id, 'file danneggiato');
      this.note(`file danneggiato, tolto dalla rotazione finché non viene sostituito: ${clip.artist ? `${clip.artist} - ` : ''}${clip.title} (${clip.file})`);
      return;
    }
    const n = (this.failures.get(clip.id) ?? 0) + 1;
    this.failures.set(clip.id, n);
    if (n >= 2) this.lib.markBroken(clip.id);
  }

  /**
   * Restart the chain after a skip or a failure: drop the prepared segment,
   * play what was coming next from its start, and continue the timeline from
   * where the encoder actually is.
   */
  private recover(ts: number) {
    if (this.prepared) {
      const p = this.prepared;
      this.prepared = null;
      p.proc.kill('SIGKILL');
      this.reserved = this.upcoming?.clip ?? null;
      this.upcoming = p.plan.clip ? { clip: p.plan.clip, head: 0, fadeIn: SKIP_FADE } : null;
    } else if (this.upcoming) {
      this.upcoming = { ...this.upcoming, head: 0, fadeIn: SKIP_FADE };
    }
    this.tsCursor = ts;
    this.activate(this.spawnSegment(this.planNext()));
  }

  /** Skip at the next frame boundary (or after 1 s if no data is flowing). */
  skip() {
    // The clip on screen has all its pictures in the store already and ends within seconds:
    // cutting now would cut the next one instead.
    if (this.current && this.current.activatedAt > Date.now() + 500) {
      this.note('salto non fatto: il brano in onda finisce tra pochi secondi');
      return;
    }
    this.cutCurrent((ts) => {
      this.note('salto manuale');
      this.recover(ts);
    });
  }

  /**
   * Put `id` on air now, cutting the clip on air. What was coming next goes
   * back to the head of the playlist; `uid` (a planned item) or `queueIndex`
   * (the manual queue) is removed from where it was, so it does not play twice.
   */
  playNow(id: string, where: { uid?: number; queueIndex?: number } = {}) {
    const clip = this.lib.get(id);
    if (!clip || !this.lib.isPlayable(clip)) throw new Error('clip non disponibile');
    if (!this.running) throw new Error('la diretta è spenta');
    if (!this.current || this.current.cutAt) throw new Error('un cambio è già in corso, riprova tra un istante');
    if (where.uid !== undefined) this.sched.playlist.remove(where.uid);
    if (where.queueIndex !== undefined && this.sched.queue[where.queueIndex] === id) this.sched.removeFromQueue(where.queueIndex);
    this.cutCurrent((ts) => {
      const p = this.prepared;
      this.prepared = null;
      p?.proc.kill('SIGKILL');
      // Already taken from the playlist, in airing order; the chosen clip is not put back.
      const back = [p?.plan.clip, this.upcoming?.clip, this.reserved].filter((c): c is Clip => !!c);
      const i = back.findIndex((c) => c.id === clip.id);
      if (i >= 0) back.splice(i, 1);
      this.sched.playlist.putBack(back);
      this.reserved = null;
      this.upcoming = { clip, head: 0, fadeIn: SKIP_FADE };
      this.tsCursor = ts;
      this.note(`mandato in onda dal pannello: ${clip.artist ? clip.artist + ' - ' : ''}${clip.title}`);
      this.activate(this.spawnSegment(this.planNext()));
    });
  }

  /** Cut the clip on air at the next frame boundary (or after 1 s if no data is flowing), then `then(ts)`. */
  private cutCurrent(then: (ts: number) => void) {
    const r = this.current;
    if (!r || r.cutAt) return;
    const fallback = setTimeout(() => r.cutAt?.(null), 1000);
    r.cutAt = (pts) => {
      clearTimeout(fallback);
      r.cutAt = null;
      if (r !== this.current) return;
      this.current = null;
      const ts = this.tsAfter(r, pts);
      this.noteCut(r, ts);
      this.finish(r, 'saltato', ts);
      r.proc.kill('SIGKILL');
      then(ts);
    };
  }

  // ----------------------------------------------------------------- encoder

  private startEncoder() {
    // Time of day at the new encoder's t = 0: the news hours are counted from it.
    const d = new Date();
    this.encDayOffset = d.getHours() * 3600 + d.getMinutes() * 60 + d.getSeconds() + d.getMilliseconds() / 1000;
    const enc = spawn(FFMPEG, encoderArgs(this.cfg, this.encoderName, this.logoFile, this.tickerBlocks, this.encDayOffset), { windowsHide: true });
    setPriority(enc, 'onAir');
    this.enc = enc;
    this.encStartedAt = Date.now();
    this.outPts = { video: -1, audio: -1 };
    this.outCarry = Buffer.alloc(0);
    this.avRaw = 0;
    this.avBase = null;
    this.driftFixedAt = Date.now();
    this.encTime = 0;
    enc.stdin!.on('error', () => {});
    enc.stdout!.on('data', (chunk: Buffer) => this.fanOut(chunk));
    let buf = '';
    enc.stderr!.on('data', (d) => {
      buf += d;
      const lines = buf.split(/[\r\n]+/);
      buf = lines.pop() ?? '';
      for (const l of lines) this.encoderLine(l);
    });
    enc.on('close', (code) => {
      if (this.stopping || enc !== this.enc) return;
      this.note(this.encoderRestart ?? `encoder terminato (codice ${code}), riavvio`);
      this.lossIsFault = !this.encoderRestart || this.encoderFault;
      this.encoderRestart = null;
      this.encoderFault = false;
      this.enc = null;
      this.restartAfterEncoderLoss();
    });
  }

  private encoderLine(l: string) {
    const t = l.match(/time=(\d+):(\d+):([\d.]+)/);
    if (t) {
      this.encTime = Number(t[1]) * 3600 + Number(t[2]) * 60 + Number(t[3]);
      this.encStats = {
        fps: Number(l.match(/fps=\s*([\d.]+)/)?.[1] ?? 0),
        speed: Number(l.match(/speed=\s*([\d.]+)x/)?.[1] ?? 0),
        bitrate: l.match(/bitrate=\s*(\S+)/)?.[1] ?? '',
      };
      return;
    }
    // Expected at every segment join; not worth showing.
    if (/Packet corrupt|corrupt input packet|Resumed reading at pts/.test(l)) return;
    // Sound and picture reached the encoder with different times: it reports it for every
    // packet from then on and the stream goes out with the two apart, which players on the
    // net answer by dropping the sound. One line in the log, and a fresh encoder realigns them.
    if (/timestamp discontinuity/.test(l)) {
      const now = Date.now();
      if (now - this.splitSince > 10000) {
        this.splitSince = now;
        this.splitCount = 0;
      }
      if (++this.splitCount === 20 && now - this.splitRestartAt > 60000) {
        this.splitRestartAt = now;
        this.restartEncoder('audio e video si erano separati: encoder riavviato per riallinearli');
      }
      return;
    }
    if (l.trim()) this.note(`encoder: ${l.trim()}`);
  }

  private encoderRestart: string | null = null;
  /** The restart under way answers a fault (a crash, a stop), not a change of settings. */
  private encoderFault = false;
  private lossIsFault = false;
  private splitSince = 0;
  private splitCount = 0;
  private splitRestartAt = 0;

  /**
   * Start the encoder again with the current settings (bitrate, audio
   * processing): the clip on air resumes from where it was, after a short gap.
   */
  restartEncoder(reason: string, fault = false) {
    if (!this.running || !this.enc) return;
    this.encoderRestart = reason;
    this.encoderFault = fault;
    this.enc.kill('SIGKILL');
  }

  /** Encoder losses per clip in the last minutes, to give up on a clip that keeps stopping it. */
  private losses: { id: string; at: number }[] = [];

  /** Note a loss on `clip`; true when it is the second within ten minutes. */
  private lostOnTooOften(clip: Clip): boolean {
    const now = Date.now();
    this.losses = this.losses.filter((l) => now - l.at < 10 * 60000);
    this.losses.push({ id: clip.id, at: now });
    return this.losses.filter((l) => l.id === clip.id).length >= 2;
  }

  /** Resume the clip that was on air from the point the encoder had reached. */
  private restartAfterEncoderLoss() {
    // With pictures kept ready ahead, the clip handed over last may not be on screen yet:
    // the one to resume is the clip on screen, and the waiting one goes back to the playlist.
    const waiting = this.current && this.current.activatedAt > Date.now() && this.airing ? this.current : null;
    const cur = waiting ? this.airing : this.current;
    const prep = this.prepared;
    this.current = null;
    this.prepared = null;
    this.airing = null;
    prep?.proc.kill('SIGKILL');
    waiting?.proc.kill('SIGKILL');
    // Clips already taken for air go back to the playlist, in order, after the resumed one.
    this.sched.playlist.putBack([waiting?.plan.clip, prep?.plan.clip, this.upcoming?.clip, this.reserved].filter((c): c is Clip => !!c));
    this.upcoming = null;
    this.reserved = null;
    if (cur) {
      this.finish(cur, 'interrotto', this.encTime);
      cur.proc.kill('SIGKILL');
      if (cur.plan.clip && this.lossIsFault && this.lostOnTooOften(cur.plan.clip)) {
        // The same clip stopped the encoder again: something in the file; the clip after it plays.
        this.lib.markBroken(cur.plan.clip.id);
        this.note(`brano saltato e tolto dalla rotazione: l'encoder si è fermato più volte su "${cur.plan.clip.artist ? `${cur.plan.clip.artist} - ` : ''}${cur.plan.clip.title}" (controlla il file)`);
      } else if (cur.plan.clip) {
        const played = Math.max(0, this.encTime - cur.plan.tsOffset);
        const head = cur.plan.start - cur.plan.clip.cueIn + played;
        if (cur.plan.clip.cueOut - cur.plan.clip.cueIn - head > 3) {
          this.upcoming = { clip: cur.plan.clip, head, fadeIn: SKIP_FADE };
        }
      }
    }
    this.waitingDrain = false;
    setTimeout(() => {
      if (this.stopping) return;
      this.startEncoder();
      this.tsCursor = 0;
      this.audioDebt = 0;
      this.writtenTs = 0;
      this.activate(this.spawnSegment(this.planNext()));
    }, 2000);
  }

  // ------------------------------------------------------------ watchdog

  private watchTimer: NodeJS.Timeout | null = null;
  private publicCheck: PublicCheck | null = null;

  /** Connect the outputs to their servers again (not the local preview). */
  reconnectOutputs(reason: string) {
    for (const p of this.pushers) {
      if (p.target === 'preview' || !p.proc) continue;
      this.note(`${reason}: ricollego l'uscita ${p.label}`);
      p.lastError = reason;
      p.restarts = 0;
      p.proc.kill('SIGKILL');
    }
  }
  /** The smallest store of ready pictures since the last state line, and how often it ran out. */
  private cushionMin = Infinity;
  private starved = 0;
  private cushionTimer: NodeJS.Timeout | null = null;

  /**
   * Every few seconds: an output that takes nothing is reconnected, an encoder
   * that stands still is restarted, and every few minutes the state goes into the log,
   * so after a problem the log says what was running and what was not.
   */
  private watch() {
    if (this.watchTimer) clearInterval(this.watchTimer);
    let encSeen = { time: -1, at: Date.now() };
    let lastHealth = Date.now();
    let slowSpeedSince = 0;
    let lagAtHealth = 0;
    let lagWarnedAt = 0;
    if (this.cushionTimer) clearInterval(this.cushionTimer);
    let empty = false;
    this.cushionTimer = setInterval(() => {
      if (!this.enc || this.encTime < 5 || this.stopping) return;
      const a = this.ahead();
      this.cushionMin = Math.min(this.cushionMin, a);
      // The encoder had nothing more to take: on air this is a jerk.
      if (a < 0.15 && !empty) this.starved++;
      empty = a < 0.15;
    }, 250);
    this.watchTimer = setInterval(() => {
      if (!this.running || this.stopping) return;
      const now = Date.now();
      for (const p of this.pushers) {
        if (p.proc && p.slowSince && now - p.slowSince > PUSHER_STUCK_MS) {
          p.lastError = `ferma da ${Math.round((now - p.slowSince) / 1000)}s`;
          this.note(`uscita ${p.label} bloccata: non accetta dati da ${Math.round((now - p.slowSince) / 1000)}s, la ricollego`);
          p.slowSince = 0;
          p.proc.kill('SIGKILL');
        }
      }
      if (this.enc) {
        if (this.encTime !== encSeen.time || this.encStartedAt > encSeen.at) encSeen = { time: this.encTime, at: now };
        else if (now - encSeen.at > ENCODER_STUCK_MS && !this.encoderRestart) {
          encSeen = { time: -1, at: now };
          this.restartEncoder(`encoder fermo da ${ENCODER_STUCK_MS / 1000}s: riavviato`, true);
        }
        // Slower than real time: the picture falls behind and players on the net run dry.
        const speed = this.encStats.speed;
        if (speed > 0 && speed < 0.95 && now - this.encStartedAt > 60000) {
          if (!slowSpeedSince) slowSpeedSince = now;
          else if (now - slowSpeedSince > 120000) {
            this.note(`attenzione: encoder lento (${speed}x da 2 minuti), il computer non ce la fa`);
            slowSpeedSince = now + 30 * 60000; // tell again in half an hour at the earliest
          }
        } else if (slowSpeedSince && slowSpeedSince < now) slowSpeedSince = 0;
      }
      if (now - lastHealth >= HEALTH_EVERY_MS) {
        lastHealth = now;
        this.note(this.healthLine());
        // Behind the clock and getting further behind: players on the net run dry sooner or later.
        const lag = this.enc ? (now - this.encStartedAt) / 1000 - this.encTime : 0;
        if (lag > 20 && lag - lagAtHealth > 0.5 && now - lagWarnedAt > 30 * 60000) {
          lagWarnedAt = now;
          this.note(`attenzione: lo streaming è indietro di ${Math.round(lag)} s sull'orologio e il ritardo cresce: il computer non ce la fa a stare al passo (prova 1280x720 nella finestra Server)`);
        }
        lagAtHealth = lag;
      }
      // Preventive realignment: past about 12 s behind the clock some ffmpeg builds start losing
      // sound at every clip change. Before that, at the next clip change, the encoder restarts and
      // the delay goes back to zero. Only the encoder: the outputs stay connected to their servers.
      const behind = this.enc ? (now - this.encStartedAt) / 1000 - this.encTime : 0;
      if (behind > REALIGN_BEHIND && this.encTime > 60 && now - this.realignedAt > REALIGN_GAP_MS) this.realignPending = behind;
    }, 5000);
  }

  /** One line with the state of everything, for the log. */
  healthLine(): string {
    const e = this.encStats;
    const enc = this.enc
      ? `encoder ${e.speed || '?'}x ${e.fps || '?'}fps, ${Math.round((Date.now() - this.encStartedAt) / 60000)} min`
      : 'encoder spento';
    // Seconds of picture the encoder is behind the clock since it started: it keeps growing
    // when the computer cannot keep up, and the stream on the net then falls behind.
    const lag = this.enc ? Math.max(0, (Date.now() - this.encStartedAt) / 1000 - this.encTime) : 0;
    // Pictures ready ahead of the encoder: when the store runs out the clips are the slow part.
    const store = Number.isFinite(this.cushionMin) ? `scorta minima ${Math.max(0, this.cushionMin).toFixed(1)}s, ${this.starved} volte senza immagini` : 'scorta non misurata';
    this.cushionMin = Infinity;
    this.starved = 0;
    const outs = this.pushers.map((p) => `${p.label} ${p.state}${p.restarts ? ` (${p.restarts} riconn.)` : ''}`).join(', ') || 'nessuna uscita';
    const mem = Math.round(process.memoryUsage().rss / 1048576);
    const site = this.publicCheck?.enabled ? ` · sito ${this.publicCheck.state.ok ? 'in movimento' : 'fermo'}` : '';
    return `stato: ${enc}, indietro di ${lag.toFixed(1)}s sull'orologio, audio/video ${Math.round(this.avDrift * 1000)} ms, ${store} · uscite: ${outs}${site} · memoria ${mem} MB`;
  }

  // ----------------------------------------------------------------- outputs

  private startPusher(p: Pusher) {
    const proc = spawn(FFMPEG, pusherArgs(this.cfg, p.target), { windowsHide: true });
    setPriority(proc, 'onAir');
    p.proc = proc;
    p.state = p.restarts ? 'riconnessione' : 'avvio';
    p.since = Date.now();
    p.slowSince = 0;
    proc.stdin!.on('error', () => {});
    let err = '';
    proc.stderr!.on('data', (d) => (err = (err + d).slice(-600)));
    const ok = setTimeout(() => p.proc === proc && (p.state = 'attivo'), 5000);
    proc.on('close', (code) => {
      clearTimeout(ok);
      if (this.stopping || p.proc !== proc) return;
      p.proc = null;
      p.lastError = err.trim().split('\n').pop() || (p.lastError.startsWith('ferma da') ? p.lastError : `codice ${code}`);
      p.restarts++;
      p.state = 'riconnessione';
      const delay = Math.min(30, 2 ** Math.min(p.restarts, 5)) * 1000;
      this.note(`uscita ${p.label} caduta (${p.lastError}), nuovo tentativo tra ${delay / 1000}s`);
      setTimeout(() => !this.stopping && this.startPusher(p), delay);
    });
  }

  /** Latest picture and sound timestamps in the encoder's output, and the gap between them. */
  private outPts = { video: -1, audio: -1 };
  /** Sound minus picture in the output, seconds, smoothed: raw, with the muxer's own offset in it. */
  private avRaw = 0;
  /** The raw gap once the encoder has settled: the muxer always shows the sound a little behind. */
  private avBase: number | null = null;
  /** How far the sound has drifted from the picture since then (negative: behind). */
  get avDrift() {
    return this.avBase === null ? 0 : this.avRaw - this.avBase;
  }
  private outCarry = Buffer.alloc(0);

  /** Read the timestamps of the encoder's output as it goes out (cheap: PES headers only). */
  private measureOutput(chunk: Buffer) {
    const buf = this.outCarry.length ? Buffer.concat([this.outCarry, chunk]) : chunk;
    const n = buf.length - (buf.length % TS_PACKET);
    this.outCarry = buf.subarray(n);
    for (let off = 0; off < n; off += TS_PACKET) {
      const v = pesStartPts(buf, off, VIDEO_PID);
      if (v !== null) this.outPts.video = v;
      else {
        const a = pesStartPts(buf, off, AUDIO_PID);
        if (a !== null) this.outPts.audio = a;
      }
    }
    if (this.outPts.video < 0 || this.outPts.audio < 0) return;
    // 33-bit timestamps wrap after about 26.5 hours.
    const wrap = 2 ** 33 / 90000;
    let d = (this.outPts.audio - this.outPts.video) % wrap;
    if (d > wrap / 2) d -= wrap;
    if (d < -wrap / 2) d += wrap;
    this.avRaw += (d - this.avRaw) * 0.05;
    if (this.avBase === null && this.encTime > 15) this.avBase = this.avRaw;
  }

  /** Each output gets its own copy; a slow or dead output never stalls the encoder. */
  private fanOut(chunk: Buffer) {
    this.measureOutput(chunk);
    for (const p of this.pushers) {
      const stdin = p.proc?.stdin;
      if (!stdin || stdin.destroyed) continue;
      if (stdin.writableLength > PUSHER_MAX_BACKLOG) {
        if (!p.slowSince) {
          p.slowSince = Date.now();
          this.note(`uscita ${p.label} lenta: il server non riceve abbastanza in fretta`);
        }
        p.state = 'lento';
        continue;
      }
      if (p.slowSince) {
        this.note(`uscita ${p.label} di nuovo regolare dopo ${Math.round((Date.now() - p.slowSince) / 1000)}s`);
        p.slowSince = 0;
        p.state = 'attivo';
      }
      stdin.write(chunk);
    }
  }

  // ------------------------------------------------------------------ status

  /** Clips already committed to air (on air and the one prepared after it). */
  committed(): Clip[] {
    return [this.current?.plan.clip, this.prepared?.plan.clip ?? this.upcoming?.clip].filter((c): c is Clip => !!c);
  }

  /**
   * The playlist as the panel shows it: what aired since yesterday, the clip
   * on air, then what follows with start times worked out from the clip on air
   * (next clip, manual queue, planned playlist).
   */
  playlistView() {
    const now = Date.now();
    const day0 = new Date(now);
    day0.setHours(0, 0, 0, 0);
    day0.setDate(day0.getDate() - 1);
    const row = (c: Clip, at: number, kind: string, slot?: string, where: { uid?: number; queueIndex?: number } = {}) => ({
      ...where,
      id: c.id, type: c.type, artist: c.artist, title: c.title, year: Library.yearOf(c),
      slot: slot ?? this.sched.playlist.slotOf.get(c.id) ?? (c.type === 'music' ? c.category : c.type),
      duration: airTime(c), at, kind,
    });
    const cur = this.current;
    const hist = this.sched.history.filter((h) => h.at >= day0.getTime());
    // The last history entry is the clip on air.
    if (cur?.plan.clip && hist.length && hist[hist.length - 1].id === cur.plan.clip.id) hist.pop();
    const past = hist.flatMap((h, i) => {
      const c = this.lib.get(h.id);
      if (!c) return [];
      const end = hist[i + 1]?.at ?? cur?.activatedAt ?? h.at + airTime(c) * 1000;
      return [{ ...row(c, h.at, 'past'), duration: Math.max(0, (end - h.at) / 1000) }];
    });
    const onAir = cur?.plan.clip
      ? { ...row(cur.plan.clip, cur.activatedAt, 'onair'), endsAt: cur.endsAt, duration: (cur.endsAt - cur.activatedAt) / 1000 }
      : null;
    const future = [];
    let at = cur ? cur.endsAt : now;
    // Taken from the playlist already: the prepared clip, the one after it, one kept aside.
    const taken = [this.prepared?.plan.clip, this.upcoming?.clip, this.reserved].filter((c): c is Clip => !!c);
    for (const [i, c] of taken.entries()) {
      future.push(row(c, at, i === 0 ? 'next' : 'plan'));
      at += airTime(c) * 1000;
    }
    for (const [queueIndex, id] of this.sched.queue.entries()) {
      const c = this.lib.get(id);
      if (!c) continue;
      future.push(row(c, at, 'queue', undefined, { queueIndex }));
      at += airTime(c) * 1000;
    }
    for (const item of this.sched.playlist.items) {
      const c = this.lib.get(item.id);
      if (!c) continue;
      future.push(row(c, at, 'plan', item.slot, { uid: item.uid }));
      at += airTime(c) * 1000;
    }
    return { now, past, onAir, future };
  }

  /** The previous segment, still on air while the current one waits its turn in the encoder's store. */
  private airing: Running | null = null;

  status() {
    const now = Date.now();
    const cur = this.current && this.current.activatedAt > now && this.airing && this.airing.endsAt > now - 1000 ? this.airing : this.current;
    const onAir = cur && {
      clip: summary(cur.plan.clip),
      filler: !cur.plan.clip,
      startedAt: cur.activatedAt,
      // Position inside the clip's playable part, and how long the clip lasts.
      offset: cur.plan.clip ? cur.plan.start - cur.plan.clip.cueIn : 0,
      elapsed: Math.max(0, now - cur.activatedAt) / 1000,
      remaining: Math.max(0, cur.plan.length - Math.max(0, now - cur.activatedAt) / 1000),
      endsAt: cur.endsAt,
    };
    const nextClip = cur !== this.current ? this.current?.plan.clip ?? null : this.prepared?.plan.clip ?? this.upcoming?.clip ?? null;
    return {
      channel: this.cfg.channelName,
      version: PROGRAM_VERSION,
      running: this.running,
      uptime: (now - this.startedAt) / 1000,
      library: this.lib.progress(),
      onAir,
      next: summary(nextClip),
      schedule: this.sched.status(now, cur?.plan.clip),
      cards: this.cards?.status() ?? null,
      queue: this.sched.queue.map((id) => summary(this.lib.get(id))).filter(Boolean),
      history: this.sched.history.slice(-15).reverse().map((h) => ({ ...summary(this.lib.get(h.id)), at: h.at })),
      encoder: {
        name: this.encoderName,
        running: !!this.enc,
        uptime: this.enc ? (now - this.encStartedAt) / 1000 : 0,
        ...this.encStats,
      },
      outputs: this.pushers.map((p) => ({ label: p.label, state: p.state, restarts: p.restarts, lastError: p.lastError })),
      log: this.log.slice(-20),
    };
  }
}
