import fs from 'node:fs';
import path from 'node:path';
import { type Config, gfxScale } from './config.ts';
import type { Clip } from './library.ts';
import { filterValue, sec } from './ffmpeg.ts';
import { tickerLayout, topLeftLayout } from './graphics.ts';
import { Library } from './library.ts';
import { shrinkToFit, textWidth, twoLines } from './textfit.ts';


/**
 * Graphics drawn by the decoder over one clip, in segment time (t = 0 at the
 * segment start):
 * - lower third: "ORA IN ONDA", artist and title, left-aligned on one edge
 *   with a thin white bar, cascading in from the left;
 * - "A seguire": the next clip under the logo, title over artist in a compact card,
 *   with a bar that fills up to the moment it starts.
 */
export interface ClipGfxPlan {
  id: number;
  clip: Clip | null;
  length: number;
  titleAt: number | null;
  upNext?: Clip | null;
  /** Segment time at which the next clip starts. */
  nextAt?: number;
}

const easeOut = (p: string) => `(1-pow(1-${p},3))`;
const ramp = (from: number, dur: number) => `clip((t-${sec(from)})/${sec(dur)},0,1)`;

function textFile(tmpDir: string, id: number, name: string, text: string) {
  const f = path.join(tmpDir, `seg${id}-${name}.txt`);
  fs.writeFileSync(f, text || ' ');
  return filterValue(f);
}

/** A window [s, e] in which an element slides `dx` px from the left (or `dy` from above) and fades. */
function windowMotion(s: number, e: number, { dx = 0, dy = 0, inDur = 0.55, outDur = 0.35 } = {}) {
  const pin = ramp(s, inDur);
  const pout = ramp(e - outDur, outDur);
  return {
    x: `-${dx}*(1-${easeOut(pin)})-${dx}*pow(${pout},2)`,
    y: `-${dy}*(1-${easeOut(pin)})`,
    alpha: `${pin}*(1-${pout})`,
    enable: `between(t,${sec(s)},${sec(e)})`,
  };
}

function lowerThird(cfg: Config, plan: ClipGfxPlan, tmpDir: string, input: string, output: string): string {
  const clip = plan.clip!;
  const { width: W, height: H, fps } = cfg.output;
  const ov = cfg.overlay;
  const S = plan.titleAt!;
  const E = Math.min(plan.length - 0.5, S + ov.nowPlaying.showSeconds);
  const x0 = ov.logo.marginX ?? Math.round(W * 0.05);
  // Sizes (1080p: kicker 20, artist 66, title 36).
  const sc = gfxScale(cfg);
  const kick = Math.round(H * 0.0185 * sc);
  const big = Math.round(H * 0.061 * sc);
  const small = Math.round(H * 0.0335 * sc);
  const padX = Math.round(H * 0.024 * sc);
  const padBig = Math.round(big * 0.2);
  const padSmall = Math.round(small * 0.32);
  const barW = Math.max(4, Math.round(H * 0.0055));
  const gapBar = Math.round(H * 0.008);
  // Every box starts at the same left edge, right of the white bar.
  const boxX = x0 + barW + gapBar;
  const textX = boxX + padX;
  const bottom = H - tickerLayout(cfg).bar - Math.round(H * 0.045); // above the ticker
  const titleBoxH = small + 2 * padSmall;
  const artistBoxH = big + 2 * padBig;
  const yTitle = bottom - titleBoxH + padSmall;
  const yArtist = yTitle - padSmall - Math.round(H * 0.004) - artistBoxH + padBig;
  const yKick = yArtist - padBig - Math.round(H * 0.014) - kick;
  const blockTop = yArtist - padBig;
  const slide = Math.round(H * 0.045);
  const box = (pad: number) => `:box=1:boxcolor=0x0b0e17@0.85:boxborderw=${pad}|${padX}`;
  const draw = (font: string, file: string, size: number, color: string, x: number, y: number, delay: number, extra = '') => {
    const m = windowMotion(S + delay, E - delay / 2, { dx: slide });
    return `drawtext=fontfile=${filterValue(font)}:textfile=${file}:expansion=none:fontsize=${size}:fontcolor=${color}${extra}:` +
      `x='${x}+${m.x}':y=${y}:alpha='${m.alpha}':enable='${m.enable}'`;
  };
  // Long names are drawn a little smaller to fit whole; cut only if still too long.
  const room = Math.round(W * 0.74) - textX;
  // "A feat. B" too long for the artist line: the guest goes to the title line, so both read whole.
  let artistName = clip.artist || clip.title;
  let titleText = clip.artist ? clip.title : '';
  const feat = /^(.+?)\s+((?:feat\.?|ft\.?|featuring)\s+.+)$/i.exec(clip.artist ?? '');
  if (feat && textWidth(ov.fontBold, Math.round(big * 0.75), artistName) > room) {
    artistName = feat[1];
    titleText = `${clip.title} · ${feat[2]}`;
  }
  const artistFit = shrinkToFit(ov.fontBold, big, artistName, room);
  const titleFit = titleText ? shrinkToFit(ov.font, small, titleText, room, 0.65) : { text: '', size: small };
  const artist = artistFit.text;
  const title = titleFit.text;
  // The year as a tag of its own after "ORA IN ONDA", labelled so it reads as a year.
  const year = Library.yearOf(clip);
  const tagPad = Math.round(kick * 0.38);
  const tagX = textX + Math.round(textWidth(ov.fontSemiBold, kick, 'ORA IN ONDA')) + Math.round(H * 0.018) + tagPad;
  const texts = [
    draw(ov.fontSemiBold, textFile(tmpDir, plan.id, 'kicker', 'ORA IN ONDA'), kick, '0xe9ebf0', textX, yKick, 0),
    ...(year
      ? [draw(ov.fontSemiBold, textFile(tmpDir, plan.id, 'year', `ANNO ${year}`), kick, 'white', tagX, yKick, 0.04,
          `:box=1:boxcolor=white@0.18:boxborderw=${tagPad}|${Math.round(tagPad * 1.6)}`)]
      : []),
    // A smaller size keeps the box the same height: the text sits in its middle.
    draw(ov.fontBold, textFile(tmpDir, plan.id, 'artist', artist), artistFit.size, 'white', textX, yArtist + Math.round((big - artistFit.size) / 2), 0.08,
      box(padBig + Math.round((big - artistFit.size) / 2))),
    ...(title ? [draw(ov.font, textFile(tmpDir, plan.id, 'title', title), titleFit.size, '0xe2e5eb', textX, yTitle + Math.round((small - titleFit.size) / 2), 0.16,
      box(padSmall + Math.round((small - titleFit.size) / 2)))] : []),
  ];
  // The white bar grows down from the top of the block.
  const barH = (title ? bottom : yArtist - padBig + artistBoxH) - blockTop;
  const grow = windowMotion(S, E, { inDur: 0.45 });
  return [
    `color=c=white:s=${barW}x${barH}:r=${fps}:d=${sec(plan.length)},format=rgba[ltbar]`,
    `[${input}][ltbar]overlay=x=${x0}:y='${blockTop}-${barH}*(1-${easeOut(ramp(S, 0.45))})':eval=frame:` +
      `enable='${grow.enable}'[ltb]`,
    `[ltb]${texts.join(',')}[${output}]`,
  ].join(';');
}

function upNext(cfg: Config, plan: ClipGfxPlan, tmpDir: string, input: string, output: string): string {
  const next = plan.upNext!;
  const T = plan.nextAt!;
  const { width: W, height: H, fps } = cfg.output;
  const ov = cfg.overlay;
  const mx = ov.logo.marginX ?? ov.logo.margin;
  const my = ov.logo.marginY ?? ov.logo.margin;
  // Under the logo, right-aligned with it: a compact card, title over artist, never wider
  // than a quarter of the screen; a long title goes on two lines.
  const top = my + Math.round(ov.logo.width * (ov.logo.ratio ?? 0.42)) + Math.round(H * 0.022);
  const sc = gfxScale(cfg);
  const kick = Math.round(H * 0.0135 * sc);
  const tSize = Math.round(H * 0.0175 * sc);
  const aSize = Math.round(H * 0.0145 * sc);
  const maxW = Math.round(W * 0.25);
  const barH = Math.max(3, Math.round(H * 0.0035));
  const padK = Math.round(kick * 0.4);
  const padX = Math.round(tSize * 0.7);
  const padY = Math.round(tSize * 0.55);
  const lead = (size: number) => Math.round(size * 1.3);
  // Shown halfway through the clip for a while, then again before the change.
  const windows: [number, number][] = [];
  const len = ov.upNext.showSeconds;
  if (T > 90) windows.push([T * 0.5, T * 0.5 + len]);
  if (T > 20) windows.push([Math.max(1, T - ov.upNext.beforeSeconds), T - 0.4]);
  if (!windows.length) return `[${input}]null[${output}]`;

  const lines: { text: string; font: string; size: number; color: string }[] = [];
  const title = next.title || next.artist;
  if (textWidth(ov.fontSemiBold, tSize, title) <= maxW) {
    lines.push({ text: title, font: ov.fontSemiBold, size: tSize, color: 'white' });
  } else {
    const small = Math.round(tSize * 0.92);
    const [l1, l2] = twoLines(ov.fontSemiBold, small, title, maxW);
    for (const l of [l1, l2].filter(Boolean)) lines.push({ text: l, font: ov.fontSemiBold, size: small, color: 'white' });
  }
  if (next.artist && next.title) {
    const a = shrinkToFit(ov.font, aSize, next.artist, maxW, 0.85);
    lines.push({ text: a.text, font: ov.font, size: a.size, color: '0xb9bec8' });
  }
  const textW = Math.max(...lines.map((l) => textWidth(l.font, l.size, l.text)));
  const boxW = Math.round((Math.ceil(textW) + 2 * padX) / 2) * 2;
  const boxH = Math.round((lines.reduce((h, l) => h + lead(l.size), 0) + 2 * padY - Math.round(lines[lines.length - 1].size * 0.3)) / 2) * 2;
  const boxX = W - mx - boxW;
  const yKick = top + padK;
  const yBox = yKick + kick + padK + Math.round(H * 0.005);
  const yBar = yBox + boxH;
  const kickFile = textFile(tmpDir, plan.id, 'next-kicker', 'A SEGUIRE');
  const lineFiles = lines.map((l, i) => textFile(tmpDir, plan.id, `next-${i}`, l.text));
  const parts: string[] = [];
  let cur = input;
  windows.forEach(([s, e], i) => {
    const m = windowMotion(s, e, { dy: Math.round(H * 0.012), inDur: 0.5, outDur: 0.4 });
    const fades = `fade=t=in:st=${sec(s)}:d=0.5:alpha=1,fade=t=out:st=${sec(e - 0.4)}:d=0.4:alpha=1`;
    // The bar shows how much is left of the song: in the last window it fills from empty to
    // full right at the change, so the end coming up reads at a glance.
    const from = i === windows.length - 1 ? s : 0;
    const fill = `clip((t-${sec(from)})/${sec(T - from)},0,1)`;
    parts.push(
      `color=c=0x0b0e17@0.82:s=${boxW}x${boxH}:r=${fps}:d=${sec(plan.length)},format=rgba,${fades}[unbox${i}]`,
      `color=c=0x3a3f4a:s=${boxW}x${barH}:r=${fps}:d=${sec(plan.length)},format=rgba[untrack${i}]`,
      `color=c=${ov.accent}:s=${boxW}x${barH}:r=${fps}:d=${sec(plan.length)},format=rgba[unfill${i}]`,
      `[untrack${i}][unfill${i}]overlay=x='-w+w*${fill}':y=0:eval=frame,format=rgba,${fades}[unbar${i}]`,
      `[${cur}][unbox${i}]overlay=x=${boxX}:y='${yBox}+${m.y}':eval=frame:enable='${m.enable}'[unx${i}]`,
      `[unx${i}][unbar${i}]overlay=x=${boxX}:y='${yBar}+${m.y}':eval=frame:enable='${m.enable}'[unb${i}]`,
    );
    const draws = [
      `drawtext=fontfile=${filterValue(ov.fontSemiBold)}:textfile=${kickFile}:expansion=none:fontsize=${kick}:fontcolor=${ov.accentText}` +
        `:box=1:boxcolor=${ov.accent}:boxborderw=${padK}|${padX}:x=${boxX + padX}:y='${yKick}+${m.y}':alpha='${m.alpha}':enable='${m.enable}'`,
    ];
    let y = yBox + padY;
    lines.forEach((l, j) => {
      draws.push(`drawtext=fontfile=${filterValue(l.font)}:textfile=${lineFiles[j]}:expansion=none:fontsize=${l.size}:fontcolor=${l.color}` +
        `:x=${boxX + padX}:y='${y}+${m.y}':alpha='${m.alpha}':enable='${m.enable}'`);
      y += lead(l.size);
    });
    parts.push(`[unb${i}]${draws.join(',')}[unt${i}]`);
    cur = `unt${i}`;
  });
  parts.push(`[${cur}]null[${output}]`);
  return parts.join(';');
}

/**
 * Next to the clock (drawn by the encoder on the same grid, see
 * topLeftLayout): a thin divider, the title, and "Artist · year" below it.
 * Fades in with a short rise when the clip starts, out when it ends.
 */
function nowBadge(cfg: Config, plan: ClipGfxPlan, tmpDir: string, input: string, output: string): string {
  const clip = plan.clip!;
  const { fps, width: W } = cfg.output;
  const ov = cfg.overlay;
  const T = topLeftLayout(cfg);
  const year = Library.yearOf(clip);
  const sc = gfxScale(cfg);
  const roomTop = Math.round(W * 0.55) - T.textX;
  const titleFit = shrinkToFit(ov.fontSemiBold, T.titleSize, clip.title, roomTop);
  const title = titleFit.text;
  const metaFit = shrinkToFit(ov.font, T.metaSize, [clip.artist, year].filter(Boolean).join('  ·  '), roomTop);
  const S = 0.6;
  const E = plan.length - 0.3;
  const pin = ramp(S, 0.4);
  const pout = ramp(E - 0.3, 0.3);
  const alpha = `'${pin}*(1-${pout})'`;
  const rise = (y: number) => `'${y}+8*(1-${easeOut(pin)})'`;
  const shadow = ':shadowcolor=black@0.4:shadowx=0:shadowy=2';
  return [
    `color=c=white@0.45:s=${T.sepW}x${T.sepH}:r=${fps}:d=${sec(plan.length)},format=rgba,` +
      `fade=t=in:st=${sec(S)}:d=0.4:alpha=1,fade=t=out:st=${sec(E - 0.3)}:d=0.3:alpha=1[npsep]`,
    `[${input}][npsep]overlay=x=${T.sepX}:y=${T.sepY}:eof_action=pass[nps]`,
    `[nps]drawtext=fontfile=${filterValue(ov.fontSemiBold)}:textfile=${textFile(tmpDir, plan.id, 'np', title)}:expansion=none:` +
      `fontsize=${titleFit.size}:fontcolor=white${shadow}:x=${T.textX}:y=${rise(T.titleBaseline)}:y_align=baseline:alpha=${alpha},` +
      `drawtext=fontfile=${filterValue(ov.font)}:textfile=${textFile(tmpDir, plan.id, 'npy', metaFit.text || ' ')}:expansion=none:` +
      `fontsize=${metaFit.size}:fontcolor=0xb9bec8${shadow}:x=${T.textX}:y=${rise(T.metaBaseline)}:y_align=baseline:alpha=${alpha}[${output}]`,
  ].join(';');
}

/** All clip graphics from `[input]` to `[output]`. */
export function clipGraphics(cfg: Config, plan: ClipGfxPlan, tmpDir: string, input: string, output: string): string {
  const parts: string[] = [];
  let cur = input;
  const clip = plan.clip;
  if (clip && plan.titleAt !== null && cfg.overlay.nowPlaying.enabled && Math.min(plan.length - 0.5, plan.titleAt + cfg.overlay.nowPlaying.showSeconds) - plan.titleAt >= 2) {
    parts.push(lowerThird(cfg, plan, tmpDir, cur, 'cg1'));
    cur = 'cg1';
  }
  if (clip && cfg.overlay.nowPlaying.enabled && clip.type === 'music') {
    parts.push(nowBadge(cfg, plan, tmpDir, cur, 'cg0'));
    cur = 'cg0';
  }
  if (cfg.overlay.upNext.enabled && plan.upNext && plan.nextAt) {
    parts.push(upNext(cfg, plan, tmpDir, cur, 'cg2'));
    cur = 'cg2';
  }
  parts.push(`[${cur}]null[${output}]`);
  return parts.join(';');
}
