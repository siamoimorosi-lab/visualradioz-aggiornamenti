// Settings of the televoto (Impostazioni → Televoto).
let vt = null;
let vtCats = [];
async function loadVote() {
  vt = await api('/api/vote');
  try {
    vtCats = Object.keys((await api('/api/settings')).categories).filter((c) => c !== 'jingle').sort();
  } catch {
    vtCats = [];
  }
  $('vtOn').checked = vt.enabled;
  $('vtMin').value = vt.roundMinutes;
  $('vtCount').value = vt.candidates;
  $('vtNew').value = vt.newCount;
  $('vtEvery').value = vt.showEverySeconds;
  $('vtShow').value = vt.showSeconds;
  const chips = (sel) => vtCats.map((c) => `<label class="check"><input type="checkbox" value="${esc(c)}"${sel.includes(c) ? ' checked' : ''}> ${esc(c)}</label>`).join('') || '<span class="hint">nessuna categoria</span>';
  $('vtNewCats').innerHTML = chips(vt.newCategories);
  $('vtOtherCats').innerHTML = chips(vt.otherCategories);
  vtHours = vt.hours.map((h) => ({ ...h }));
  renderVtHours();
  showVote();
}
let vtHours = [];
function renderVtHours() {
  $('vtHours').innerHTML = vtHours.map((h, i) => `<div class="grid-row" data-h="${i}">
    <input class="vh-days" value="${esc(h.days)}" placeholder="giorni, es. ven,sab" aria-label="Giorni">
    <input class="vh-hours" value="${esc(h.hours)}" placeholder="ore, es. 20-23" aria-label="Ore">
    <button class="ghost small vh-del">✕</button></div>`).join('') || '<p class="hint">Nessuna fascia: si vota solo quando lo avvii a mano.</p>';
}
$('vtHours').addEventListener('input', (e) => {
  const row = e.target.closest('[data-h]');
  if (!row) return;
  vtHours[+row.dataset.h] = { days: row.querySelector('.vh-days').value, hours: row.querySelector('.vh-hours').value };
});
$('vtHours').addEventListener('click', (e) => {
  if (!e.target.classList.contains('vh-del')) return;
  vtHours.splice(+e.target.closest('[data-h]').dataset.h, 1);
  renderVtHours();
});
$('vtAddHour').onclick = () => {
  vtHours.push({ days: '*', hours: '20-23' });
  renderVtHours();
};
function showVote() {
  if (!vt) return;
  const hm = (t) => new Date(t).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  $('vtState').textContent = vt.round ? `votazione aperta fino alle ${hm(vt.round.closesAt)}`
    : !vt.page ? 'manca l’indirizzo della pagina (Controllo remoto)'
    : vt.enabled ? (vt.inHours ? 'in fascia: la votazione parte a breve' : 'attivo, fuori fascia') : 'spento';
  const r = vt.round;
  const total = r ? r.songs.reduce((s, x) => s + x.votes, 0) : 0;
  $('vtRound').innerHTML = r
    ? `<p class="hint">Pagina di voto: <a href="${esc(vt.page)}" target="_blank" rel="noopener">${esc(vt.page)}</a> · ${total} voti${vt.connected ? '' : ` · <b>pagina non raggiungibile: ${esc(vt.remoteError || 'in attesa')}</b>`}</p>
       <ol class="list small-list">${r.songs.map((s) => `<li><span class="t">${s.n}. ${s.isNew ? '<b>NUOVO</b> · ' : ''}${esc(s.artist ? `${s.artist} – ${s.title}` : s.title)}</span><span class="sub">${s.votes} voti${total ? ` · ${Math.round((s.votes * 100) / total)}%` : ''}</span></li>`).join('')}</ol>`
    : vt.last ? `<p class="hint">Ultima vincitrice: ${esc(vt.last.artist ? `${vt.last.artist} – ${vt.last.title}` : vt.last.title)} con ${vt.last.votes} voti su ${vt.last.total}, alle ${hm(vt.last.at)}.</p>` : '';
}
setInterval(async () => {
  if (views.settings.hidden || !vt) return;
  try {
    const v = await api('/api/vote');
    Object.assign(vt, { round: v.round, last: v.last, inHours: v.inHours, connected: v.connected, remoteError: v.remoteError });
    showVote();
  } catch {
    // next time
  }
}, 5000);
window.addEventListener('hashchange', () => !views.settings.hidden && loadVote());
if (!views.settings.hidden) loadVote();
const picked = (id) => [...$(id).querySelectorAll('input:checked')].map((i) => i.value);
$('vtSave').onclick = async () => {
  $('vtMsg').textContent = 'Salvo…';
  try {
    await api('/api/vote', 'POST', {
      enabled: $('vtOn').checked, hours: vtHours,
      roundMinutes: Number($('vtMin').value), candidates: Number($('vtCount').value), newCount: Number($('vtNew').value),
      newCategories: picked('vtNewCats'), otherCategories: picked('vtOtherCats'),
      showEverySeconds: Number($('vtEvery').value), showSeconds: Number($('vtShow').value),
    });
    await loadVote();
    $('vtMsg').textContent = 'Salvato.';
  } catch (e) {
    $('vtMsg').textContent = `Non salvato: ${e.message}`;
  }
};
$('vtStart').onclick = async () => {
  try {
    await api('/api/vote', 'POST', { action: 'start' });
    await loadVote();
    $('vtMsg').textContent = 'Votazione aperta.';
  } catch (e) {
    $('vtMsg').textContent = e.message;
  }
};
$('vtStop').onclick = async () => {
  if (!confirm('Annullare la votazione in corso, senza vincitore?')) return;
  await api('/api/vote', 'POST', { action: 'stop' }).catch(() => {});
  await loadVote();
};
