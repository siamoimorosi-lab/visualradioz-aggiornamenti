// Settings of the televoto (Impostazioni → Televoto).
let vt = null;
let vtCats = [];
async function loadVote() {
  vt = await api('/api/vote');
  try {
    vtCats = Object.keys((await api('/api/settings')).categories).filter((c) => c !== 'jingle').sort();
  } catch {
    vtCats = [];
  }
  $('vtOn').checked = vt.enabled;
  $('vtMin').value = vt.roundMinutes;
  $('vtAddress').value = vt.address ?? '';
  vtGroups = (vt.groups?.length ? vt.groups : [
    { categories: vt.newCategories, count: vt.newCount, tag: '' },
    { categories: vt.otherCategories, count: Math.max(0, vt.candidates - vt.newCount), tag: '' },
  ]).map((g) => ({ categories: [...g.categories], count: g.count, tag: g.tag }));
  renderVtGroups();
  $('vtEvery').value = vt.showEverySeconds;
  $('vtShow').value = vt.showSeconds;
  vtHours = vt.hours.map((h) => ({ ...h }));
  renderVtHours();
  showVote();
}
let vtHours = [];
let vtGroups = [];
function renderVtGroups() {
  $('vtGroups').innerHTML = vtGroups.map((g, i) => `<div class="excl" data-g="${i}">
    <div class="row"><input type="number" class="vg-count" min="0" max="10" value="${g.count}" style="width:70px" aria-label="Quanti brani"> brani con etichetta
      <input class="vg-tag" value="${esc(g.tag)}" maxlength="12" placeholder="es. NATALE" style="width:130px" aria-label="Etichetta">
      <button class="ghost small vg-del">✕</button></div>
    <div class="chips">${vtCats.map((c) => `<label class="check"><input type="checkbox" class="vg-cat" value="${esc(c)}"${g.categories.includes(c) ? ' checked' : ''}> ${esc(c)}</label>`).join('') || '<span class="hint">nessuna categoria</span>'}</div>
  </div>`).join('') || '<p class="hint">Nessun gruppo: aggiungine uno.</p>';
  const n = vtGroups.reduce((s, g) => s + (Number(g.count) || 0), 0);
  $('vtTotal').textContent = `In tutto ${Math.min(10, n)} brani per votazione${n > 10 ? ' (oltre 10 non si usano)' : ''}.`;
}
$('vtGroups').addEventListener('change', (e) => {
  const row = e.target.closest('[data-g]');
  if (!row) return;
  const g = vtGroups[+row.dataset.g];
  g.count = Number(row.querySelector('.vg-count').value) || 0;
  g.tag = row.querySelector('.vg-tag').value.trim().toUpperCase();
  g.categories = [...row.querySelectorAll('.vg-cat:checked')].map((x) => x.value);
  renderVtGroups();
});
$('vtGroups').addEventListener('click', (e) => {
  if (!e.target.classList.contains('vg-del')) return;
  vtGroups.splice(+e.target.closest('[data-g]').dataset.g, 1);
  renderVtGroups();
});
$('vtAddGroup').onclick = () => {
  vtGroups.push({ categories: [], count: 2, tag: '' });
  renderVtGroups();
};
function renderVtHours() {
  $('vtHours').innerHTML = vtHours.map((h, i) => `<div class="grid-row" data-h="${i}">
    <input class="vh-days" value="${esc(h.days)}" placeholder="giorni, es. ven,sab" aria-label="Giorni">
    <input class="vh-hours" value="${esc(h.hours)}" placeholder="ore, es. 20-23" aria-label="Ore">
    <button class="ghost small vh-del">✕</button></div>`).join('') || '<p class="hint">Nessuna fascia: si vota solo quando lo avvii a mano.</p>';
}
$('vtHours').addEventListener('input', (e) => {
  const row = e.target.closest('[data-h]');
  if (!row) return;
  vtHours[+row.dataset.h] = { days: row.querySelector('.vh-days').value, hours: row.querySelector('.vh-hours').value };
});
$('vtHours').addEventListener('click', (e) => {
  if (!e.target.classList.contains('vh-del')) return;
  vtHours.splice(+e.target.closest('[data-h]').dataset.h, 1);
  renderVtHours();
});
$('vtAddHour').onclick = () => {
  vtHours.push({ days: '*', hours: '20-23' });
  renderVtHours();
};
function showVote() {
  if (!vt) return;
  const hm = (t) => new Date(t).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  $('vtState').textContent = vt.round ? `votazione aperta fino alle ${hm(vt.round.closesAt)}`
    : !vt.page ? 'manca l’indirizzo della pagina (Controllo remoto)'
    : vt.enabled ? (vt.inHours ? 'in fascia: la votazione parte a breve' : 'attivo, fuori fascia') : 'spento';
  const r = vt.round;
  const total = r ? r.songs.reduce((s, x) => s + x.votes, 0) : 0;
  $('vtRound').innerHTML = r
    ? `<p class="hint">Pagina di voto: <a href="${esc(vt.page)}" target="_blank" rel="noopener">${esc(vt.page)}</a> · ${total} voti${vt.connected ? '' : ` · <b>pagina non raggiungibile: ${esc(vt.remoteError || 'in attesa')}</b>`}</p>
       <ol class="list small-list">${r.songs.map((s) => `<li><span class="t">${s.n}. ${s.tag ? `<b>${esc(s.tag)}</b> · ` : ''}${esc(s.artist ? `${s.artist} – ${s.title}` : s.title)}</span><span class="sub">${s.votes} voti${total ? ` · ${Math.round((s.votes * 100) / total)}%` : ''}</span></li>`).join('')}</ol>`
    : vt.last ? `<p class="hint">Ultima vincitrice: ${esc(vt.last.artist ? `${vt.last.artist} – ${vt.last.title}` : vt.last.title)} con ${vt.last.votes} voti su ${vt.last.total}, alle ${hm(vt.last.at)}.</p>` : '';
}
setInterval(async () => {
  if (views.settings.hidden || !vt) return;
  try {
    const v = await api('/api/vote');
    Object.assign(vt, { round: v.round, last: v.last, inHours: v.inHours, connected: v.connected, remoteError: v.remoteError });
    showVote();
  } catch {
    // next time
  }
}, 5000);
window.addEventListener('hashchange', () => !views.settings.hidden && loadVote());
if (!views.settings.hidden) loadVote();
$('vtSave').onclick = async () => {
  $('vtMsg').textContent = 'Salvo…';
  try {
    await api('/api/vote', 'POST', {
      enabled: $('vtOn').checked, hours: vtHours,
      roundMinutes: Number($('vtMin').value), groups: vtGroups,
      candidates: Math.max(2, Math.min(10, vtGroups.reduce((n, g) => n + g.count, 0))), newCount: 0, newCategories: [], otherCategories: [],
      showEverySeconds: Number($('vtEvery').value), showSeconds: Number($('vtShow').value), address: $('vtAddress').value.trim(),
    });
    await loadVote();
    $('vtMsg').textContent = 'Salvato.';
  } catch (e) {
    $('vtMsg').textContent = `Non salvato: ${e.message}`;
  }
};
$('vtStart').onclick = async () => {
  try {
    await api('/api/vote', 'POST', { action: 'start' });
    await loadVote();
    $('vtMsg').textContent = 'Votazione aperta.';
  } catch (e) {
    $('vtMsg').textContent = e.message;
  }
};
$('vtStop').onclick = async () => {
  if (!confirm('Annullare la votazione in corso, senza vincitore?')) return;
  await api('/api/vote', 'POST', { action: 'stop' }).catch(() => {});
  await loadVote();
};
