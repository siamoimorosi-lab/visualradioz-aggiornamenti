// Settings of the visuals (Impostazioni → Visual): folders, their clock, the hours.
let vi = null;
let viSets = [];
let viClock = [];
let viHours = [];
async function loadVisuals() {
  vi = await api('/api/visuals');
  viSets = vi.sets.map((x) => ({ ...x }));
  viClock = [...vi.clock];
  viHours = vi.hours.map((h) => ({ ...h }));
  $('viMin').value = vi.minSeconds;
  $('viShowClock').checked = vi.show?.clock !== false;
  $('viShowLogo').checked = vi.show?.logo !== false;
  $('viShowTicker').checked = vi.show?.ticker !== false;
  $('viMax').value = vi.maxSeconds;
  renderVisuals();
}
function renderVisuals() {
  const counts = vi?.counts ?? {};
  $('viSets').innerHTML = viSets.map((x, i) => `<div class="grid-row" data-s="${i}">
    <input class="vs-name" value="${esc(x.name)}" placeholder="nome, es. Generali" aria-label="Nome" style="max-width:160px">
    <input class="vs-path" value="${esc(x.path)}" placeholder="cartella, es. D:\\Visual\\Generali" aria-label="Cartella" style="flex:1">
    <span class="hint">${counts[x.name] !== undefined ? `${counts[x.name]} file` : ''}</span>
    <button class="ghost small vs-del">✕</button></div>`).join('') || '<p class="hint">Nessuna cartella: aggiungine una, per esempio Generali e Christmas.</p>';
  const names = viSets.map((x) => x.name).filter(Boolean);
  $('viAdd').innerHTML = names.map((n) => `<button class="chip" data-add="${esc(n)}">+ ${esc(n)}</button>`).join('');
  $('viClock').innerHTML = viClock.map((n, j) => `<span class="slot-chip${names.includes(n) ? '' : ' missing'}"><span class="n">${j + 1}</span>${esc(n)}
    <button data-move="-1" data-j="${j}" aria-label="Sposta a sinistra">‹</button><button data-move="1" data-j="${j}" aria-label="Sposta a destra">›</button><button data-rm="${j}" aria-label="Togli">✕</button></span>`).join('')
    || '<span class="sub">Vuoto: le cartelle vanno a turno, una dopo l’altra.</span>';
  $('viHours').innerHTML = viHours.map((h, i) => `<div class="grid-row" data-h="${i}">
    <input class="vh-days" value="${esc(h.days)}" placeholder="giorni, es. mar" aria-label="Giorni">
    <input class="vh-hours" value="${esc(h.hours)}" placeholder="ore, es. 21-24" aria-label="Ore">
    <button class="ghost small vh-del">✕</button></div>`).join('') || '<p class="hint">Nessuna fascia: i visual non partono.</p>';
  $('viState').textContent = vi?.on ? 'in onda adesso' : '';
}
$('viSets').addEventListener('input', (e) => {
  const row = e.target.closest('[data-s]');
  if (!row) return;
  const i = +row.dataset.s;
  const before = viSets[i].name;
  viSets[i] = { name: row.querySelector('.vs-name').value.trim(), path: row.querySelector('.vs-path').value.trim() };
  if (before && before !== viSets[i].name) viClock = viClock.map((n) => (n === before ? viSets[i].name : n));
});
$('viSets').addEventListener('change', () => renderVisuals());
$('viSets').addEventListener('click', (e) => {
  if (!e.target.classList.contains('vs-del')) return;
  const [gone] = viSets.splice(+e.target.closest('[data-s]').dataset.s, 1);
  viClock = viClock.filter((n) => n !== gone.name);
  renderVisuals();
});
$('viAddSet').onclick = () => {
  viSets.push({ name: viSets.length ? 'Christmas' : 'Generali', path: '' });
  renderVisuals();
};
$('viAdd').addEventListener('click', (e) => {
  const b = e.target.closest('[data-add]');
  if (!b) return;
  viClock.push(b.dataset.add);
  renderVisuals();
});
$('viClock').addEventListener('click', (e) => {
  const b = e.target.closest('button');
  if (!b) return;
  if (b.dataset.rm !== undefined) viClock.splice(+b.dataset.rm, 1);
  if (b.dataset.move !== undefined) {
    const j = +b.dataset.j;
    const k = j + +b.dataset.move;
    if (k >= 0 && k < viClock.length) [viClock[j], viClock[k]] = [viClock[k], viClock[j]];
  }
  renderVisuals();
});
$('viHours').addEventListener('input', (e) => {
  const row = e.target.closest('[data-h]');
  if (!row) return;
  viHours[+row.dataset.h] = { days: row.querySelector('.vh-days').value, hours: row.querySelector('.vh-hours').value };
});
$('viHours').addEventListener('click', (e) => {
  if (!e.target.classList.contains('vh-del')) return;
  viHours.splice(+e.target.closest('[data-h]').dataset.h, 1);
  renderVisuals();
});
$('viAddHour').onclick = () => {
  viHours.push({ days: 'mar', hours: '21-24' });
  renderVisuals();
};
$('viSave').onclick = async () => {
  $('viMsg').textContent = 'Salvo…';
  try {
    await api('/api/visuals', 'POST', { sets: viSets, clock: viClock, hours: viHours, minSeconds: Number($('viMin').value), maxSeconds: Number($('viMax').value),
      show: { clock: $('viShowClock').checked, logo: $('viShowLogo').checked, ticker: $('viShowTicker').checked } });
    await loadVisuals();
    $('viMsg').textContent = 'Salvato. Le cartelle nuove vengono lette subito: il numero di file compare tra poco.';
  } catch (e) {
    $('viMsg').textContent = `Non salvato: ${e.message}`;
  }
};
window.addEventListener('hashchange', () => !views.settings.hidden && loadVisuals());
if (!views.settings.hidden) loadVisuals();
