import crypto from 'node:crypto';
import fs from 'node:fs';
import { Resvg } from '@resvg/resvg-js';
import path from 'node:path';
import { type Config, assetPath, gfxScale } from './config.ts';
import { qrMatrix } from './qr.ts';
import type { Clip } from './library.ts';
import { filterValue, sec } from './ffmpeg.ts';
import { tickerLayout, topLeftLayout } from './graphics.ts';
import { Library } from './library.ts';
import { fitWidth, shrinkToFit, textWidth, twoLines } from './textfit.ts';
import type { VoteOverlay } from './vote.ts';


/**
 * Graphics drawn by the decoder over one clip, in segment time (t = 0 at the
 * segment start):
 * - lower third: "ORA IN ONDA", artist and title, left-aligned on one edge
 *   with a thin white bar, cascading in from the left;
 * - "A seguire": the next clip under the logo, title over artist in a compact card,
 *   with a bar that fills up to the moment it starts.
 */
export interface ClipGfxPlan {
  id: number;
  clip: Clip | null;
  length: number;
  titleAt: number | null;
  upNext?: Clip | null;
  /** Segment time at which the next clip starts. */
  nextAt?: number;
  /** Lower third kicker instead of "ORA IN ONDA" (e.g. the song most voted). */
  kicker?: string;
  /** The televoto winner, revealed in a big card at the start of the clip. */
  winner?: { title: string; artist: string; share: number };
  /** Televoto panel: the round's songs, the closing time, the page's address. */
  vote?: VoteOverlay;
  /** The picture's parts during the visuals hours: no song graphics over a visual. */
  videoParts?: { length: number; visual?: boolean }[];
}

/** An enable option that keeps a graphic off the visuals, or '' when the segment has none. */
function offVisuals(plan: ClipGfxPlan): string {
  const w: string[] = [];
  let t = 0;
  for (const p of plan.videoParts ?? []) {
    if (p.visual) w.push(`between(t,${sec(t)},${sec(t + p.length)})`);
    t += p.length;
  }
  return w.length ? `:enable='not(${w.join('+')})'` : '';
}

const easeOut = (p: string) => `(1-pow(1-${p},3))`;
const ramp = (from: number, dur: number) => `clip((t-${sec(from)})/${sec(dur)},0,1)`;

function textFile(tmpDir: string, id: number, name: string, text: string) {
  const f = path.join(tmpDir, `seg${id}-${name}.txt`);
  fs.writeFileSync(f, text || ' ');
  return filterValue(f);
}

/** A window [s, e] in which an element slides `dx` px from the left (or `dy` from above) and fades. */
function windowMotion(s: number, e: number, { dx = 0, dy = 0, inDur = 0.55, outDur = 0.35 } = {}) {
  const pin = ramp(s, inDur);
  const pout = ramp(e - outDur, outDur);
  return {
    x: `-${dx}*(1-${easeOut(pin)})-${dx}*pow(${pout},2)`,
    y: `-${dy}*(1-${easeOut(pin)})`,
    alpha: `${pin}*(1-${pout})`,
    enable: `between(t,${sec(s)},${sec(e)})`,
  };
}

function lowerThird(cfg: Config, plan: ClipGfxPlan, tmpDir: string, input: string, output: string): string {
  const clip = plan.clip!;
  const { width: W, height: H, fps } = cfg.output;
  const ov = cfg.overlay;
  const S = plan.titleAt!;
  const E = Math.min(plan.length - 0.5, S + ov.nowPlaying.showSeconds);
  const x0 = ov.logo.marginX ?? Math.round(W * 0.05);
  // Sizes (1080p: kicker 20, artist 66, title 36).
  const sc = gfxScale(cfg);
  const kick = Math.round(H * 0.0185 * sc);
  const big = Math.round(H * 0.061 * sc);
  const small = Math.round(H * 0.0335 * sc);
  const padX = Math.round(H * 0.024 * sc);
  const padBig = Math.round(big * 0.2);
  const padSmall = Math.round(small * 0.32);
  const barW = Math.max(4, Math.round(H * 0.0055));
  const gapBar = Math.round(H * 0.008);
  // Every box starts at the same left edge, right of the white bar.
  const boxX = x0 + barW + gapBar;
  const textX = boxX + padX;
  const bottom = H - tickerLayout(cfg).bar - Math.round(H * 0.045); // above the ticker
  const titleBoxH = small + 2 * padSmall;
  const artistBoxH = big + 2 * padBig;
  const yTitle = bottom - titleBoxH + padSmall;
  const yArtist = yTitle - padSmall - Math.round(H * 0.004) - artistBoxH + padBig;
  const yKick = yArtist - padBig - Math.round(H * 0.014) - kick;
  const blockTop = yArtist - padBig;
  const slide = Math.round(H * 0.045);
  const box = (pad: number) => `:box=1:boxcolor=0x0b0e17@0.85:boxborderw=${pad}|${padX}`;
  const draw = (font: string, file: string, size: number, color: string, x: number, y: number, delay: number, extra = '') => {
    const m = windowMotion(S + delay, E - delay / 2, { dx: slide });
    return `drawtext=fontfile=${filterValue(font)}:textfile=${file}:expansion=none:fontsize=${size}:fontcolor=${color}${extra}:` +
      `x='${x}+${m.x}':y=${y}:alpha='${m.alpha}':enable='${m.enable}'`;
  };
  // Long names are drawn a little smaller to fit whole; cut only if still too long.
  const room = Math.round(W * 0.74) - textX;
  // "A feat. B" too long for the artist line: the guest goes to the title line, so both read whole.
  let artistName = clip.artist || clip.title;
  let titleText = clip.artist ? clip.title : '';
  const feat = /^(.+?)\s+((?:feat\.?|ft\.?|featuring)\s+.+)$/i.exec(clip.artist ?? '');
  if (feat && textWidth(ov.fontBold, Math.round(big * 0.75), artistName) > room) {
    artistName = feat[1];
    titleText = `${clip.title} · ${feat[2]}`;
  }
  const artistFit = shrinkToFit(ov.fontBold, big, artistName, room);
  const titleFit = titleText ? shrinkToFit(ov.font, small, titleText, room, 0.65) : { text: '', size: small };
  const artist = artistFit.text;
  const title = titleFit.text;
  // The year as a tag of its own after "ORA IN ONDA", labelled so it reads as a year.
  const year = Library.yearOf(clip);
  const tagPad = Math.round(kick * 0.38);
  const kicker = plan.kicker ?? 'ORA IN ONDA';
  const tagX = textX + Math.round(textWidth(ov.fontSemiBold, kick, kicker)) + Math.round(H * 0.018) + tagPad;
  const texts = [
    draw(ov.fontSemiBold, textFile(tmpDir, plan.id, 'kicker', kicker), kick, plan.kicker ? ov.accentText : '0xe9ebf0', textX, yKick, 0,
      plan.kicker ? `:box=1:boxcolor=${ov.accent}:boxborderw=${tagPad}|${Math.round(tagPad * 1.6)}` : ''),
    ...(year
      ? [draw(ov.fontSemiBold, textFile(tmpDir, plan.id, 'year', `ANNO ${year}`), kick, 'white', tagX, yKick, 0.04,
          `:box=1:boxcolor=white@0.18:boxborderw=${tagPad}|${Math.round(tagPad * 1.6)}`)]
      : []),
    // A smaller size keeps the box the same height: the text sits in its middle.
    draw(ov.fontBold, textFile(tmpDir, plan.id, 'artist', artist), artistFit.size, 'white', textX, yArtist + Math.round((big - artistFit.size) / 2), 0.08,
      box(padBig + Math.round((big - artistFit.size) / 2))),
    ...(title ? [draw(ov.font, textFile(tmpDir, plan.id, 'title', title), titleFit.size, '0xe2e5eb', textX, yTitle + Math.round((small - titleFit.size) / 2), 0.16,
      box(padSmall + Math.round((small - titleFit.size) / 2)))] : []),
  ];
  // The white bar grows down from the top of the block.
  const barH = (title ? bottom : yArtist - padBig + artistBoxH) - blockTop;
  const grow = windowMotion(S, E, { inDur: 0.45 });
  return [
    `color=c=white:s=${barW}x${barH}:r=${fps}:d=${sec(plan.length)},format=rgba[ltbar]`,
    `[${input}][ltbar]overlay=x=${x0}:y='${blockTop}-${barH}*(1-${easeOut(ramp(S, 0.45))})':eval=frame:` +
      `enable='${grow.enable}'[ltb]`,
    `[ltb]${texts.join(',')}[${output}]`,
  ].join(';');
}

function upNext(cfg: Config, plan: ClipGfxPlan, tmpDir: string, input: string, output: string): string {
  const next = plan.upNext!;
  const T = plan.nextAt!;
  const { width: W, height: H, fps } = cfg.output;
  const ov = cfg.overlay;
  const mx = ov.logo.marginX ?? ov.logo.margin;
  const my = ov.logo.marginY ?? ov.logo.margin;
  // Under the logo, right-aligned with it: a compact card, title over artist, never wider
  // than a quarter of the screen; a long title goes on two lines.
  const top = my + Math.round(ov.logo.width * (ov.logo.ratio ?? 0.42)) + Math.round(H * 0.022);
  const sc = gfxScale(cfg);
  const kick = Math.round(H * 0.0135 * sc);
  const tSize = Math.round(H * 0.0175 * sc);
  const aSize = Math.round(H * 0.0145 * sc);
  const maxW = Math.round(W * 0.25);
  const barH = Math.max(3, Math.round(H * 0.0035));
  const padK = Math.round(kick * 0.4);
  const padX = Math.round(tSize * 0.7);
  const padY = Math.round(tSize * 0.55);
  const lead = (size: number) => Math.round(size * 1.3);
  // Shown halfway through the clip for a while, then again before the change.
  const windows: [number, number][] = [];
  const len = ov.upNext.showSeconds;
  if (T > 90) windows.push([T * 0.5, T * 0.5 + len]);
  if (T > 20) windows.push([Math.max(1, T - ov.upNext.beforeSeconds), T - 0.4]);
  if (!windows.length) return `[${input}]null[${output}]`;

  const lines: { text: string; font: string; size: number; color: string }[] = [];
  const title = next.title || next.artist;
  if (textWidth(ov.fontSemiBold, tSize, title) <= maxW) {
    lines.push({ text: title, font: ov.fontSemiBold, size: tSize, color: 'white' });
  } else {
    const small = Math.round(tSize * 0.92);
    const [l1, l2] = twoLines(ov.fontSemiBold, small, title, maxW);
    for (const l of [l1, l2].filter(Boolean)) lines.push({ text: l, font: ov.fontSemiBold, size: small, color: 'white' });
  }
  if (next.artist && next.title) {
    const a = shrinkToFit(ov.font, aSize, next.artist, maxW, 0.85);
    lines.push({ text: a.text, font: ov.font, size: a.size, color: '0xb9bec8' });
  }
  const textW = Math.max(...lines.map((l) => textWidth(l.font, l.size, l.text)));
  const boxW = Math.round((Math.ceil(textW) + 2 * padX) / 2) * 2;
  const boxH = Math.round((lines.reduce((h, l) => h + lead(l.size), 0) + 2 * padY - Math.round(lines[lines.length - 1].size * 0.3)) / 2) * 2;
  const boxX = W - mx - boxW;
  const yKick = top + padK;
  const yBox = yKick + kick + padK + Math.round(H * 0.005);
  const yBar = yBox + boxH;
  const kickFile = textFile(tmpDir, plan.id, 'next-kicker', 'A SEGUIRE');
  const lineFiles = lines.map((l, i) => textFile(tmpDir, plan.id, `next-${i}`, l.text));
  const parts: string[] = [];
  let cur = input;
  windows.forEach(([s, e], i) => {
    const m = windowMotion(s, e, { dy: Math.round(H * 0.012), inDur: 0.5, outDur: 0.4 });
    const fades = `fade=t=in:st=${sec(s)}:d=0.5:alpha=1,fade=t=out:st=${sec(e - 0.4)}:d=0.4:alpha=1`;
    // The bar shows how much is left of the song: in the last window it fills from empty to
    // full right at the change, so the end coming up reads at a glance.
    const from = i === windows.length - 1 ? s : 0;
    const fill = `clip((t-${sec(from)})/${sec(T - from)},0,1)`;
    parts.push(
      `color=c=0x0b0e17@0.82:s=${boxW}x${boxH}:r=${fps}:d=${sec(plan.length)},format=rgba,${fades}[unbox${i}]`,
      `color=c=0x3a3f4a:s=${boxW}x${barH}:r=${fps}:d=${sec(plan.length)},format=rgba[untrack${i}]`,
      `color=c=${ov.accent}:s=${boxW}x${barH}:r=${fps}:d=${sec(plan.length)},format=rgba[unfill${i}]`,
      `[untrack${i}][unfill${i}]overlay=x='-w+w*${fill}':y=0:eval=frame,format=rgba,${fades}[unbar${i}]`,
      `[${cur}][unbox${i}]overlay=x=${boxX}:y='${yBox}+${m.y}':eval=frame:enable='${m.enable}'[unx${i}]`,
      `[unx${i}][unbar${i}]overlay=x=${boxX}:y='${yBar}+${m.y}':eval=frame:enable='${m.enable}'[unb${i}]`,
    );
    const draws = [
      `drawtext=fontfile=${filterValue(ov.fontSemiBold)}:textfile=${kickFile}:expansion=none:fontsize=${kick}:fontcolor=${ov.accentText}` +
        `:box=1:boxcolor=${ov.accent}:boxborderw=${padK}|${padX}:x=${boxX + padX}:y='${yKick}+${m.y}':alpha='${m.alpha}':enable='${m.enable}'`,
    ];
    let y = yBox + padY;
    lines.forEach((l, j) => {
      draws.push(`drawtext=fontfile=${filterValue(l.font)}:textfile=${lineFiles[j]}:expansion=none:fontsize=${l.size}:fontcolor=${l.color}` +
        `:x=${boxX + padX}:y='${y}+${m.y}':alpha='${m.alpha}':enable='${m.enable}'`);
      y += lead(l.size);
    });
    parts.push(`[unb${i}]${draws.join(',')}[unt${i}]`);
    cur = `unt${i}`;
  });
  parts.push(`[${cur}]null[${output}]`);
  return parts.join(';');
}

/**
 * The televoto winner, at the start of its clip: a big card in the middle of the screen,
 * "HA VINTO IL TELEVOTO", the title, the artist and the share, rising in and fading out.
 */
function winnerReveal(cfg: Config, plan: ClipGfxPlan, tmpDir: string, input: string, output: string): string {
  const w = plan.winner!;
  const { width: W, height: H, fps } = cfg.output;
  const ov = cfg.overlay;
  const gold = ov.accent.toLowerCase() === '0xffffff' ? '0xf2c14e' : ov.accent;
  const sc = Math.min(gfxScale(cfg), 1.3);
  const u = (k: number) => Math.round(H * k * sc);
  const S = 0.6;
  const E = Math.min(plan.length - 1, 11);
  const maxW = Math.round(W * 0.62);
  const kick = u(0.028);
  const title = shrinkToFit(ov.fontBold, u(0.072), w.title, maxW, 0.55);
  const artist = shrinkToFit(ov.font, u(0.04), w.artist || ' ', maxW, 0.6);
  const share = u(0.03);
  const padX = u(0.04);
  const boxW = Math.round((Math.max(textWidth(ov.fontBold, title.size, title.text), textWidth(ov.font, artist.size, artist.text), W * 0.36) + 2 * padX) / 2) * 2;
  const boxH = Math.round((kick * 2.2 + title.size * 1.25 + artist.size * 1.35 + share * 1.9 + u(0.05)) / 2) * 2;
  const avail = H - tickerLayout(cfg).bar;
  const bx = Math.round((W - boxW) / 2);
  const by = Math.round((avail - boxH) / 2);
  const rise = `${u(0.03)}*pow(1-clip((t-${sec(S)})/0.6\,0\,1)\,3)`;
  const kickText = 'HA VINTO IL TELEVOTO';
  const shareText = `con il ${w.share}% dei voti`;
  const kickW = Math.round(textWidth(ov.fontBold, kick, kickText) + kick * 1.4);
  let y = u(0.03);
  const yKick = y;
  y += Math.round(kick * 2.2);
  const yTitle = y;
  y += Math.round(title.size * 1.25);
  const yArtist = y;
  y += Math.round(artist.size * 1.35);
  const yShare = y + Math.round(share * 0.3);
  const mid = Math.round(boxW / 2);
  const ink = ov.accentText === '0x0B0E17' ? '#111111' : hex(ov.accentText);
  // Drawn once as a picture; ffmpeg only fades it and lifts it into place.
  const card = svgPng(tmpDir, 'voto-vincitore', `<svg xmlns="http://www.w3.org/2000/svg" width="${boxW}" height="${boxH}">` +
    `<rect width="${boxW}" height="${boxH}" fill="#0b0e17" fill-opacity="0.92"/><rect width="${boxW}" height="${Math.max(4, Math.round(H * 0.006))}" fill="${hex(gold)}"/>` +
    `<rect x="${mid - Math.round(kickW / 2)}" y="${yKick - Math.round(kick * 0.3)}" width="${kickW}" height="${Math.round(kick * 1.6)}" fill="${hex(gold)}"/>` +
    svgText(mid, yKick, kick, 700, ink, kickText, 'middle') +
    svgText(mid, yTitle, title.size, 700, '#fff', title.text, 'middle') +
    svgText(mid, yArtist, artist.size, 500, '#c7ccd6', artist.text, 'middle') +
    svgText(mid, yShare, share, 600, hex(gold), shareText, 'middle') + '</svg>');
  const frames = Math.max(1, Math.round((E - S) * fps));
  return [
    `movie=${filterValue(card)},loop=loop=${frames}:size=1:start=0,setpts=N/(${fps}*TB)+${sec(S)}/TB,format=rgba,` +
      `fade=t=in:st=${sec(S)}:d=0.5:alpha=1,fade=t=out:st=${sec(E - 0.6)}:d=0.6:alpha=1[wrcard]`,
    `[${input}][wrcard]overlay=x=${bx}:y='${by}+${rise}':eval=frame:eof_action=pass:enable='between(t,${sec(S)},${sec(E)})'[${output}]`,
  ].join(';');
}

const xml = (t: string) => t.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

/** An SVG drawn once to a PNG with the bundled fonts (as the info cards), kept while its content is the same. */
function svgPng(tmpDir: string, name: string, svg: string): string {
  const file = path.join(tmpDir, `${name}-${crypto.createHash('sha1').update(svg).digest('hex').slice(0, 12)}.png`);
  if (!fs.existsSync(file)) {
    fs.writeFileSync(file, new Resvg(svg, {
      font: { fontFiles: ['Medium', 'SemiBold', 'Bold'].map((w) => assetPath(`assets/fonts/Poppins-${w}.ttf`)), loadSystemFonts: false, defaultFontFamily: 'Poppins' },
    }).render().asPng());
  }
  return file;
}

/** SVG text at the top-left corner (x, y) like drawtext, Poppins of the given weight. */
const svgText = (x: number, y: number, size: number, weight: number, fill: string, text: string, anchor = 'start') =>
  `<text x="${x}" y="${y + Math.round(size * 0.94)}" font-family="Poppins" font-weight="${weight}" font-size="${size}" fill="${fill}" text-anchor="${anchor}">${xml(text)}</text>`;
const hex = (c: string) => `#${c.replace(/^0x/i, '').slice(0, 6)}`;

/**
 * Televoto. Now and then the screen becomes the vote, fading in over the clip: a still of the
 * clip blurred behind, a large QR on the left with the time left counting down, the round's
 * songs on the right as cards sliding in, each filling up with its live share of the votes.
 * Everything that does not change is drawn once as pictures (QR, cards, titles); only the
 * shares, their bars and the countdown are drawn by ffmpeg, so the decoder stays light.
 * In between, a small card with the QR invites to vote.
 */
function votePanel(cfg: Config, plan: ClipGfxPlan, tmpDir: string, input: string, output: string): string {
  const v = plan.vote!;
  const { width: W, height: H, fps } = cfg.output;
  const ov = cfg.overlay;
  const gold = ov.accent.toLowerCase() === '0xffffff' ? '0xf2c14e' : ov.accent;
  const avail = H - tickerLayout(cfg).bar;
  const u = (k: number) => Math.round(H * k);
  const m = u(0.052);
  // The clock with the song next to it and the logo stay on top of everything (the encoder
  // draws them, like the ticker): the vote screen starts below them and ends above the ticker.
  const TL = topLeftLayout(cfg);
  const logoBottom = (ov.logo.marginY ?? ov.logo.margin) + Math.round(ov.logo.width * (ov.logo.ratio ?? 0.42));
  const top = Math.max(m, logoBottom, TL.metaBaseline + Math.round(TL.metaSize * 0.4)) + u(0.03);
  const sc = gfxScale(cfg);
  const head = Math.round(Math.min(u(0.034) * Math.min(sc, 1.25), u(0.045)));
  const qrY = top + Math.round(head * 1.75);
  const say = Math.round(u(0.026) * Math.min(sc, 1.25));
  const small = Math.round(u(0.018) * Math.min(sc, 1.25));
  const cdSize = Math.round(u(0.024) * Math.min(sc, 1.25));
  const textsH = u(0.022) + Math.round(say * 1.5) + Math.round(cdSize * 1.5) + Math.round(small * 1.5) * 2;
  const Q = Math.round(Math.max(H * 0.22, Math.min(H * 0.45, W * 0.28, avail - m - qrY - textsH)) / 2) * 2;
  const colX = m + Q + u(0.05);
  const colW = W - m - colX;
  // The songs in two columns of five (one column for a short round): numbers go down the first
  // column, then the second.
  const n = v.songs.length;
  const cols = n > 6 ? 2 : 1;
  const rows = Math.ceil(n / cols);
  const gap = u(0.012);
  const cardW = Math.floor((colW - gap * (cols - 1)) / cols);
  const rowH = Math.floor((avail - m - qrY + gap) / Math.max(1, rows));
  const cardH = rowH - gap;
  const at = (j: number) => ({ x: Math.floor(j / rows) * (cardW + gap), y: (j % rows) * rowH });
  const pad = Math.round(cardH * 0.16);
  const circle = Math.round(Math.min(cardH * 0.62, u(0.05) * sc) / 2) * 2;
  const tSize = Math.min(Math.round(cardH * 0.3), Math.round(u(0.024) * sc));
  const aSize = Math.round(tSize * 0.78);
  const pSize = Math.round(tSize * 1.1);
  const textDX = pad + circle + Math.round(pad * 0.9);
  const pctW = Math.round(textWidth(ov.fontBold, pSize, '100%'));
  const textW = cardW - textDX - pctW - Math.round(pad * 1.5);
  const listH = rows * rowH;
  const cdY = qrY + Q + u(0.022) + Math.round(say * 1.5);

  // The left column: header, QR, what to do, when the winner airs, the address (two versions
  // of the header: the usual one, and the last seconds of the round).
  const qrm = qrMatrix(v.url);
  const mod = Q / (qrm.length + 8);
  let qrRects = '';
  qrm.forEach((row, y) => row.forEach((d, x) => {
    if (d) qrRects += `<rect x="${(m + (x + 4) * mod).toFixed(2)}" y="${(qrY + (y + 4) * mod).toFixed(2)}" width="${(mod + 0.4).toFixed(2)}" height="${(mod + 0.4).toFixed(2)}"/>`;
  }));
  const sayFit = shrinkToFit(ov.fontBold, say, 'Inquadra il QR e vota', Q, 0.6);
  const airsFit = shrinkToFit(ov.font, small, v.airsAt ? `il più votato va in onda verso le ${v.airsAt}` : 'il più votato va in onda poco dopo', Q, 0.65);
  const urlFit = shrinkToFit(ov.font, small, v.url.replace(/^https?:\/\//, ''), Q, 0.65);
  const leftW = m + Q + u(0.02);
  const left = (header: string, color: string) => svgPng(tmpDir, 'voto-sinistra', `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${avail}">` +
    svgText(m, top, head, 700, color, header) +
    `<rect x="${m}" y="${qrY}" width="${Q}" height="${Q}" rx="${Math.round(Q * 0.03)}" fill="#fff"/><g fill="#000" shape-rendering="crispEdges">${qrRects}</g>` +
    svgText(m, qrY + Q + u(0.022), sayFit.size, 700, '#fff', sayFit.text) +
    svgText(m, cdY + Math.round(cdSize * 1.5), airsFit.size, 500, '#fff', airsFit.text) +
    svgText(m, cdY + Math.round(cdSize * 1.5) + Math.round(small * 1.5), urlFit.size, 500, '#a9b0bd', urlFit.text) +
    '</svg>');
  const leftNormal = left(fitWidth(ov.fontBold, head, 'VOTA IL BRANO CHE VUOI SENTIRE', W - 2 * m), '#fff');
  const leftFinal = left(fitWidth(ov.fontBold, head, 'ULTIMI SECONDI PER VOTARE!', W - 2 * m - Math.round(head * 4)), hex(gold));
  void leftW;

  // The cards (under the share bars) and their texts (over them), with whole titles: a long
  // one is drawn a little smaller, and cut only if it still does not fit.
  let cardsSvg = '';
  let textsSvg = '';
  v.songs.forEach((sg, j) => {
    const { x, y } = at(j);
    const mid = y + Math.round(cardH / 2);
    cardsSvg += `<rect x="${x}" y="${y}" width="${cardW}" height="${cardH}" rx="${u(0.013)}" fill="#1b2130" fill-opacity="0.98"/>` +
      `<circle cx="${x + pad + circle / 2}" cy="${mid}" r="${circle / 2}" fill="#2a3142"/>`;
    const title = shrinkToFit(ov.fontSemiBold, tSize, sg.title || sg.artist, textW, 0.7);
    const artist = sg.title ? shrinkToFit(ov.font, aSize, sg.artist, textW, 0.75) : { text: '', size: aSize };
    const blockH = tSize + Math.round(tSize * 0.3) + aSize;
    const ty = mid - Math.round(blockH / 2);
    const num = Math.round(circle * 0.48);
    textsSvg += `<text x="${x + pad + circle / 2}" y="${mid + Math.round(num * 0.36)}" font-family="Poppins" font-weight="700" font-size="${num}" fill="#fff" text-anchor="middle">${sg.n}</text>` +
      svgText(x + textDX, ty + Math.round((tSize - title.size) * 0.6), title.size, 600, '#fff', title.text) +
      (artist.text ? svgText(x + textDX, ty + tSize + Math.round(tSize * 0.3), artist.size, 500, '#b9bec8', artist.text) : '');
  });
  const cardsPng = svgPng(tmpDir, 'voto-schede', `<svg xmlns="http://www.w3.org/2000/svg" width="${colW}" height="${listH}">${cardsSvg}</svg>`);
  const textsPng = svgPng(tmpDir, 'voto-testi', `<svg xmlns="http://www.w3.org/2000/svg" width="${colW}" height="${listH}">${textsSvg}</svg>`);

  // The share bar: as many letters "M" as half the share, invisible on a coloured box; 50 of
  // them span the card. Their box is as tall as a capital (0.72 of the size), padded to the card.
  // The bar stays inside the card, a little in from its rounded edges, also at 100%.
  const barIn = Math.max(2, Math.round(cardH * 0.09));
  const mW = textWidth(ov.fontSemiBold, 100, 'M') / 100;
  const barSize = Math.max(6, Math.floor((cardW - 2 * barIn) / 50 / mW));
  const barPad = Math.max(0, Math.round((cardH - 2 * barIn - barSize * 0.72) / 2));

  // The invitation card: box, QR and texts drawn once.
  // Large enough to read from across the room on a big screen.
  const bs = Math.min(1.4, Math.max(1, sc));
  const bq = Math.round(u(0.15) * bs);
  const bpad = Math.round(u(0.014) * bs);
  const b1 = Math.round(u(0.034) * bs);
  const b2 = Math.round(u(0.026) * bs);
  const inv1 = 'Vota il brano che vuoi sentire';
  const inv2 = `si vota fino alle ${v.closesAt}`;
  const bw = bq + 3 * bpad + Math.round(Math.max(textWidth(ov.fontBold, b1, inv1), textWidth(ov.fontSemiBold, b2, inv2)));
  const bh = bq + 2 * bpad;
  const bx = W - (ov.logo.marginX ?? ov.logo.margin) - bw;
  const by = avail - u(0.03) - bh;
  const bmod = bq / (qrm.length + 8);
  let bRects = '';
  qrm.forEach((row, y) => row.forEach((d, x) => {
    if (d) bRects += `<rect x="${(bpad + (x + 4) * bmod).toFixed(2)}" y="${(bpad + (y + 4) * bmod).toFixed(2)}" width="${(bmod + 0.3).toFixed(2)}" height="${(bmod + 0.3).toFixed(2)}"/>`;
  }));
  const invite = svgPng(tmpDir, 'voto-invito', `<svg xmlns="http://www.w3.org/2000/svg" width="${bw}" height="${bh}">` +
    `<rect width="${bw}" height="${bh}" fill="#0b0e17" fill-opacity="0.9"/>` +
    `<rect x="${bpad}" y="${bpad}" width="${bq}" height="${bq}" fill="#fff"/><g fill="#000" shape-rendering="crispEdges">${bRects}</g>` +
    svgText(bq + 2 * bpad, Math.round(bh / 2) - b1 - Math.round(b1 * 0.15), b1, 700, '#fff', inv1) +
    svgText(bq + 2 * bpad, Math.round(bh / 2) + Math.round(b2 * 0.3), b2, 600, hex(gold), inv2) + '</svg>');

  const parts: string[] = [];
  let cur = input;
  (v.invites ?? []).forEach(([s, e], i) => {
    const frames = Math.max(1, Math.round((e - s) * fps));
    parts.push(
      `movie=${filterValue(invite)},loop=loop=${frames}:size=1:start=0,setpts=N/(${fps}*TB)+${sec(s)}/TB,format=rgba,` +
        `fade=t=in:st=${sec(s)}:d=0.5:alpha=1,fade=t=out:st=${sec(e - 0.5)}:d=0.5:alpha=1[vinv${i}]`,
      `[${cur}][vinv${i}]overlay=x=${bx}:y=${by}:eof_action=pass:enable='between(t,${sec(s)},${sec(e)})'[viz${i}]`,
    );
    cur = `viz${i}`;
  });

  v.windows.forEach(([s, e, final], i) => {
    const len = e - s;
    const frames = Math.max(1, Math.round(len * fps));
    const fades = `fade=t=in:st=0:d=0.6:alpha=1,fade=t=out:st=${sec(len - 0.6)}:d=0.6:alpha=1`;
    // The list slides in from the right as the screen appears.
    const off = `${Math.round(W * 0.3)}*pow(1-clip((t-0.15)/0.75\,0\,1)\,3)`;
    // Time left, counted by ffmpeg itself on the window's clock, so it matches what is on air.
    const C = (v.closesIn ?? plan.length) - s;
    const cd = path.join(tmpDir, `seg${plan.id}-vote-cd${i}.txt`);
    fs.writeFileSync(cd, `%{eif:trunc(max(0,${C.toFixed(2)}-t)/60):d}:%{eif:mod(trunc(max(0,${C.toFixed(2)}-t)),60):d:2}`);
    const cdW = Math.round(textWidth(ov.fontBold, cdSize, '00:00'));
    const barX = m + cdW + u(0.016);
    const barW = Math.max(10, m + Q - barX);
    const barH = u(0.0075);
    const total = Math.max(1, v.roundSecs ?? 600);
    const live: string[] = [
      `drawtext=fontfile=${filterValue(ov.fontBold)}:textfile=${filterValue(cd)}:expansion=normal:fontsize=${cdSize}:fontcolor=${gold}:x=${m}:y=${cdY}`,
      ...(final ? [`drawtext=fontfile=${filterValue(ov.fontBold)}:textfile=${filterValue(cd)}:expansion=normal:fontsize=${Math.round(head * 1.6)}:fontcolor=${gold}:x=${W - m}-tw:y=${top - Math.round(head * 0.35)}`] : []),
    ];
    const bars: string[] = [];
    v.songs.forEach((_, j) => {
      const p0 = at(j);
      const cx = colX + p0.x;
      const cy = qrY + p0.y;
      const mid = cy + Math.round(cardH / 2);
      if (v.bars?.[j]) {
        bars.push(`drawtext=fontfile=${filterValue(ov.fontSemiBold)}:textfile=${filterValue(v.bars[j])}:reload=${fps}:expansion=none:` +
          `fontsize=${barSize}:fontcolor=white@0:box=1:boxcolor=${gold}@0.32:boxborderw=${barPad}|0:x='${cx + barIn}+${off}':y=${cy + barIn + barPad}`);
      }
      live.push(`drawtext=fontfile=${filterValue(ov.fontBold)}:textfile=${filterValue(v.counts[j])}:reload=${fps}:expansion=none:fontsize=${pSize}:fontcolor=white:` +
        `x='${cx + cardW - pad}-tw+${off}':y=${mid}-${Math.round(pSize * 0.36)}`);
    });
    parts.push(
      `[${cur}]split=3[vw${i}a][vw${i}b][vw${i}c]`,
      `[vw${i}a]trim=end=${sec(s)},setpts=PTS-STARTPTS[vpre${i}]`,
      `[vw${i}b]trim=start=${sec(s)}:end=${sec(e)},setpts=PTS-STARTPTS,split[vm${i}a][vm${i}b]`,
      `[vw${i}c]trim=start=${sec(e)},setpts=PTS-STARTPTS[vpost${i}]`,
      // Behind: one still of the clip, blurred and darkened once, held for the whole window.
      `[vm${i}b]trim=end_frame=1,scale=${Math.round(W / 8 / 2) * 2}:${Math.round(H / 8 / 2) * 2}:flags=area,gblur=sigma=6,` +
        `eq=brightness=-0.42:saturation=0.45,scale=${W}:${H}:flags=bicubic,format=yuv420p,loop=loop=${frames}:size=1:start=0,setpts=N/(${fps}*TB)[vbg${i}]`,
      `movie=${filterValue(final ? leftFinal : leftNormal)}[vl${i}]`,
      `[vbg${i}][vl${i}]overlay=x=0:y=0[vb1${i}]`,
      `movie=${filterValue(cardsPng)}[vc${i}]`,
      `[vb1${i}][vc${i}]overlay=x='${colX}+${off}':y=${qrY}:eval=frame[vb2${i}]`,
      // The countdown bar: shrinks to nothing at the close.
      `color=c=white@0.18:s=${barW}x${barH}:r=${fps}:d=${sec(len)},format=rgba[vtr${i}]`,
      `color=c=${gold}:s=${barW}x${barH}:r=${fps}:d=${sec(len)},format=rgba[vfl${i}]`,
      `[vtr${i}][vfl${i}]overlay=x='-w*(1-clip((${C.toFixed(2)}-t)/${total},0,1))':y=0:eval=frame[vcb${i}]`,
      `[vb2${i}][vcb${i}]overlay=x=${barX}:y=${cdY + Math.round((cdSize * 0.72 - barH) / 2)}[vb3${i}]`,
      bars.length ? `[vb3${i}]${bars.join(',')}[vb4${i}]` : `[vb3${i}]null[vb4${i}]`,
      `movie=${filterValue(textsPng)}[vx${i}]`,
      `[vb4${i}][vx${i}]overlay=x='${colX}+${off}':y=${qrY}:eval=frame[vb5${i}]`,
      `[vb5${i}]${live.join(',')},format=yuva420p,${fades}[vsc${i}]`,
      `[vm${i}a][vsc${i}]overlay=0:0[vmid${i}]`,
      `[vpre${i}][vmid${i}][vpost${i}]concat=n=3:v=1:a=0[vt${i}]`,
    );
    cur = `vt${i}`;
  });
  parts.push(`[${cur}]null[${output}]`);
  return parts.join(';');
}

/**
 * Next to the clock (drawn by the encoder on the same grid, see
 * topLeftLayout): a thin divider, the title, and "Artist · year" below it.
 * Fades in with a short rise when the clip starts, out when it ends.
 */
function nowBadge(cfg: Config, plan: ClipGfxPlan, tmpDir: string, input: string, output: string): string {
  const clip = plan.clip!;
  const { fps, width: W } = cfg.output;
  const ov = cfg.overlay;
  const T = topLeftLayout(cfg);
  const year = Library.yearOf(clip);
  const sc = gfxScale(cfg);
  const roomTop = Math.round(W * 0.55) - T.textX;
  const titleFit = shrinkToFit(ov.fontSemiBold, T.titleSize, clip.title, roomTop);
  const title = titleFit.text;
  const metaFit = shrinkToFit(ov.font, T.metaSize, [clip.artist, year].filter(Boolean).join('  ·  '), roomTop);
  const S = 0.6;
  const E = plan.length - 0.3;
  const pin = ramp(S, 0.4);
  const pout = ramp(E - 0.3, 0.3);
  const alpha = `'${pin}*(1-${pout})'`;
  const rise = (y: number) => `'${y}+8*(1-${easeOut(pin)})'`;
  const shadow = ':shadowcolor=black@0.4:shadowx=0:shadowy=2' + offVisuals(plan);
  return [
    `color=c=white@0.45:s=${T.sepW}x${T.sepH}:r=${fps}:d=${sec(plan.length)},format=rgba,` +
      `fade=t=in:st=${sec(S)}:d=0.4:alpha=1,fade=t=out:st=${sec(E - 0.3)}:d=0.3:alpha=1[npsep]`,
    `[${input}][npsep]overlay=x=${T.sepX}:y=${T.sepY}:eof_action=pass${offVisuals(plan)}[nps]`,
    `[nps]drawtext=fontfile=${filterValue(ov.fontSemiBold)}:textfile=${textFile(tmpDir, plan.id, 'np', title)}:expansion=none:` +
      `fontsize=${titleFit.size}:fontcolor=white${shadow}:x=${T.textX}:y=${rise(T.titleBaseline)}:y_align=baseline:alpha=${alpha},` +
      `drawtext=fontfile=${filterValue(ov.font)}:textfile=${textFile(tmpDir, plan.id, 'npy', metaFit.text || ' ')}:expansion=none:` +
      `fontsize=${metaFit.size}:fontcolor=0xb9bec8${shadow}:x=${T.textX}:y=${rise(T.metaBaseline)}:y_align=baseline:alpha=${alpha}[${output}]`,
  ].join(';');
}

/** All clip graphics from `[input]` to `[output]`. */
export function clipGraphics(cfg: Config, plan: ClipGfxPlan, tmpDir: string, input: string, output: string): string {
  const parts: string[] = [];
  let cur = input;
  const clip = plan.clip;
  if (clip && plan.titleAt !== null && cfg.overlay.nowPlaying.enabled && Math.min(plan.length - 0.5, plan.titleAt + cfg.overlay.nowPlaying.showSeconds) - plan.titleAt >= 2) {
    parts.push(lowerThird(cfg, plan, tmpDir, cur, 'cg1'));
    cur = 'cg1';
  }
  if (clip && cfg.overlay.nowPlaying.enabled && clip.type === 'music') {
    parts.push(nowBadge(cfg, plan, tmpDir, cur, 'cg0'));
    cur = 'cg0';
  }
  if (cfg.overlay.upNext.enabled && plan.upNext && plan.nextAt) {
    parts.push(upNext(cfg, plan, tmpDir, cur, 'cg2'));
    cur = 'cg2';
  }
  if (plan.winner) {
    parts.push(winnerReveal(cfg, plan, tmpDir, cur, 'cg4'));
    cur = 'cg4';
  }
  // Last, so the vote screen shrinks the picture together with its graphics.
  if (plan.vote && (plan.vote.windows.length || plan.vote.invites?.length)) {
    parts.push(votePanel(cfg, plan, tmpDir, cur, 'cg3'));
    cur = 'cg3';
  }
  parts.push(`[${cur}]null[${output}]`);
  return parts.join(';');
}
