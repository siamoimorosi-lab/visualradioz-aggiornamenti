import fs from 'node:fs';
import path from 'node:path';
import { EventEmitter } from 'node:events';
import { type Config, resolvePath } from './config.ts';
import type { Clip, Library } from './library.ts';
import type { BreakOccurrence, BreakRule, ScheduleBook } from './schedule.ts';
import { Playlist, type Played } from './playlist.ts';

/**
 * How early a break may start. Soft breaks start when the clip before them
 * ends; hard ones cut that clip at the exact time, so they only start early
 * to avoid playing a few seconds of a clip.
 */
const SOFT_EARLY_MS = 10_000;
const HARD_EARLY_MS = 6_000;

/**
 * Chooses what plays next, in this order: the rest of an ad block, a break
 * that is due, the manual queue, the planned playlist (see Playlist).
 */
export class Scheduler extends EventEmitter {
  queue: string[] = [];
  /** Queued clips that may wait one clip when they would break a sequence rule (televoto winners). */
  deferrable = new Set<string>();
  history: Played[] = [];
  private fired: string[] = [];
  private breakQueue: string[] = [];
  /** Name of the ad block on air or being queued, for the panel. */
  activeBreak: string | null = null;
  private file: string;
  private cfg: Config;
  private lib: Library;
  book: ScheduleBook;
  playlist: Playlist;

  constructor(cfg: Config, lib: Library, book: ScheduleBook) {
    super();
    this.cfg = cfg;
    this.lib = lib;
    this.book = book;
    this.file = path.join(resolvePath(cfg.dataDir), 'scheduler.json');
    try {
      const s = JSON.parse(fs.readFileSync(this.file, 'utf8'));
      this.queue = s.queue ?? [];
      this.history = s.history ?? [];
      this.fired = s.fired ?? [];
      this.breakQueue = s.breakQueue ?? [];
    } catch {
      // first run
    }
    this.playlist = new Playlist(cfg, lib, book, () => this.history);
    this.playlist.on('relaxed', (rule) => this.emit('relaxed', rule));
    this.playlist.on('backup', (slot, from) => this.emit('backup', slot, from));
    this.playlist.on('slot-skipped', (slot) => this.emit('slot-skipped', slot));
    this.playlist.on('repeat', (clip) => this.emit('repeat', clip));
  }

  /** New clocks or rotation rules: plan the playlist again. `locked` = clips already committed to air. */
  setSchedule(book: ScheduleBook, locked: Clip[]) {
    if (book !== this.book) book.override = this.book.override;
    this.book = book;
    this.playlist.book = book;
    this.playlist.regenerate(locked, this.playlist.items[0]?.at ?? Date.now());
  }

  private save() {
    this.history = this.history.slice(-4000);
    this.fired = this.fired.slice(-500);
    const data = { queue: this.queue, history: this.history, fired: this.fired, breakQueue: this.breakQueue };
    fs.writeFileSync(this.file, JSON.stringify(data));
  }

  enqueue(id: string, front = false) {
    if (!this.lib.get(id)) throw new Error('clip sconosciuto');
    if (front) this.queue.unshift(id);
    else this.queue.push(id);
    this.save();
  }

  removeFromQueue(index: number) {
    this.queue.splice(index, 1);
    this.save();
  }

  moveInQueue(from: number, to: number) {
    const [id] = this.queue.splice(from, 1);
    if (id !== undefined) this.queue.splice(Math.max(0, Math.min(to, this.queue.length)), 0, id);
    this.save();
  }

  markPlayed(clip: Clip, at = Date.now()) {
    this.history.push({ id: clip.id, artist: clip.artist.toLowerCase(), type: clip.type, at });
    this.save();
  }

  /** Air a break's block as soon as possible, outside its schedule. */
  fireNow(name: string) {
    const rule = this.book.sched.breaks.find((b) => b.name === name);
    if (!rule) throw new Error('break sconosciuto');
    const block = this.buildBlock(rule, []);
    if (!block.length) throw new Error('nessuno spot disponibile per questo break');
    this.breakQueue.unshift(...block.map((c) => c.id));
    this.activeBreak = rule.name;
    this.save();
  }

  // ---------------------------------------------------------------- picking

  /** True while only songs may air (the visuals hours). */
  musicOnly: (at: number) => boolean = () => false;

  /** `locked` = clips already committed to air; `at` = expected start time (ms). */
  next(locked: Clip[], at: number): Clip | null {
    // Visuals hours: only songs under the visuals, no breaks, jingles or spots (a break left
    // for later airs after the visuals if it is still in time, otherwise it is missed).
    if (this.musicOnly(at)) {
      const head = this.queue.length ? this.lib.get(this.queue[0]) : undefined;
      if (head?.type === 'music') {
        const q = this.takeFrom(this.queue);
        if (q) return q;
      }
      for (let i = 0; i < 12; i++) {
        const c = this.playlist.take(locked, at);
        if (!c) break;
        if (c.type === 'music') return c;
      }
      return this.lib.playable().find((x) => x.type === 'music' && !locked.includes(x)) ?? null;
    }
    const fromBreak = this.takeFrom(this.breakQueue);
    if (fromBreak) return fromBreak;
    this.activeBreak = null;

    const due = this.dueBreak(at);
    if (due) {
      this.fired.push(due.key);
      const block = this.buildBlock(due.rule, locked);
      this.save();
      if (block.length) {
        this.activeBreak = due.rule.name;
        this.breakQueue = block.slice(1).map((c) => c.id);
        this.save();
        this.emit('break', due, block);
        return block[0];
      }
      this.emit('break-empty', due);
    }

    // The manual queue goes first, but never two jingles in a row.
    const afterJingle = locked.some((x) => x.type === 'jingle');
    const head = this.queue.length ? this.lib.get(this.queue[0]) : undefined;
    // A televoto winner right after a clip it may not follow (two Italian songs in a row): one
    // clip of the rotation goes first, then the winner.
    if (head && this.deferrable.has(head.id)) {
      this.deferrable.delete(head.id);
      const recent = locked.filter((x) => x.type === 'music');
      if (!this.playlist.sequenceOk(head, recent)) {
        const other = this.playlist.take(locked, at);
        if (other) return other;
      }
    }
    const queued = afterJingle && head?.type === 'jingle' ? null : this.takeFrom(this.queue);
    return queued ?? this.playlist.take(locked, at) ?? this.lib.playable().find((x) => !locked.includes(x)) ?? null;
  }

  private takeFrom(list: string[]): Clip | null {
    while (list.length) {
      const c = this.lib.get(list.shift()!);
      this.save();
      if (c && this.lib.isPlayable(c)) return c;
    }
    return null;
  }

  /** The first break whose time has come (or nearly), marking ones that are too late as missed. */
  private dueBreak(at: number): BreakOccurrence | null {
    const maxLate = Math.max(...this.book.sched.breaks.map((b) => b.maxLateMinutes ?? 10), 0) * 60_000;
    // Older occurrences are simply past (e.g. while the channel was off), not missed.
    for (const occ of this.book.breaksBetween(at - maxLate, at + Math.max(SOFT_EARLY_MS, HARD_EARLY_MS))) {
      if (this.fired.includes(occ.key)) continue;
      const early = occ.rule.mode === 'hard' ? HARD_EARLY_MS : SOFT_EARLY_MS;
      if (occ.at > at + early) continue;
      if (at - occ.at > (occ.rule.maxLateMinutes ?? 10) * 60_000) {
        this.fired.push(occ.key);
        this.emit('break-missed', occ);
        continue;
      }
      return occ;
    }
    return null;
  }

  /** Next hard break not yet aired with its time in (from, to], for the engine to cut at. */
  hardBreakBetween(from: number, to: number): number | null {
    const occ = this.book.breaksBetween(from + 1, to).find((o) => o.rule.mode === 'hard' && !this.fired.includes(o.key));
    return occ ? occ.at : null;
  }

  upcomingBreaks(now: number, hours = 6) {
    return this.book.breaksBetween(now - 60_000, now + hours * 3600_000)
      .filter((o) => !this.fired.includes(o.key))
      .slice(0, 12)
      .map((o) => ({ name: o.rule.name, at: o.at, mode: o.rule.mode }));
  }

  /** `onAir` = the clip on air, to show its slot. */
  status(now: number, onAir?: Clip | null) {
    const { name, clock } = this.book.clockAt(now);
    const slot = onAir ? this.playlist.slotOf.get(onAir.id) : undefined;
    return {
      clock: name,
      slots: clock.slots,
      slotIndex: slot ? clock.slots.indexOf(slot) : -1,
      activeBreak: this.activeBreak,
      breakRemaining: this.breakQueue.length,
      breaks: this.book.sched.breaks.map((b) => b.name),
      upcoming: this.upcomingBreaks(now),
    };
  }

  private buildBlock(rule: BreakRule, locked: Clip[]): Clip[] {
    const spots: Clip[] = [];
    let total = 0;
    const count = rule.count ?? (rule.maxSeconds ? Infinity : 3);
    for (const c of this.leastRecent(this.lib.playable(rule.pool), locked)) {
      if (spots.length >= count) break;
      const d = c.cueOut - c.cueIn;
      if (rule.maxSeconds && total + d > rule.maxSeconds) continue;
      spots.push(c);
      total += d;
    }
    if (!spots.length) return [];
    const intro = rule.intro ? this.lib.findByName(rule.intro) : undefined;
    const outro = rule.outro ? this.lib.findByName(rule.outro) : undefined;
    return [...(intro ? [intro] : []), ...spots, ...(outro ? [outro] : [])];
  }

  private lastPlayedMap(): Map<string, number> {
    const m = new Map<string, number>();
    for (const h of this.history) m.set(h.id, h.at);
    return m;
  }

  private leastRecent(clips: Clip[], locked: Clip[]): Clip[] {
    const last = this.lastPlayedMap();
    return clips.filter((c) => !locked.includes(c)).sort((a, b) => (last.get(a.id) ?? 0) - (last.get(b.id) ?? 0));
  }
}
