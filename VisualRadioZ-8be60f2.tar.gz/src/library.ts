import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { EventEmitter } from 'node:events';
import { type Config, resolvePath } from './config.ts';
import { FFMPEG, FFPROBE, run } from './ffmpeg.ts';
import { type ExternalCue, guidOf, loadZettaCues, parseTime } from './zetta.ts';
import { categoryMatches, fieldsOf, parts } from './filters.ts';

export interface Clip {
  id: string;
  file: string;
  type: string;
  category: string;
  artist: string;
  title: string;
  album: string;
  /** Release year from the file's date tag. */
  tagYear?: string;
  /** Every tag of the file (genre, comment, track…), names in lower case: for the filter categories. */
  tags?: Record<string, string>;
  size: number;
  mtimeMs: number;
  duration: number;
  width: number;
  height: number;
  hasAudio: boolean;
  /** Where the file's sound track ends (seconds); null when the file does not say. */
  soundEnd?: number | null;
  /** Read again in the background (it stays on air meanwhile): a field added later is missing. */
  recheck?: boolean;
  /** Seconds of picture left after the sound ends, when far too many: the clip is cut at the end of its sound. */
  silentTail?: number;
  /** Integrated loudness in LUFS, null when there is no audio or not measured yet. */
  lufs: number | null;
  /** Effective cue points (seconds in the file), see resolveCues(). */
  cueIn: number;
  /** End of audible/visible content: the outgoing tail plays until here at most. */
  cueOut: number;
  /** Where the next clip starts, while this one fades ("segue" / mix out). */
  mixOut: number;
  /** Where the cue points come from. */
  cueSource: 'zetta' | 'auto' | 'none';
  /** Measured by our analysis. */
  auto?: { cueIn: number; cueOut: number; mixOut: number };
  /** From the Zetta archive. */
  ext?: ExternalCue;
  /** From the file's own tags (library.cueTags). */
  tagCue?: ExternalCue;
  analysisVersion?: number;
  /** Picture area without black bars baked into the file: [w, h, x, y]. */
  crop?: [number, number, number, number];
  /** Tags, duration and format read: the clip can go on air (cue 0/end, no gain). */
  probed: boolean;
  /** Loudness and cue points measured. */
  analyzed: boolean;
  error?: string;
  analysisError?: string;
}

type Folder = Config['library']['folders'][number];

/** Bump when analyze() learns something new, so clips are measured again. */
const ANALYSIS_VERSION = 3;
/** Shortest stretch between cue in and mix out that is still a plausible song. */
const MIN_BODY = 10;

/**
 * Effective cues: Zetta's points, else the ones written in the file's tags, when
 * present and plausible for this file; otherwise our measurements, otherwise the whole file.
 */
/** When set, the cue points written in the files' tags or in Zetta are not used. */
let measuredOnly = false;

export function resolveCues(c: Clip) {
  const d = c.duration;
  const a = c.auto;
  const e = measuredOnly ? undefined : c.ext ?? c.tagCue;
  const extIn = e?.start != null && e.start > 0 && e.start < d - MIN_BODY ? e.start : null;
  const cueIn = extIn ?? a?.cueIn ?? 0;
  const extMix = e?.mixOut != null && e.mixOut > cueIn + MIN_BODY && e.mixOut <= d + 0.5 ? Math.min(e.mixOut, d) : null;
  const mixOut = extMix ?? a?.mixOut ?? Math.max(cueIn, (a?.cueOut ?? d) - 2);
  c.cueIn = round(cueIn);
  // Jingles and other short items play to their end: the next one starts as they finish.
  c.mixOut = round(c.type === 'music' ? mixOut : Math.max(cueIn, (a?.cueOut ?? d) - 0.3));
  // The tail may run past the measured end when Zetta mixes later than our silence detection.
  c.cueOut = round(Math.max(a?.cueOut ?? d, Math.min(d, mixOut)));
  c.cueSource = extIn !== null || extMix !== null ? 'zetta' : a ? 'auto' : 'none';
  // A picture running on long after the sound (a broken or badly exported file): the clip
  // ends with its sound. A few seconds of picture after the song are normal and stay.
  delete c.silentTail;
  if (c.hasAudio && c.soundEnd != null && d - c.soundEnd > SILENT_TAIL_MAX) {
    c.silentTail = round(d - c.soundEnd);
    c.cueOut = round(Math.max(c.cueIn + MIN_BODY, Math.min(c.cueOut, c.soundEnd + 1)));
    c.mixOut = round(Math.max(c.cueIn, Math.min(c.mixOut, c.soundEnd)));
  }
}

/** Seconds of picture after the end of the sound beyond which the clip is cut at the end of its sound. */
const SILENT_TAIL_MAX = 15;

const VIDEO_EXT = new Set(['.mp4', '.m4v', '.mov', '.mkv', '.webm', '.avi', '.mpg', '.mpeg', '.ts', '.wmv', '.flv']);

/** Video files under `dir`, asynchronously: on a network share this takes a while and must not block the stream. */
async function walk(dir: string, out: string[] = []): Promise<string[]> {
  let entries: fs.Dirent[];
  try {
    entries = await fs.promises.readdir(dir, { withFileTypes: true });
  } catch {
    return out;
  }
  for (const e of entries) {
    const full = path.join(dir, e.name);
    if (e.isDirectory()) await walk(full, out);
    else if (VIDEO_EXT.has(path.extname(e.name).toLowerCase())) out.push(full);
  }
  return out;
}

/** "Artist - Title.mp4" → { artist, title } */
export function parseName(file: string): { artist: string; title: string } {
  const base = path.basename(file, path.extname(file)).replace(/_/g, ' ').trim();
  const i = base.indexOf(' - ');
  if (i > 0) return { artist: base.slice(0, i).trim(), title: base.slice(i + 3).trim() };
  return { artist: '', title: base };
}

/** Category from the configured tag (e.g. album "5CT"), else the folder's category or type. */
function categoryFor(folder: Folder, c: Pick<Clip, 'album'>): string {
  const fromTag = folder.categoryTag === 'album' ? c.album.trim() : '';
  return fromTag || folder.category || folder.type;
}

/** Run `fn` over `items` with at most `n` in flight. */
async function pool<T>(items: T[], n: number, fn: (t: T) => Promise<void>) {
  let i = 0;
  await Promise.all(Array.from({ length: n }, async () => {
    while (i < items.length) await fn(items[i++]);
  }));
}

interface ProbeResult {
  duration: number;
  width: number;
  height: number;
  hasVideo: boolean;
  hasAudio: boolean;
  /** End of the first sound track, if the file gives it. */
  soundEnd?: number;
  tags: Record<string, string>;
}

/** Where a sound stream ends: start plus duration (MKV and WebM give it as a DURATION tag). */
function soundEndOf(s: any): number | undefined {
  if (!s) return undefined;
  let d = Number(s.duration);
  if (!Number.isFinite(d) || d <= 0) {
    const m = String(s.tags?.DURATION ?? s.tags?.duration ?? '').match(/^(\d+):(\d+):([\d.]+)/);
    d = m ? Number(m[1]) * 3600 + Number(m[2]) * 60 + Number(m[3]) : NaN;
  }
  if (!Number.isFinite(d) || d <= 0) return undefined;
  return d + Math.max(0, Number(s.start_time) || 0);
}

async function probe(file: string): Promise<ProbeResult> {
  const r = await run(FFPROBE, ['-v', 'error', '-show_format', '-show_streams', '-of', 'json', file], 60000);
  if (r.code !== 0) throw new Error(r.stderr.trim() || 'ffprobe failed');
  const j = JSON.parse(r.stdout);
  const streams: any[] = j.streams ?? [];
  const v = streams.find((s) => s.codec_type === 'video' && s.disposition?.attached_pic !== 1);
  const tags: Record<string, string> = {};
  for (const [k, val] of Object.entries({ ...(j.format?.tags ?? {}) })) tags[k.toLowerCase()] = String(val);
  let { width = 0, height = 0 } = v ?? {};
  // Rotated phone videos report their stored size; swap for display size.
  const rot = Math.abs(Number(v?.side_data_list?.find((d: any) => d.rotation !== undefined)?.rotation ?? 0));
  if (rot === 90 || rot === 270) [width, height] = [height, width];
  return {
    duration: Number(j.format?.duration ?? v?.duration ?? 0),
    width,
    height,
    hasVideo: !!v,
    hasAudio: streams.some((s) => s.codec_type === 'audio'),
    soundEnd: soundEndOf(streams.find((s) => s.codec_type === 'audio')),
    tags,
  };
}

interface Analysis {
  lufs: number | null;
  cueIn: number;
  cueOut: number;
  /** Last moment the song is still at full level, before it starts to fade. */
  mixOut: number;
  crop?: [number, number, number, number];
}

/** Bars thinner than this share of the frame are left alone. */
const MIN_BAR = 0.03;

/**
 * Black bars baked into the picture (e.g. a 4:3 video padded to 16:9).
 * Sampled at three points and united, so one dark scene cannot fool it.
 */
async function detectBars(file: string, p: ProbeResult): Promise<[number, number, number, number] | undefined> {
  if (!p.width || !p.height || p.duration < 20) return undefined;
  let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
  for (const at of [0.25, 0.5, 0.75]) {
    const log = await ffmpegLog(['-ss', String(Math.round(p.duration * at)), '-t', '3', '-i', file, '-map', '0:v:0',
      '-vf', 'cropdetect=limit=24:round=2:reset=0']);
    const m = [...log.matchAll(/crop=(\d+):(\d+):(\d+):(\d+)/g)].pop();
    if (!m) return undefined;
    const [w, h, x, y] = m.slice(1, 5).map(Number);
    x0 = Math.min(x0, x); y0 = Math.min(y0, y); x1 = Math.max(x1, x + w); y1 = Math.max(y1, y + h);
  }
  const w = x1 - x0, h = y1 - y0;
  const barsX = (p.width - w) / p.width, barsY = (p.height - h) / p.height;
  if (barsX < MIN_BAR && barsY < MIN_BAR) return undefined;
  // Ignore unlikely results (almost everything black, or a tiny picture).
  if (w < p.width * 0.4 || h < p.height * 0.4) return undefined;
  return [w, h, x0, y0];
}

/** "Full level" = momentary loudness within this many LU of the song's integrated loudness. */
const FADE_DROP_LU = 12;
/** The fade-out is looked for only in the last seconds of content. */
const FADE_SEARCH_SECONDS = 20;

const EDGE_SECONDS = 12;

async function ffmpegLog(args: string[]): Promise<string> {
  const r = await run(FFMPEG, ['-hide_banner', '-nostats', '-v', 'verbose', ...args, '-f', 'null', '-'], 15 * 60000, 'background');
  if (r.code !== 0) throw new Error(r.stderr.split('\n').slice(-5).join(' ').trim());
  return r.stderr;
}

/**
 * Loudness and silence from the whole audio track (cheap to decode), black
 * frames only in the first and last seconds of video: decoding all of it
 * would take days on a large library.
 */
async function analyze(file: string, p: ProbeResult): Promise<Analysis> {
  const d = p.duration;
  let log = '';
  if (p.hasAudio) {
    log += await ffmpegLog(['-i', file, '-map', '0:a:0', '-af', 'ebur128=framelog=verbose,silencedetect=n=-50dB:d=0.3']);
  }
  if (p.hasVideo) {
    const black = ['-map', '0:v:0', '-vf', 'scale=320:-2,blackdetect=d=0.2:pix_th=0.10'];
    log += await ffmpegLog(['-t', String(EDGE_SECONDS), '-i', file, ...black]);
    // -copyts keeps the file's own timestamps, so tail black times are absolute.
    if (d > EDGE_SECONDS * 2) log += await ffmpegLog(['-copyts', '-sseof', `-${EDGE_SECONDS}`, '-i', file, ...black]);
  }
  const near = (a: number, b: number) => Math.abs(a - b) < 0.15;

  const lufsMatch = [...log.matchAll(/I:\s+(-?[\d.]+) LUFS/g)].pop();
  const lufs = lufsMatch && Number(lufsMatch[1]) > -70 ? Number(lufsMatch[1]) : null;

  // Silence: pairs of silence_start / silence_end (the last one may be open-ended).
  const silences: [number, number][] = [];
  for (const m of log.matchAll(/silence_start: (-?[\d.]+)|silence_end: ([\d.]+)/g)) {
    if (m[1] !== undefined) silences.push([Math.max(0, Number(m[1])), d]);
    else if (silences.length) silences[silences.length - 1][1] = Number(m[2]);
  }
  const blacks: [number, number][] = [];
  for (const m of log.matchAll(/black_start:([\d.]+) black_end:([\d.]+)/g)) blacks.push([Number(m[1]), Number(m[2])]);
  blacks.sort((a, b) => a[0] - b[0]);

  const startAfter = (spans: [number, number][]) => (spans.length && near(spans[0][0], 0) ? spans[0][1] : 0);
  const endBefore = (spans: [number, number][]) => {
    const last = spans[spans.length - 1];
    return last && near(last[1], d) ? last[0] : d;
  };

  const starts: number[] = [];
  const ends: number[] = [];
  if (p.hasAudio) { starts.push(startAfter(silences)); ends.push(endBefore(silences)); }
  if (p.hasVideo) { starts.push(startAfter(blacks)); ends.push(endBefore(blacks)); }
  // Content begins when either picture or sound begins, and ends when both have ended.
  let cueIn = Math.min(10, starts.length ? Math.min(...starts) : 0);
  let cueOut = ends.length ? Math.max(...ends) : d;
  if (cueOut - cueIn < 2) { cueIn = 0; cueOut = d; }

  // Mix point: the last moment near the end where the song is still at full level.
  let mixOut = Math.max(cueIn, cueOut - 2);
  if (lufs !== null) {
    const threshold = lufs - FADE_DROP_LU;
    let lastLoud = -1;
    for (const m of log.matchAll(/t:\s*([\d.]+)\s+TARGET:\S+ LUFS\s+M:\s*(-?[\d.]+)/g)) {
      const t = Number(m[1]);
      if (t <= cueOut && Number(m[2]) >= threshold) lastLoud = t;
    }
    if (lastLoud > 0) mixOut = Math.min(cueOut, Math.max(cueOut - FADE_SEARCH_SECONDS, cueIn, lastLoud));
  }
  const crop = p.hasVideo ? await detectBars(file, p) : undefined;
  return { lufs, cueIn: round(cueIn), cueOut: round(cueOut), mixOut: round(mixOut), crop };
}

const round = (n: number) => Math.round(n * 1000) / 1000;

export class Library extends EventEmitter {
  clips = new Map<string, Clip>();
  private file: string;
  private busy = false;
  private cfg: Config;
  private folderOf = new Map<string, Folder>();
  /** Categories analyzed first (those the clocks use). */
  priority = new Set<string>();

  constructor(cfg: Config) {
    super();
    this.cfg = cfg;
    measuredOnly = !!cfg.library.measuredCues;
    this.file = path.join(resolvePath(cfg.dataDir), 'library.json');
    if (fs.existsSync(this.file)) {
      for (const c of JSON.parse(fs.readFileSync(this.file, 'utf8')) as Clip[]) {
        c.album ??= '';
        c.probed ??= c.analyzed;
        // Read before the tags (or the end of the sound) were kept: read them again (quick, the measurements stay).
        if (c.probed && !c.error && !c.tags) c.probed = false;
        // Read before the end of the sound was kept: read again, staying on air meanwhile.
        if (c.probed && !c.error && c.hasAudio && c.soundEnd === undefined) c.recheck = true;
        // Measured with an older analysis: measure again.
        if (c.analyzed && !c.error && (c.analysisVersion ?? 1) < ANALYSIS_VERSION) {
          c.analyzed = false;
          delete c.auto;
        }
        resolveCues(c);
        this.clips.set(c.id, c);
      }
    }
  }

  list(): Clip[] {
    return [...this.clips.values()];
  }

  get(id: string): Clip | undefined {
    return this.clips.get(id);
  }

  /** Clips that failed on air; kept out of rotation until the file changes. */
  private broken = new Set<string>();

  markBroken(id: string) {
    this.broken.add(id);
    this.emit('change');
  }

  isPlayable(c: Clip): boolean {
    return c.probed && !c.error && !this.broken.has(c.id);
  }

  /** Playable clips whose type or category is `group` (all when omitted). */
  playable(group?: string): Clip[] {
    const all = this.list().filter((c) => this.isPlayable(c));
    if (!group) return all;
    const filter = this.cfg.library.categories.find((f) => f.name === group);
    if (filter) return all.filter((c) => c.type === 'music' && categoryMatches(c, filter));
    return all.filter((c) => c.type === group || c.category === group);
  }

  /** Tag fields found in the music clips, with how many clips have each and its most common values. */
  tagFields(): { field: string; clips: number; values: string[] }[] {
    const seen = new Map<string, { clips: number; values: Map<string, number> }>();
    for (const c of this.list()) {
      if (c.type !== 'music' || !this.isPlayable(c)) continue;
      for (const [k, v] of fieldsOf(c)) {
        // Not about the song: the file's own details, written by the program that made it.
        if (['file', 'title', 'duration', 'major_brand', 'minor_version', 'compatible_brands', 'encoder', 'creation_time', 'handler_name', 'vendor_id'].includes(k)) continue;
        const f = seen.get(k) ?? { clips: 0, values: new Map<string, number>() };
        f.clips++;
        for (const t of k === 'artist' || k === 'album' ? [v.trim()] : parts(v)) {
          if (t && t.length <= 40) f.values.set(t, (f.values.get(t) ?? 0) + 1);
        }
        seen.set(k, f);
      }
    }
    return [...seen].map(([field, f]) => ({
      field, clips: f.clips,
      values: [...f.values].sort((a, b) => b[1] - a[1]).slice(0, 30).map(([v]) => v),
    })).sort((a, b) => b.clips - a.clips);
  }

  /** First playable clip whose file name contains `name` (case-insensitive). */
  findByName(name: string): Clip | undefined {
    const n = name.toLowerCase();
    return this.list().find((c) => this.isPlayable(c) && path.basename(c.file).toLowerCase().includes(n));
  }

  private save() {
    const tmp = this.file + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(this.list()));
    fs.renameSync(tmp, this.file);
  }

  private saveTimer: NodeJS.Timeout | null = null;

  /** During analysis clips change one by one: write at most every few seconds. */
  private saveSoon() {
    this.saveTimer ??= setTimeout(() => {
      this.saveTimer = null;
      this.save();
    }, 5000);
  }

  /** Find new, changed and removed files, then read and measure what needs it. */
  async scan(): Promise<void> {
    const seen = new Set<string>();
    for (const folder of this.cfg.library.folders) {
      const files = await walk(resolvePath(folder.path));
      // Stat in parallel: one by one, ten thousand files over SMB take half a minute.
      const stats = new Map<string, fs.Stats>();
      await pool(files, 16, async (f) => {
        try {
          stats.set(f, await fs.promises.stat(f));
        } catch {
          // vanished meanwhile
        }
      });
      for (const file of files) {
        const st = stats.get(file);
        if (!st) continue;
        const id = crypto.createHash('sha1').update(path.resolve(file).toLowerCase()).digest('hex').slice(0, 16);
        seen.add(id);
        this.folderOf.set(id, folder);
        const old = this.clips.get(id);
        if (old && old.size === st.size && old.mtimeMs === st.mtimeMs && old.type === folder.type) {
          old.category = categoryFor(folder, old);
          continue;
        }
        this.broken.delete(id);
        const { artist, title } = parseName(file);
        this.clips.set(id, {
          id, file, type: folder.type, category: folder.category ?? folder.type, artist, title, album: '',
          size: st.size, mtimeMs: st.mtimeMs, duration: 0, width: 0, height: 0, hasAudio: false,
          lufs: null, cueIn: 0, cueOut: 0, mixOut: 0, cueSource: 'none', probed: false, analyzed: false,
        });
      }
    }
    for (const id of [...this.clips.keys()]) if (!seen.has(id)) this.clips.delete(id);
    this.loadExternalCues();
    this.loadTagCues();
    this.save();
    this.emit('change');
    await this.processPending();
  }

  /**
   * Read the tags of every new clip (fast, in parallel); the clips can air
   * from then on. Measuring them continues in the background.
   */
  private async processPending() {
    if (this.busy) return;
    this.busy = true;
    try {
      const toProbe = this.list().filter((c) => (!c.probed || c.recheck) && !c.error);
      await pool(toProbe, 8, async (c) => {
        try {
          const p = await probe(c.file);
          if (!p.hasVideo) throw new Error('nessuna traccia video');
          Object.assign(c, {
            duration: round(p.duration), width: p.width, height: p.height, hasAudio: p.hasAudio,
            soundEnd: p.soundEnd === undefined ? null : round(p.soundEnd),
            artist: p.tags.artist || c.artist, title: p.tags.title || c.title, album: p.tags.album ?? '',
            tagYear: (p.tags.date ?? p.tags.year ?? '').match(/\b(19|20)\d\d\b/)?.[0],
            tags: p.tags,
            probed: true,
          });
          delete c.recheck;
          this.loadTagCues(c);
          resolveCues(c);
          if (c.silentTail !== undefined && c.soundEnd != null) {
            console.log(`${path.basename(c.file)}: il suono finisce a ${Math.round(c.soundEnd)} s, il video a ${Math.round(c.duration)} s: il brano si ferma con la fine del suono`);
          }
          const folder = this.folderOf.get(c.id);
          if (folder) c.category = categoryFor(folder, c);
        } catch (e) {
          // Only read again for a missing detail: it stays as it was.
          if (c.recheck) {
            delete c.recheck;
            return;
          }
          Object.assign(c, { probed: true, analyzed: true, error: String((e as Error).message ?? e).slice(0, 300) });
        }
        this.saveSoon();
        this.emit('change');
      });
    } finally {
      this.busy = false;
      this.save();
    }
    this.analyzeInBackground().catch((e) => console.error('analisi:', e));
  }

  private analyzing = false;

  private async analyzeInBackground() {
    if (this.analyzing) return;
    this.analyzing = true;
    try {
      const rank = (c: Clip) => (this.priority.has(c.category) ? 0 : 1);
      const toAnalyze = this.list().filter((c) => !c.analyzed && !c.error).sort((a, b) => rank(a) - rank(b));
      for (const c of toAnalyze) {
        if (!this.clips.has(c.id)) continue; // removed by a later scan
        try {
          const p = await probe(c.file);
          const a = await analyze(c.file, p);
          Object.assign(c, { lufs: a.lufs, auto: { cueIn: a.cueIn, cueOut: a.cueOut, mixOut: a.mixOut } });
          if (a.crop) c.crop = a.crop;
          else delete c.crop;
          Object.assign(c, { analyzed: true, analysisVersion: ANALYSIS_VERSION });
          resolveCues(c);
          delete c.analysisError;
        } catch (e) {
          // The clip stays playable with its probed values; just record why.
          Object.assign(c, { analyzed: true, analysisError: String((e as Error).message ?? e).slice(0, 300) });
        }
        this.saveSoon();
        this.emit('analyzed', c);
      }
    } finally {
      this.analyzing = false;
      this.save();
    }
  }

  zettaMatched = 0;

  /** (Re)read the Zetta archive so edits made there apply at the next scan. */
  /** Mix points written in the files' tags as mm:ss, in the tags named by library.cueTags. */
  private loadTagCues(only?: Clip) {
    const names = this.cfg.library.cueTags;
    for (const c of only ? [only] : this.clips.values()) {
      const time = (tag?: string) => {
        const v = tag ? c.tags?.[tag.toLowerCase()] : undefined;
        // Only real times: "01:22", not a name that happens to be in the tag.
        return v && /^\s*\d{1,2}(:\d{2}){1,2}([.,]\d+)?\s*$/.test(v) ? parseTime(v) : null;
      };
      const start = time(names?.start);
      const mixOut = time(names?.mixOut);
      const had = !!c.tagCue;
      if (start !== null || mixOut !== null) c.tagCue = { start, mixOut };
      else delete c.tagCue;
      if (c.probed && (had || c.tagCue)) resolveCues(c);
    }
  }

  private loadExternalCues() {
    const db = this.cfg.library.zettaDb;
    if (!db) return;
    let cues: Map<string, ExternalCue>;
    try {
      cues = loadZettaCues(resolvePath(db));
    } catch (e) {
      console.warn('zetta:', (e as Error).message);
      return;
    }
    let n = 0;
    for (const c of this.clips.values()) {
      const g = guidOf(c.file);
      const e = g ? cues.get(g) : undefined;
      if (e) {
        c.ext = e;
        n++;
      } else {
        delete c.ext;
      }
      if (c.probed) resolveCues(c);
    }
    this.zettaMatched = n;
  }

  /** Release year: the Zetta archive first, then the file's tag. */
  static yearOf(c: Clip): string {
    return c.ext?.year ?? c.tagYear ?? '';
  }

  progress() {
    const all = this.list();
    return {
      total: all.length,
      probed: all.filter((c) => c.probed).length,
      analyzed: all.filter((c) => c.analyzed).length,
      errors: all.filter((c) => c.error).length,
      zetta: all.filter((c) => c.cueSource === 'zetta').length,
    };
  }
}
