import fs from 'node:fs';
import { spawnSync } from 'node:child_process';
import path from 'node:path';
import { type Config, resolvePath } from './config.ts';
import { FFMPEG } from './ffmpeg.ts';
import { audioProcessing } from './audioproc.ts';
import { encoderGraphics, type TickerBlock } from './graphics.ts';
import { isAnimatedLogo, logoDecoder, logoLoop } from './logo.ts';

function videoCodecArgs(cfg: Config, encoder: string): string[] {
  const o = cfg.output;
  const gop = String(Math.round(o.fps * o.keyframeSeconds));
  const rate = ['-b:v', o.videoBitrate, '-maxrate', o.videoBitrate, '-bufsize', `${parseInt(o.videoBitrate) * 2}k`];
  switch (encoder) {
    case 'h264_nvenc':
      return ['-c:v', encoder, '-preset', 'p5', '-tune', 'hq', '-rc', 'cbr', ...rate, '-g', gop, '-bf', '2',
        '-no-scenecut', '1', '-forced-idr', '1', '-profile:v', 'high'];
    case 'h264_videotoolbox':
      return ['-c:v', encoder, '-realtime', '1', '-allow_sw', '1', ...rate, '-g', gop, '-profile:v', 'high'];
    case 'h264_qsv':
    case 'h264_amf':
      return ['-c:v', encoder, ...rate, '-g', gop];
    default:
      return ['-c:v', 'libx264', '-preset', 'veryfast', ...rate, '-g', gop, '-keyint_min', gop,
        '-sc_threshold', '0', '-profile:v', 'high'];
  }
}

/**
 * The always-on encoder: reads the decoders' MPEG-TS on stdin at real-time
 * speed, regenerates timestamps, adds the station graphics and writes the
 * final H.264/AAC MPEG-TS to stdout for the output pushers.
 */
let queueArgs: string[] | null = null;
/**
 * A longer queue between reading and decoding the clips: an input option that the newest
 * ffmpeg builds no longer take (they refuse to start), so it is used only where it works.
 */
function inputQueue(): string[] {
  if (!queueArgs) {
    const r = spawnSync(FFMPEG, ['-hide_banner', '-v', 'error', '-f', 'lavfi', '-thread_queue_size', '64', '-i', 'anullsrc', '-t', '0.1', '-f', 'null', '-'], { timeout: 15000, windowsHide: true });
    queueArgs = r.status === 0 ? ['-thread_queue_size', '64'] : [];
  }
  return queueArgs;
}

let catchUpArgs: string[] | null = null;
/**
 * After a slow stretch (e.g. the graphics chip busy with something else), read faster for a while
 * so the channel gets back to real time instead of staying minutes behind. Only where ffmpeg has it.
 */
function catchUp(): string[] {
  if (!catchUpArgs) {
    const r = spawnSync(FFMPEG, ['-hide_banner', '-v', 'error', '-readrate', '1', '-readrate_catchup', '1.5', '-f', 'lavfi', '-i', 'anullsrc', '-t', '0.1', '-f', 'null', '-'], { timeout: 15000, windowsHide: true });
    catchUpArgs = r.status === 0 ? ['-readrate_catchup', '1.5'] : [];
  }
  return catchUpArgs;
}

export function encoderArgs(cfg: Config, encoder: string, logo = '', blocks: TickerBlock[] = [], dayOffset = 0): string[] {
  const { width: W, height: H, fps } = cfg.output;
  const ov = cfg.overlay;
  const args = [
    '-hide_banner', '-nostdin', '-v', 'warning', '-stats', '-stats_period', '1',
    '-readrate', '1', '-readrate_initial_burst', '2', ...inputQueue(), ...catchUp(),
    // Segment joins break the TS continuity counters, which flags one packet as
    // corrupt; it is intact, so keep it instead of dropping a frame per join.
    // The picture and sound clocks count frames and samples from the start: never start them
    // again because a segment looks different from the one before.
    '-reinit_filter', '0',
    // Room to find the picture even when it arrives a few seconds after the sound.
    '-analyzeduration', '5000000', '-probesize', '20000000',
    '-fflags', '+genpts', '-f', 'mpegts', '-i', 'pipe:0',
  ];
  // An animated logo is drawn by the decoders (see logo.ts), not here.
  const hasLogo = !!logo && fs.existsSync(logo) && !isAnimatedLogo(logo);
  // A moving logo plays in a loop for as long as the channel is on air.
  const animated = hasLogo && isAnimatedLogo(logo);
  if (hasLogo) args.push(...(animated ? [...logoLoop(logo), ...logoDecoder(logo)] : []), '-i', logo);
  // Ticker block logos follow, one input each.
  const logoInputs: number[] = [];
  if (blocks.length && blocks.every((b) => b.logo && fs.existsSync(b.logo))) {
    for (const b of blocks) {
      logoInputs.push(1 + (hasLogo ? 1 : 0) + logoInputs.length);
      args.push('-i', b.logo!);
    }
  }

  let video = `[0:v]setpts=N/(${fps}*TB),format=yuv420p[vbase];${encoderGraphics(cfg, 'vbase', 'vgfx', blocks, logoInputs, dayOffset)}`;
  if (hasLogo) {
    const mx = ov.logo.marginX ?? ov.logo.margin;
    const my = ov.logo.marginY ?? ov.logo.margin;
    const pre = animated ? `fps=${fps},${ov.logo.crop ? `crop=${ov.logo.crop},` : ''}` : '';
    video += `;[1:v]${pre}scale=${ov.logo.width}:-2,format=rgba,colorchannelmixer=aa=${ov.logo.opacity}[logo];` +
      `[vgfx][logo]overlay=W-w-${mx}:${my}:eof_action=repeat,format=yuv420p[v]`;
  } else {
    video += ';[vgfx]null[v]';
  }
  // Separate graphs run on separate threads: the audio processor must not slow the picture.
  const audio = `[0:a]asetpts=N/SR/TB[apre];${audioProcessing(cfg.audio.processing, 'apre', 'a', cfg.audio.tuning)}`;

  args.push(
    '-filter_complex', video, '-filter_complex', audio, '-map', '[v]', '-map', '[a]',
    // Intel Quick Sync takes the picture as nv12 (the same colours, laid out its own way).
    ...videoCodecArgs(cfg, encoder), '-pix_fmt', encoder === 'h264_qsv' ? 'nv12' : 'yuv420p', '-r', String(fps),
    '-c:a', 'aac', '-b:a', cfg.output.audioBitrate, '-ar', '48000', '-ac', '2',
    '-f', 'mpegts', 'pipe:1',
  );
  return args;
}

const FLV_FLAGS = 'no_duration_filesize+aac_seq_header_detect';

/** ffmpeg arguments for one output pusher, which only remuxes the encoded stream. */
export function pusherArgs(cfg: Config, target: string): string[] {
  const input = ['-hide_banner', '-nostdin', '-v', 'warning', '-f', 'mpegts', '-i', 'pipe:0', '-map', '0', '-c', 'copy'];
  if (target === 'preview') {
    const dir = path.join(resolvePath(cfg.dataDir), 'preview');
    fs.rmSync(dir, { recursive: true, force: true });
    fs.mkdirSync(dir, { recursive: true });
    return [...input, '-f', 'hls', '-hls_time', '2', '-hls_list_size', '6',
      '-hls_flags', 'delete_segments+independent_segments',
      // Segment numbers keep growing across restarts, so open players do not stall.
      '-hls_start_number_source', 'epoch', path.join(dir, 'stream.m3u8')];
  }
  // The sound travels without a separate description, so ffmpeg opens an RTMP stream with an
  // empty one and sends the real one with the first packet. Some servers keep the empty one:
  // their players then list a sound track and play nothing. Write it from the start.
  if (/^rtmps?:\/\//i.test(target)) return [...input, '-f', 'flv', '-flvflags', FLV_FLAGS, target];
  if (/^(srt|udp):\/\//i.test(target)) return [...input, '-f', 'mpegts', target];
  // Local file, handy for tests: format follows the extension.
  const ext = path.extname(target).toLowerCase();
  const fmt = ext === '.flv' ? 'flv' : ext === '.mkv' ? 'matroska' : 'mpegts';
  return [...input, '-y', '-f', fmt, ...(fmt === 'flv' ? ['-flvflags', FLV_FLAGS] : []), resolvePath(target)];
}
