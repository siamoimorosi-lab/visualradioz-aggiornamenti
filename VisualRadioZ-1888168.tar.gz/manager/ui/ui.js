// Manager window: a tab per station with its state and panel, the new-station
// form and the manager's own settings. Talks to the app through window.tv.
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);

let stations = [];
let current = null; // station id, 'new' or 'gear'
let loadedUrl = '';

function show(view) {
  for (const v of ['stationView', 'newView', 'gearView']) $(v).hidden = v !== view;
}

function select(id) {
  current = id;
  localStorage.setItem('tab', id);
  renderTabs();
  if (id === 'new') return openNew();
  if (id === 'gear') return openGear();
  show('stationView');
  renderStation();
}

function renderTabs() {
  $('tabs').innerHTML = stations.map((s) =>
    `<button class="tab${s.id === current ? ' on' : ''}" data-id="${esc(s.id)}" title="${esc(s.state)}"><span class="dot ${s.light}"></span>${esc(s.name)}</button>`).join('');
  $('addTab').classList.toggle('on', current === 'new');
  $('gearTab').classList.toggle('on', current === 'gear');
}

function chip(label, value, cls = '') {
  return `<span class="chip ${cls}">${esc(label)} <b>${esc(value)}</b></span>`;
}

function renderStation() {
  const s = stations.find((x) => x.id === current);
  if (!s) return;
  $('sDot').className = `dot big ${s.light}`;
  $('sState').textContent = s.state;
  $('sNow').textContent = s.onAir ? `In onda: ${s.onAir}` : s.reachable ? '' : s.wanted ? 'Il gestore lo sta avviando o riavviando' : 'Chiusa: premi Avvia per metterla in onda';
  const chips = [];
  if (s.encoder) {
    // ffmpeg's speed is the average since the encoder started: low in the first minutes.
    const speed = Number(s.encoder.speed);
    const warm = s.encoder.uptime > 180;
    chips.push(chip('Encoder', `${speed.toFixed(2)}x · ${s.encoder.fps} fps${warm ? '' : ' · avvio'}`, !warm ? '' : speed >= 0.97 ? 'ok' : speed >= 0.9 ? 'warn' : 'bad'));
  }
  for (const o of s.outputs) {
    const label = o.label.startsWith('Anteprima') ? 'Anteprima' : o.label.startsWith('rtmp') ? 'RTMP' : o.label;
    chips.push(chip(label, o.state, o.state === 'attivo' ? 'ok' : 'warn'));
  }
  const p = s.public;
  if (p.url) {
    const t = p.checkedAt ? new Date(p.checkedAt).toLocaleTimeString('it-CH', { hour: '2-digit', minute: '2-digit' }) : '';
    chips.push(p.state === 'ok' ? chip('In rete', `visibile · ${t}`, 'ok')
      : p.state === 'stale' ? chip('In rete', 'fermo', 'bad')
      : p.state === 'down' ? chip('In rete', p.error || 'non raggiungibile', 'bad')
      : chip('In rete', 'controllo…'));
  } else if (s.reachable) {
    chips.push(chip('In rete', 'indirizzo pubblico non impostato', 'warn'));
  }
  $('sChips').innerHTML = chips.join('');
  $('sStart').hidden = s.reachable || (s.wanted && s.light !== 'red');
  $('sClose').hidden = !s.reachable;
  $('sRestart').disabled = !s.reachable;
  // The panel only when the station answers; otherwise a message.
  if (s.reachable) {
    if (loadedUrl !== s.url) {
      $('panel').src = s.url;
      loadedUrl = s.url;
    }
    $('placeholder').hidden = true;
  } else {
    if (loadedUrl) {
      $('panel').src = 'about:blank';
      loadedUrl = '';
    }
    $('placeholder').hidden = false;
    $('placeholder').textContent = s.wanted ? 'Avvio della stazione…' : 'La stazione è chiusa. Premi “Avvia” per metterla in onda.';
  }
}

let autoNew = false; // "Nuova stazione" shown only because the list was still empty

function update(v) {
  stations = v;
  if (!current || (autoNew && stations.length) || (!['new', 'gear'].includes(current) && !stations.some((s) => s.id === current))) {
    autoNew = !stations.length;
    const saved = localStorage.getItem('tab');
    current = stations.some((s) => s.id === saved) ? saved : stations[0]?.id ?? 'new';
    select(current);
    return;
  }
  renderTabs();
  if (!$('stationView').hidden) renderStation();
}

$('tabs').addEventListener('click', (e) => {
  const b = e.target.closest('[data-id]');
  if (b) {
    loadedUrl = '';
    select(b.dataset.id);
  }
});
$('addTab').onclick = () => select('new');
$('gearTab').onclick = () => select('gear');
$('sStart').onclick = () => window.tv.start(current);
$('sClose').onclick = async () => {
  if (confirm('Chiudere il programma di questa stazione? Smette di trasmettere finché non la riavvii.')) await window.tv.close(current);
};
$('sRestart').onclick = async () => {
  if (confirm('Riavviare il programma di questa stazione? La diretta si interrompe per qualche secondo.')) await window.tv.restart(current);
};
// ------------------------------------------------------------- destinations

let outTargets = [];
function renderOut() {
  $('outRows').innerHTML = outTargets.map((t, i) => `
    <div class="out-row" data-i="${i}">
      <label>Server<input class="o-server" value="${esc(t.server)}" placeholder="es. rtmp://a.rtmp.youtube.com/live2"></label>
      <label>Chiave di trasmissione<span class="pick"><input class="o-key" type="password" autocomplete="off" value="${esc(t.key)}"><button type="button" class="o-show">Mostra</button></span></label>
      <button type="button" class="ghost small o-del" title="Togli questa destinazione">✕</button>
    </div>`).join('') || '<p class="hint">Nessuna destinazione: il canale gira solo in anteprima.</p>';
}
$('sOutputs').onclick = async () => {
  const o = await window.tv.outputs(current);
  if (!o) return;
  outTargets = o.targets.length ? o.targets : [{ server: '', key: '' }];
  $('outTitle').textContent = `Server di trasmissione: ${o.name}`;
  $('outPublic').value = o.publicUrl;
  $('outQuality').value = o.quality;
  $('outMsg').textContent = '';
  renderOut();
  $('outDlg').showModal();
};
$('outAdd').onclick = () => {
  outTargets.push({ server: '', key: '' });
  renderOut();
};
$('outCancel').onclick = () => $('outDlg').close();
$('outRows').addEventListener('input', (e) => {
  const row = e.target.closest('[data-i]');
  if (!row) return;
  const t = outTargets[+row.dataset.i];
  if (e.target.classList.contains('o-server')) t.server = e.target.value;
  if (e.target.classList.contains('o-key')) t.key = e.target.value;
});
$('outRows').addEventListener('click', (e) => {
  const row = e.target.closest('[data-i]');
  if (!row) return;
  if (e.target.closest('.o-del')) {
    outTargets.splice(+row.dataset.i, 1);
    renderOut();
  } else if (e.target.closest('.o-show')) {
    const k = row.querySelector('.o-key');
    k.type = k.type === 'password' ? 'text' : 'password';
    e.target.textContent = k.type === 'password' ? 'Mostra' : 'Nascondi';
  }
});
$('outForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const s = stations.find((x) => x.id === current);
  if (s?.reachable && !confirm('Salvare? Il canale si riavvia per usare i nuovi server: la diretta si interrompe per qualche secondo.')) return;
  $('outMsg').textContent = 'Salvo…';
  try {
    await window.tv.setOutputs(current, { targets: outTargets, publicUrl: $('outPublic').value, quality: $('outQuality').value });
    $('outDlg').close();
  } catch (err) {
    $('outMsg').textContent = `Non salvato: ${String(err.message).replace(/^Error invoking remote method '\w+': Error: /, '')}`;
  }
});

// -------------------------------------------------------------------- tags

$('sTags').onclick = async () => {
  $('sTags').disabled = true;
  const t = await window.tv.tags(current).finally(() => ($('sTags').disabled = false));
  if (!t) return;
  $('tagTitle').textContent = `Tag dei file: ${t.name}`;
  $('tagStart').value = t.cueStart;
  $('tagMix').value = t.cueMix;
  $('cueMeasured').checked = t.measured;
  $('cueFiles').checked = !t.measured;
  $('tagMsg').textContent = '';
  $('tagList').innerHTML = t.fields.map((f) => `<option value="${esc(f.field)}">`).join('');
  $('tagRows').innerHTML = t.fields.map((f) => `
    <label class="tag-row"><span><code>${esc(f.field)}</code> <small>${esc(f.values.join(' · '))}</small></span><input data-tag="${esc(f.field)}" value="${esc(f.name)}" placeholder="nome da mostrare"></label>`).join('')
    || `<p class="hint">${t.running ? 'Nessun tag letto finora.' : 'Avvia il canale per vedere i tag trovati nei file.'}</p>`;
  $('tagDlg').showModal();
};
$('tagCancel').onclick = () => $('tagDlg').close();
$('tagForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const s = stations.find((x) => x.id === current);
  if (s?.reachable && !confirm('Salvare? Il canale si riavvia per rileggere i tag: la diretta si interrompe per qualche secondo.')) return;
  const names = {};
  for (const i of $('tagRows').querySelectorAll('[data-tag]')) if (i.value.trim()) names[i.dataset.tag] = i.value.trim();
  $('tagMsg').textContent = 'Salvo…';
  try {
    await window.tv.setTags(current, { names, cueStart: $('tagStart').value, cueMix: $('tagMix').value, measured: $('cueMeasured').checked });
    $('tagDlg').close();
  } catch (err) {
    $('tagMsg').textContent = `Non salvato: ${err.message}`;
  }
});

// ---------------------------------------------------------------- graphics

const cleanErr = (err) => String(err.message).replace(/^Error invoking remote method '\w+': Error: /, '');
let gfxLogoFile = '';
let gfxStillFile = '';
$('gfxStillPick').onclick = async () => {
  const f = await window.tv.pick('image');
  if (!f) return;
  gfxStillFile = f;
  $('gfxStill').value = f.split(/[\\/]/).pop();
};
$('gfxStillClear').onclick = () => {
  gfxStillFile = '';
  $('gfxStill').value = '';
};
const gfxLabels = () => {
  $('gfxWidthV').textContent = `${$('gfxWidth').value} pixel`;
  $('gfxStingerV').textContent = `${$('gfxStingerW').value}% dello schermo`;
  $('gfxScaleV').textContent = `${$('gfxScale').value}%`;
};
$('sGfx').onclick = async () => {
  const g = await window.tv.graphics(current);
  if (!g) return;
  gfxLogoFile = '';
  $('gfxTitle').textContent = `Grafica: ${g.name}`;
  $('gfxLogo').value = g.logo;
  $('gfxWidth').value = g.logoWidth;
  $('gfxStinger').checked = g.stingerOn;
  $('gfxStingerW').value = g.stingerWidth;
  $('gfxScale').value = g.scale;
  $('gfxStillAt').value = g.stillAt;
  gfxStillFile = g.stillFile;
  $('gfxStill').value = g.stillFile ? g.stillFile.split(/[\\/]/).pop() : '';
  $('gfxMsg').textContent = '';
  gfxLabels();
  $('gfxDlg').showModal();
};
for (const id of ['gfxWidth', 'gfxStingerW', 'gfxScale']) $(id).oninput = gfxLabels;
$('gfxPick').onclick = async () => {
  const f = await window.tv.pick('logo');
  if (!f) return;
  gfxLogoFile = f;
  $('gfxLogo').value = f;
};
$('gfxCancel').onclick = () => $('gfxDlg').close();
$('gfxForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const s = stations.find((x) => x.id === current);
  if (s?.reachable && !confirm('Salvare? Il canale si riavvia per mostrare la nuova grafica: la diretta si interrompe per qualche secondo.')) return;
  $('gfxMsg').textContent = 'Salvo…';
  try {
    await window.tv.setGraphics(current, {
      logoFile: gfxLogoFile, logoWidth: $('gfxWidth').value, stingerOn: $('gfxStinger').checked,
      stingerWidth: $('gfxStingerW').value, scale: $('gfxScale').value, stillAt: $('gfxStillAt').value, stillFile: gfxStillFile,
    });
    $('gfxDlg').close();
  } catch (err) {
    $('gfxMsg').textContent = `Non salvato: ${cleanErr(err)}`;
  }
});

// -------------------------------------------------------------------- news

// Sources ready to add, with the logos that come with the program.
const NEWS_PRESETS = [
  { label: 'TIO.CH', url: 'https://media.tio.ch/files/domains/tio.ch/rss/rss_aperture.xml', logo: 'assets/feed-logos/src/tio.png' },
  { label: 'LA REGIONE', url: 'https://media.laregione.ch/files/domains/laregione.ch/rss/feed_rss.xml', logo: 'assets/feed-logos/src/laregione.svg' },
  { label: 'IL POST', url: 'https://www.ilpost.it/feed', logo: 'assets/feed-logos/src/ilpost.svg' },
  { label: 'REUTERS', url: 'https://news.google.com/rss/search?q=when:24h+site:reuters.com&ceid=US:en&hl=en-US&gl=US', logo: 'assets/feed-logos/src/reuters.svg' },
];
$('newsPreset').innerHTML += NEWS_PRESETS.map((p, i) => `<option value="${i}">${esc(p.label)}</option>`).join('');
let newsFeeds = [];
function renderNews() {
  $('newsRows').innerHTML = newsFeeds.map((f, i) => `
    <div class="news-row" data-i="${i}">
      <label>Nome<input class="n-label" value="${esc(f.label)}" maxlength="30" placeholder="es. TIO.CH"></label>
      <label>Indirizzo del feed RSS<input class="n-url" value="${esc(f.url)}" placeholder="https://…"></label>
      <label>Logo<span class="pick"><input class="n-logo" readonly value="${esc(f.logo ? f.logo.split(/[\\/]/).pop() : '')}" placeholder="solo il nome"><button type="button" class="n-pick">Scegli…</button></span></label>
      <button type="button" class="ghost small n-del" title="Togli questa fonte">✕</button>
    </div>`).join('') || '<p class="hint">Nessuna fonte: la barra mostra solo il testo del canale.</p>';
}
$('sNews').onclick = async () => {
  const t = await window.tv.ticker(current);
  if (!t) return;
  newsFeeds = t.feeds;
  $('newsTitle').textContent = `Notizie: ${t.name}`;
  $('newsOn').checked = t.enabled;
  $('newsSeconds').value = t.seconds;
  $('newsPer').value = t.perBlock;
  $('newsLabel').value = t.label;
  $('evUrl').value = t.events.url;
  $('evLabel').value = t.events.label;
  $('evEvery').value = t.events.cardEveryMinutes;
  $('evCard').checked = t.events.card;
  evLogoFile = t.events.logo;
  $('evLogo').value = t.events.logo ? t.events.logo.split(/[\\/]/).pop() : '';
  for (const c of document.querySelectorAll('[data-kind]')) c.checked = !t.events.skipKinds.includes(c.dataset.kind);
  for (const c of document.querySelectorAll('[data-town]')) c.checked = !t.events.skipTowns.some((x) => x.toLowerCase() === c.dataset.town.toLowerCase());
  $('newsFrom').value = t.newsFrom;
  $('newsTo').value = t.newsTo;
  $('newsMsg').textContent = '';
  renderNews();
  $('newsDlg').showModal();
};
$('newsAdd').onclick = () => {
  newsFeeds.push({ label: '', url: '', logo: '' });
  renderNews();
};
$('newsPreset').onchange = (e) => {
  const p = NEWS_PRESETS[e.target.value];
  e.target.value = '';
  if (!p || newsFeeds.some((f) => f.label === p.label)) return;
  newsFeeds.push({ ...p });
  renderNews();
};
// The four sources of the program this app comes from, in one click.
$('newsAll').onclick = () => {
  for (const p of NEWS_PRESETS) if (!newsFeeds.some((f) => f.label === p.label)) newsFeeds.push({ ...p });
  $('newsOn').checked = true;
  renderNews();
};
let evLogoFile = '';
$('evLogoPick').onclick = async () => {
  const f = await window.tv.pick('feedLogo');
  if (!f) return;
  evLogoFile = f;
  $('evLogo').value = f.split(/[\\/]/).pop();
};
$('evWl').onclick = () => {
  $('evUrl').value = 'https://winterland.swiss/programma/';
  $('evLabel').value = 'WINTERLAND';
  // The Winterland logo comes with the program; resident DJs stay out of the bar.
  evLogoFile = 'assets/feed-logos/src/winterland.png';
  $('evLogo').value = 'winterland.png';
  for (const c of document.querySelectorAll('[data-kind]')) c.checked = c.dataset.kind !== 'resident-dj';
  // Locarno only: the Ascona village and its Lake Dome stay out.
  for (const c of document.querySelectorAll('[data-town]')) c.checked = c.dataset.town !== 'Ascona';
  $('newsOn').checked = true;
};
$('newsCancel').onclick = () => $('newsDlg').close();
$('newsRows').addEventListener('input', (e) => {
  const row = e.target.closest('[data-i]');
  if (!row) return;
  const f = newsFeeds[+row.dataset.i];
  if (e.target.classList.contains('n-label')) f.label = e.target.value;
  if (e.target.classList.contains('n-url')) f.url = e.target.value;
});
$('newsRows').addEventListener('click', async (e) => {
  const row = e.target.closest('[data-i]');
  if (!row) return;
  if (e.target.closest('.n-del')) {
    newsFeeds.splice(+row.dataset.i, 1);
    renderNews();
  } else if (e.target.closest('.n-pick')) {
    const f = await window.tv.pick('feedLogo');
    if (!f) return;
    newsFeeds[+row.dataset.i].logo = f;
    renderNews();
  }
});
$('newsForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const s = stations.find((x) => x.id === current);
  if (s?.reachable && !confirm('Salvare? Il canale si riavvia per usare le nuove fonti: la diretta si interrompe per qualche secondo.')) return;
  $('newsMsg').textContent = 'Salvo…';
  try {
    await window.tv.setTicker(current, {
      enabled: $('newsOn').checked, label: $('newsLabel').value, seconds: $('newsSeconds').value, perBlock: $('newsPer').value, feeds: newsFeeds,
      events: {
        url: $('evUrl').value, label: $('evLabel').value, card: $('evCard').checked, cardEveryMinutes: $('evEvery').value, logo: evLogoFile,
        skipKinds: [...document.querySelectorAll('[data-kind]')].filter((c) => !c.checked).map((c) => c.dataset.kind),
        skipTowns: [...document.querySelectorAll('[data-town]')].filter((c) => !c.checked).map((c) => c.dataset.town),
      },
      newsFrom: $('newsFrom').value, newsTo: $('newsTo').value,
    });
    $('newsDlg').close();
  } catch (err) {
    $('newsMsg').textContent = `Non salvato: ${cleanErr(err)}`;
  }
});

$('sFolder').onclick = () => window.tv.folder(current);
$('sLog').onclick = () => window.tv.log(current);

// --------------------------------------------------------------- new station

async function openNew() {
  show('newView');
  const info = await window.tv.info();
  $('homeHint').textContent = `${info.home}${info.platform === 'win32' ? '\\' : '/'}stations`;
  $('baseSel').innerHTML = [...info.stations.map((s) => `<option value="${esc(s.id)}">${esc(s.name)}</option>`), '<option value="">Impostazioni di esempio</option>'].join('');
}
document.querySelectorAll('[data-pick]').forEach((b) => {
  b.onclick = async () => {
    const f = await window.tv.pick(b.dataset.pick);
    if (f) $('newForm').elements[b.dataset.for].value = f;
  };
});
$('newForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const f = $('newForm').elements;
  const form = {};
  for (const k of ['name', 'logo', 'musicDir', 'categoryTag', 'jingleDir', 'zettaDb', 'cueStart', 'cueMix', 'rtmpUrl', 'streamKey', 'publicUrl', 'base']) form[k] = f[k].value.trim();
  form.copySchedule = f.copySchedule.checked;
  form.startNow = f.startNow.checked;
  $('newMsg').textContent = 'Creo la stazione…';
  try {
    const id = await window.tv.create(form);
    $('newForm').reset();
    $('newMsg').textContent = '';
    current = id;
    stations = await window.tv.stations();
    select(id);
  } catch (err) {
    $('newMsg').textContent = `Non creata: ${err.message}`;
  }
});

// ---------------------------------------------------------------- manager

async function openGear() {
  show('gearView');
  const info = await window.tv.info();
  $('gHome').textContent = info.home;
  const c = info.code;
  const short = (v) => (v.commit ? `${v.version} (${v.commit})` : v.version);
  $('gVersion').textContent = c.updated ? `In uso: aggiornamento ${short(c)}. Installer: ${short(c.installer)}.` : `In uso: ${short(c)}, quella dell’installer.`;
  $('gInstalled').hidden = !c.updated;
  $('gAutostart').checked = info.autostart;
  $('gWatchdog').checked = info.watchdog;
  $('gWatchdog').disabled = !info.packaged;
  // The periodic check uses Windows' Task Scheduler.
  $('gWatchdogRow').hidden = info.platform !== 'win32';
  $('gRuntime').textContent = `Node: ${info.runtime.node} · ffmpeg: ${info.runtime.ffmpeg}${info.packaged ? '' : ' (avviato dai sorgenti: il controllo periodico c’è solo nella versione installata)'}`;
}
$('gAutostart').onchange = async (e) => (e.target.checked = await window.tv.autostart(e.target.checked));
$('gWatchdog').onchange = async (e) => (e.target.checked = await window.tv.watchdog(e.target.checked));
$('gOpen').onclick = () => window.tv.openHome();
$('sExport').onclick = async () => {
  try {
    const f = await window.tv.exportStation(current);
    if (f) alert(`Stazione esportata in:\n${f}`);
  } catch (e) {
    alert(`Non esportata: ${cleanErr(e)}`);
  }
};
$('gImport').onclick = async () => {
  $('gImportMsg').textContent = 'Importo…';
  try {
    const r = await window.tv.importStation();
    if (!r) return ($('gImportMsg').textContent = '');
    $('gImportMsg').textContent = 'Importata.';
    if (r.missing.length) alert(`Stazione importata. Su questo computer mancano queste cartelle dei video: correggile nella stazione prima di avviarla.\n\n${r.missing.join('\n')}`);
    select(r.id);
  } catch (e) {
    $('gImportMsg').textContent = `Non importata: ${cleanErr(e)}`;
  }
};
$('gBackups').onclick = () => window.tv.openBackups();
$('gUpdate').onclick = async () => {
  $('gUpdateMsg').textContent = 'Installo…';
  try {
    const r = await window.tv.installUpdate();
    $('gUpdateMsg').textContent = r.ok ? 'Installato: il programma si riapre.' : '';
  } catch (e) {
    $('gUpdateMsg').textContent = `Non installato: ${String(e.message).replace(/^Error invoking remote method '\w+': Error: /, '')}`;
  }
};
function showOnline(o) {
  const ready = o.state === 'ready';
  $('updBanner').hidden = !ready;
  if (ready) $('updBanner').textContent = `Aggiornamento pronto (${o.commit})`;
  $('gInstallReady').hidden = !ready;
  const when = o.checkedAt ? ` · controllato alle ${new Date(o.checkedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}` : '';
  $('gOnline').textContent = o.error ? `Controllo non riuscito: ${o.error}${when}`
    : ready ? `Versione nuova ${o.commit} scaricata e pronta${o.note ? `: ${o.note}` : ''}.${when}`
    : o.state === 'installer' ? `C’è la versione ${o.commit}, ma cambia i motori del programma: serve l’installer completo.${when}`
    : `Nessuna versione nuova${when || ' (il programma controlla da solo ogni ora)'}.`;
}
window.tv.updateState().then(showOnline);
window.tv.onUpdateState(showOnline);
$('gCheck').onclick = async () => {
  $('gOnline').textContent = 'Controllo…';
  showOnline(await window.tv.checkUpdate());
};
const installNew = async () => {
  if (!confirm('Installare la versione nuova? Le stazioni accese si riavviano: la diretta si interrompe per qualche secondo.')) return;
  try {
    await window.tv.installReady();
  } catch (e) {
    alert(`Non installato: ${cleanErr(e)}`);
  }
};
$('gInstallReady').onclick = installNew;
$('updBanner').onclick = installNew;
$('gInstalled').onclick = async () => {
  if (confirm('Tornare alla versione dell’installer? Le stazioni accese si riavviano.')) await window.tv.useInstalled();
};

window.tv.info().then((i) => ($('appVer').textContent = `versione ${i.code.label}`));
window.tv.onUpdate(update);
window.tv.onSelect((id) => select(id));
window.tv.stations().then(update);
