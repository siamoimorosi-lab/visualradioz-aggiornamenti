// Installs an update file (VisualRadioZ-aggiornamento-*.tar.gz from the release page):
// unpacked next to the earlier ones in <data>/code/<version>, checked against the
// installed engines, then made the current code (see boot.mjs).
import { execFile } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

const readJson = (f) => {
  try {
    return JSON.parse(fs.readFileSync(f, 'utf8'));
  } catch {
    return null;
  }
};

/**
 * Remove a folder of the update store. Its node_modules may be a junction to the installer's
 * own modules (made by earlier versions): a recursive removal on Windows follows a junction and
 * empties the target, which took the installed modules away and stopped the stations at their
 * next start. The link is taken away first, on its own, never followed.
 */
export function removeFolder(dir) {
  if (!fs.existsSync(dir)) return;
  unlinkModules(dir);
  fs.rmSync(dir, { recursive: true, force: true });
}

/** If `dir`/node_modules is a link (junction or symlink), remove the link only. */
function unlinkModules(dir) {
  const link = path.join(dir, 'node_modules');
  let st;
  try {
    st = fs.lstatSync(link);
  } catch {
    return;
  }
  if (!st.isSymbolicLink()) return;
  try {
    fs.unlinkSync(link);
  } catch {
    fs.rmdirSync(link);
  }
}

/** Whether the modules in `nodeModules` hold @resvg/resvg-js whole: its package and its native part. */
export function modulesComplete(nodeModules) {
  const pkg = path.join(nodeModules, '@resvg', 'resvg-js', 'package.json');
  if (!fs.existsSync(pkg)) return false;
  try {
    // The native part is a package of its own per system (e.g. @resvg/resvg-js-win32-x64-msvc).
    return fs.readdirSync(path.join(nodeModules, '@resvg')).some((d) => d.startsWith('resvg-js-') &&
      fs.readdirSync(path.join(nodeModules, '@resvg', d)).some((f) => f.endsWith('.node')));
  } catch {
    return false;
  }
}

/**
 * Give the update in `dir` its own copy of the installer's modules (a few megabytes): nothing
 * links to the installed program any more, so removing an update can never touch it.
 */
export function copyModules(dir, bundled) {
  const modules = path.join(bundled, 'node_modules');
  const own = path.join(dir, 'node_modules');
  unlinkModules(dir);
  if (modulesComplete(own)) return;
  if (!modulesComplete(modules)) throw new Error('i moduli del programma installato sono danneggiati: reinstalla con l’installer completo');
  fs.rmSync(own, { recursive: true, force: true });
  fs.cpSync(modules, own, { recursive: true, dereference: true });
}

/** Whether the code in `dir` has whole modules of its own. */
export function modulesOk(dir) {
  return modulesComplete(path.join(dir, 'node_modules'));
}

/** Run `fn`, trying again for up to ten seconds while Windows holds the files (EPERM, EBUSY). */
async function settle(fn) {
  for (let i = 0; ; i++) {
    try {
      return fn();
    } catch (e) {
      if (i >= 20 || !['EPERM', 'EBUSY', 'EACCES', 'ENOTEMPTY'].includes(e.code)) throw e;
      await new Promise((r) => setTimeout(r, 500));
    }
  }
}

/** The newest update file in the Downloads folder, or ''. */
export function findDownloaded(downloads) {
  try {
    return fs.readdirSync(downloads)
      .filter((f) => /^VisualRadioZ-aggiornamento.*\.tar\.gz$/i.test(f))
      .map((f) => path.join(downloads, f))
      .sort((a, b) => fs.statSync(b).mtimeMs - fs.statSync(a).mtimeMs)[0] ?? '';
  } catch {
    return '';
  }
}

/** What version the code in `dir` is (the commit it was built from). */
export function versionOf(dir) {
  const p = readJson(path.join(dir, 'package.json')) ?? {};
  return { version: p.version ?? '', commit: p.updateCommit ?? '', base: p.updateBase ?? '', date: p.updateDate ?? '' };
}

/** Version of an update file, read without unpacking it (null when it is not one). */
export async function versionOfFile(file) {
  try {
    const p = JSON.parse(await tarRead(file, 'package.json'));
    return { version: p.version ?? '', commit: p.updateCommit ?? '', base: p.updateBase ?? '', date: p.updateDate ?? '' };
  } catch {
    return null;
  }
}

const tarBin = () => (process.platform === 'win32' ? path.join(process.env.SystemRoot ?? 'C:\\Windows', 'System32', 'tar.exe') : 'tar');

/** One file of a .tar.gz, as text, without unpacking the rest. */
const tarRead = (file, member) => new Promise((ok, fail) =>
  execFile(tarBin(), ['-xzOf', file, member], { windowsHide: true, maxBuffer: 1 << 20 }, (e, out, err) => (e ? fail(new Error(String(err || e.message).trim())) : ok(out))));

const untar = (file, to) => new Promise((ok, fail) =>
  // tar is part of Windows 10 and later, and of macOS.
  execFile(process.platform === 'win32' ? path.join(process.env.SystemRoot ?? 'C:\\Windows', 'System32', 'tar.exe') : 'tar',
    ['-xzf', file, '-C', to], { windowsHide: true }, (e, _o, err) => (e ? fail(new Error(String(err || e.message).trim())) : ok())));

/**
 * Unpack and check `file`; returns the folder of the new code. `bundled` is the code that
 * came with the installer, `store` the folder of the updates.
 */
export async function installUpdate(file, bundled, store) {
  fs.mkdirSync(store, { recursive: true });
  // Which version it is, read from the file without unpacking it: the update is then unpacked
  // straight into its own folder. No folder is moved afterwards, a step Windows (often its
  // antivirus looking at the files just written) could refuse with EPERM.
  let v;
  try {
    const p = JSON.parse(await tarRead(file, 'package.json'));
    v = { version: p.version ?? '', commit: p.updateCommit ?? '', base: p.updateBase ?? '' };
  } catch {
    throw new Error('il file non è un aggiornamento di VisualRadioZ');
  }
  const base = versionOf(bundled).base;
  if (!base || v.base !== base) {
    throw new Error('questo aggiornamento cambia anche i motori del programma (ffmpeg, Node o Electron): serve l’installer completo');
  }
  let name = `${v.version}-${v.commit || Date.now()}`;
  let dir = path.join(store, name);
  if (fs.existsSync(dir)) {
    try {
      await settle(() => removeFolder(dir));
    } catch {
      // Left from an earlier try and still held: a folder of its own.
      name = `${name}-${Date.now()}`;
      dir = path.join(store, name);
    }
  }
  fs.mkdirSync(dir, { recursive: true });
  await untar(file, dir);
  if (!fs.existsSync(path.join(dir, 'manager', 'main.mjs')) || !fs.existsSync(path.join(dir, 'src', 'main.ts'))) {
    throw new Error('aggiornamento incompleto: riprova');
  }
  // A copy of the installer's native modules, checked before the version is made current.
  copyModules(dir, bundled);
  if (!modulesOk(dir)) throw new Error('aggiornamento incompleto (mancano i moduli del programma): riprova');
  fs.writeFileSync(path.join(store, 'current.json'), JSON.stringify({ dir: name, at: new Date().toISOString() }));
  // Keep the last three; folders left by earlier tries go too.
  const old = fs.readdirSync(store).filter((d) => d !== name && fs.statSync(path.join(store, d)).isDirectory())
    .sort((a, b) => fs.statSync(path.join(store, b)).mtimeMs - fs.statSync(path.join(store, a)).mtimeMs)
    .filter((d, i) => i >= 2 || d.startsWith('nuovo-'));
  for (const d of old) {
    try {
      removeFolder(path.join(store, d));
    } catch {
      // still in use: removed next time
    }
  }
  return { dir, ...v };
}

/** Back to the code of the installer. */
export function useInstalled(store) {
  fs.rmSync(path.join(store, 'current.json'), { force: true });
}


/** Where the app looks for new versions: a public repository holding only the update files. */
export const UPDATE_URL = process.env.VRZ_UPDATE_URL ?? 'https://raw.githubusercontent.com/siamoimorosi-lab/visualradioz-aggiornamenti/main/';

/**
 * Look for a newer version than `current` (see versionOf). When there is one that fits the
 * installed engines, download it into `store` and check it; returns what was found:
 * { state: 'none' } | { state: 'ready', file, version, commit, note } |
 * { state: 'installer', version, commit, note } (it needs the whole installer).
 */
export async function checkOnline(current, store) {
  const res = await fetch(`${UPDATE_URL}versione.json?t=${Date.now()}`, { signal: AbortSignal.timeout(20000), cache: 'no-store' });
  if (res.status === 404) return { state: 'none' };
  if (!res.ok) throw new Error(`controllo aggiornamenti: HTTP ${res.status}`);
  const v = await res.json();
  if (!v.commit || v.commit === current.commit) return { state: 'none' };
  const info = { version: v.version ?? '', commit: v.commit, note: v.note ?? '', date: v.date ?? '' };
  if (!current.base || v.base !== current.base) return { state: 'installer', ...info };
  fs.mkdirSync(store, { recursive: true });
  const file = path.join(store, `scaricato-${v.commit}.tar.gz`);
  if (!fs.existsSync(file)) {
    const r = await fetch(`${UPDATE_URL}${v.file}?t=${Date.now()}`, { signal: AbortSignal.timeout(120000) });
    if (!r.ok) throw new Error(`download aggiornamento: HTTP ${r.status}`);
    const data = Buffer.from(await r.arrayBuffer());
    const sum = (await import('node:crypto')).createHash('sha256').update(data).digest('hex');
    if (v.sha256 && sum !== v.sha256) throw new Error('aggiornamento scaricato ma rovinato (controllo non riuscito): riprovo più tardi');
    fs.writeFileSync(`${file}.parziale`, data);
    fs.renameSync(`${file}.parziale`, file);
    // Older downloads are no longer needed.
    for (const f of fs.readdirSync(store)) if (/^scaricato-.*\.tar\.gz$/.test(f) && path.join(store, f) !== file) fs.rmSync(path.join(store, f), { force: true });
  }
  return { state: 'ready', file, ...info };
}
