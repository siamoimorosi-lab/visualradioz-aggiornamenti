// A whole station in one file (.tar.gz): settings, schedule, logos, playlist,
// play history and the measurements made on the clips (library.json, so they
// are not made again). Logs, the preview and the pictures made at start-up are
// left out: the station makes them again. Used for export, import and the
// automatic backups.
import { execFile } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

/** Files of the data folder worth keeping. */
const DATA_FILES = ['library.json', 'playlist.json', 'scheduler.json', 'ticker-manual.txt', 'logo-still-own.png'];

const tarBin = () => (process.platform === 'win32' ? path.join(process.env.SystemRoot ?? 'C:\\Windows', 'System32', 'tar.exe') : 'tar');
const tar = (args) => new Promise((ok, fail) =>
  execFile(tarBin(), args, { windowsHide: true, maxBuffer: 1 << 24 }, (e, _o, err) => (e ? fail(new Error(String(err || e.message).trim())) : ok())));

/** Pack the station in `dir` (its data folder is `dataName`) into `file`. */
export async function packStation(dir, dataName, file) {
  const entries = fs.readdirSync(dir).filter((f) => f !== dataName && !f.startsWith('.'));
  const data = DATA_FILES.filter((f) => fs.existsSync(path.join(dir, dataName, f))).map((f) => `${dataName}/${f}`);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = `${file}.parziale`;
  await tar(['-czf', tmp, '-C', dir, ...entries, ...data]);
  fs.renameSync(tmp, file);
  return file;
}

/** Unpack a station file into the empty folder `to`; returns its config. */
export async function unpackStation(file, to) {
  fs.mkdirSync(to, { recursive: true });
  await tar(['-xzf', file, '-C', to]);
  const cfgFile = path.join(to, 'config.json');
  if (!fs.existsSync(cfgFile)) throw new Error('il file non contiene una stazione di VisualRadioZ (manca config.json)');
  return JSON.parse(fs.readFileSync(cfgFile, 'utf8'));
}

const stamp = (d = new Date()) => {
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}_${p(d.getHours())}-${p(d.getMinutes())}-${p(d.getSeconds())}`;
};
export const fileStamp = stamp;

/** How many backups are kept per station. */
const KEEP = 30;

/**
 * Backups of one station in <home>/backups/<id>: one whenever its settings or schedule
 * change (checked every minute), at least one a day, and one before it is replaced.
 */
export class Backups {
  constructor(root) {
    this.root = root;
    this.seen = new Map();
  }

  dirOf(id) {
    return path.join(this.root, id);
  }

  /** The settings files of a station, by their last change: a backup is due when it differs. */
  signature(station) {
    return ['config.json', 'schedule.json'].map((f) => {
      try {
        return fs.statSync(path.join(station.dir, f)).mtimeMs;
      } catch {
        return 0;
      }
    }).join('|');
  }

  list(id) {
    try {
      return fs.readdirSync(this.dirOf(id)).filter((f) => f.endsWith('.tar.gz')).sort();
    } catch {
      return [];
    }
  }

  async make(station, reason = '') {
    const dataName = path.relative(station.dir, station.dataDir) || 'data';
    const file = path.join(this.dirOf(station.id), `${stamp()}${reason ? `-${reason}` : ''}.tar.gz`);
    await packStation(station.dir, dataName, file);
    this.seen.set(station.id, this.signature(station));
    fs.writeFileSync(path.join(this.dirOf(station.id), 'ultimo.json'), JSON.stringify({ signature: this.signature(station), at: Date.now() }));
    for (const old of this.list(station.id).slice(0, -KEEP)) fs.rmSync(path.join(this.dirOf(station.id), old), { force: true });
    return file;
  }

  /** A backup for each station whose settings changed since the last one, or older than a day. */
  async check(stations) {
    for (const s of stations) {
      const sig = this.signature(s);
      let last = this.seen.get(s.id);
      let at = Date.now();
      if (last === undefined) {
        try {
          const j = JSON.parse(fs.readFileSync(path.join(this.dirOf(s.id), 'ultimo.json'), 'utf8'));
          last = j.signature;
          at = j.at;
          this.seen.set(s.id, last);
        } catch {
          last = '';
          at = 0;
        }
      }
      const newest = this.list(s.id).at(-1);
      const age = newest ? Date.now() - fs.statSync(path.join(this.dirOf(s.id), newest)).mtimeMs : Infinity;
      if (sig !== last || age > 24 * 3600_000 || !at) {
        await this.make(s, sig !== last && last ? 'modifica' : '').catch((e) => s.emit('note', `${s.name}: backup non riuscito (${e.message})`));
      }
    }
  }
}
