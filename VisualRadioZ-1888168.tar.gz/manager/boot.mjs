// First file the app runs. The program can be updated without the whole
// installer: an update is the code alone (manager, src, public, assets), a
// small file, unpacked into the app's data folder under code/<version>. When
// one is there and fits the installed engines (Electron, Node, ffmpeg and the
// native modules, see updateBase in package.json) it runs instead of the code
// that came with the installer.
import { app } from 'electron';
import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { copyModules, modulesOk } from './update.mjs';

app.setName('VisualRadioZ');
const bundled = path.resolve(import.meta.dirname, '..');
const readJson = (f) => {
  try {
    return JSON.parse(fs.readFileSync(f, 'utf8'));
  } catch {
    return null;
  }
};

function updatedCode() {
  if (!app.isPackaged) return null;
  const store = path.join(app.getPath('userData'), 'code');
  const current = readJson(path.join(store, 'current.json'));
  if (!current?.dir) return null;
  const dir = path.join(store, current.dir);
  const base = readJson(path.join(bundled, 'package.json'))?.updateBase;
  const own = readJson(path.join(dir, 'package.json'))?.updateBase;
  if (!base || base !== own || !fs.existsSync(path.join(dir, 'manager', 'main.mjs'))) return null;
  // The update must have whole native modules of its own (older updates linked to the installer's,
  // which a removal could empty): give it a copy, or run the installed code.
  try {
    copyModules(dir, bundled);
  } catch {
    // checked below
  }
  if (!modulesOk(dir)) return null;
  return dir;
}

const dir = updatedCode();
globalThis.VRZ_BUNDLED_DIR = bundled;
globalThis.VRZ_CODE_DIR = dir ?? bundled;
try {
  await import(pathToFileURL(path.join(globalThis.VRZ_CODE_DIR, 'manager', 'main.mjs')).href);
} catch (e) {
  if (!dir) throw e;
  // The update does not start: back to the installed code, and the update is set aside.
  fs.rmSync(path.join(app.getPath('userData'), 'code', 'current.json'), { force: true });
  fs.appendFileSync(path.join(app.getPath('userData'), 'code', 'errori-aggiornamento.log'), `${new Date().toISOString()} ${e?.stack ?? e}\n`);
  globalThis.VRZ_CODE_DIR = bundled;
  await import(pathToFileURL(path.join(bundled, 'manager', 'main.mjs')).href);
}
