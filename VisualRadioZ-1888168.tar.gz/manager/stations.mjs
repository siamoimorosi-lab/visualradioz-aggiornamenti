// Station supervisor: each station is its own playout process (src/main.ts)
// with its own folder (config.json, schedule.json, data/) and panel port.
// Stations run detached, so they keep broadcasting if this app closes or
// crashes; on start the app finds them again by their panel port.
import { spawn } from 'node:child_process';
import { EventEmitter } from 'node:events';
import fs from 'node:fs';
import path from 'node:path';
import { Backups, fileStamp, packStation, unpackStation } from './backup.mjs';

/** How long a station may take to answer after being started before it counts as failed. */
const START_GRACE_MS = 45_000;
/** Status poll and public-address check intervals. */
const POLL_MS = 2_000;
const PUBLIC_MS = 60_000;

const readJson = (f, fallback) => {
  try {
    return JSON.parse(fs.readFileSync(f, 'utf8'));
  } catch {
    return fallback;
  }
};

export class Station extends EventEmitter {
  constructor(dir, env) {
    super();
    this.dir = dir;
    this.id = path.basename(dir);
    this.env = env;
    this.status = null;
    this.reachable = false;
    this.startedAt = 0;
    this.failures = 0;
    this.public = { state: 'none', seq: null, checkedAt: 0, error: '' };
    this.reload();
  }

  /** Name, port and public address from the station's config. */
  reload() {
    const cfg = readJson(path.join(this.dir, 'config.json'), {});
    this.name = cfg.channelName || this.id;
    this.port = cfg.server?.port ?? 8080;
    this.token = cfg.server?.token ?? '';
    this.publicUrl = cfg.output?.publicUrl ?? '';
    this.dataDir = path.join(this.dir, cfg.dataDir ?? 'data');
  }

  get url() {
    return `http://127.0.0.1:${this.port}/${this.token ? `?token=${encodeURIComponent(this.token)}` : ''}`;
  }

  /** On unless closed on purpose ("Esci" in its panel or "Chiudi" here). */
  get wanted() {
    return !fs.existsSync(path.join(this.dataDir, 'closed-by-user'));
  }

  async api(p, method = 'GET', body, timeout = 1500) {
    const sep = this.token ? `${p.includes('?') ? '&' : '?'}token=${encodeURIComponent(this.token)}` : '';
    const r = await fetch(`http://127.0.0.1:${this.port}${p}${sep}`, {
      method,
      headers: body ? { 'content-type': 'application/json' } : {},
      body: body ? JSON.stringify(body) : undefined,
      signal: AbortSignal.timeout(timeout),
    });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    return r.json();
  }

  start() {
    fs.mkdirSync(this.dataDir, { recursive: true });
    fs.rmSync(path.join(this.dataDir, 'closed-by-user'), { force: true });
    const log = fs.openSync(path.join(this.dataDir, 'run-live.log'), 'a');
    fs.writeSync(log, `\n---- avvio ${new Date().toLocaleString()} (gestore) ----\n`);
    const e = this.env;
    const env = {
      ...process.env,
      WEBTV_HOME: this.dir,
      WEBTV_CONFIG: 'config.json',
      WEBTV_SCHEDULE: 'schedule.json',
      FFMPEG: e.ffmpeg,
      FFPROBE: e.ffprobe,
    };
    delete env.ELECTRON_RUN_AS_NODE;
    const child = spawn(e.node, [path.join(e.codeDir, 'src', 'main.ts')], {
      cwd: this.dir,
      detached: true,
      windowsHide: true,
      stdio: ['ignore', log, log],
      env,
    });
    child.unref();
    fs.closeSync(log);
    this.startedAt = Date.now();
    this.emit('note', `${this.name}: programma avviato`);
  }

  /** Change the station's config file keeping its line endings, then read name, port and address again. */
  writeConfig(change) {
    const full = path.join(this.dir, 'config.json');
    const text = fs.readFileSync(full, 'utf8');
    const cfg = JSON.parse(text);
    change(cfg);
    const out = JSON.stringify(cfg, null, 1) + '\n';
    fs.writeFileSync(full, text.includes('\r\n') ? out.replace(/\n/g, '\r\n') : out);
    this.reload();
  }

  /** Where the channel is sent (server and key per destination) and where viewers watch it. */
  outputs() {
    const cfg = readJson(path.join(this.dir, 'config.json'), {});
    return {
      name: this.name,
      targets: (cfg.output?.targets ?? []).map((t) => {
        // rtmp://server/app/KEY: the key is the last part of the address.
        const m = /^(rtmps?:\/\/.+)\/([^/]+)$/i.exec(t);
        return m ? { server: m[1], key: m[2] } : { server: t, key: '' };
      }),
      publicUrl: cfg.output?.publicUrl ?? '',
      quality: (cfg.output?.height ?? 1080) <= 720 ? '720' : '1080',
    };
  }

  setOutputs({ targets, publicUrl, quality }) {
    const list = (Array.isArray(targets) ? targets : [])
      .map((t) => ({ server: String(t?.server ?? '').trim().replace(/\/+$/, ''), key: String(t?.key ?? '').trim() }))
      .filter((t) => t.server)
      .map((t) => (t.key ? `${t.server}/${t.key}` : t.server));
    for (const t of list) if (!/^(rtmps?|srt|udp):\/\/\S+$/i.test(t)) throw new Error(`indirizzo non valido: deve iniziare con rtmp://, rtmps://, srt:// o udp:// (${t.slice(0, 40)})`);
    const pub = String(publicUrl ?? '').trim();
    if (pub && !/^https?:\/\/\S+$/i.test(pub)) throw new Error('l’indirizzo pubblico deve iniziare con http:// o https://');
    this.writeConfig((cfg) => {
      cfg.output = { ...cfg.output, targets: list, publicUrl: pub };
      // 720 asks much less of the computer than 1080: for one that cannot keep up.
      if (quality === '720') Object.assign(cfg.output, { width: 1280, height: 720, videoBitrate: '3500k' });
      if (quality === '1080') Object.assign(cfg.output, { width: 1920, height: 1080, videoBitrate: '6000k' });
    });
  }

  /**
   * How the station reads the files' tags: the names shown for them in the panel and the
   * tags holding the mix points. `fields` lists the tags found in the files (when it is running).
   */
  async tags() {
    const cfg = readJson(path.join(this.dir, 'config.json'), {});
    const names = cfg.library?.tagNames ?? {};
    let fields = [];
    try {
      fields = (await this.api('/api/settings', 'GET', undefined, 15000)).tagFields ?? [];
    } catch {
      // closed: only the tags already named can be shown
    }
    const skip = ['artist', 'title', 'content', 'temi'];
    const known = new Map(fields.filter((f) => !skip.includes(f.field)).map((f) => [f.field, f.values.slice(0, 4)]));
    for (const k of Object.keys(names)) if (!known.has(k)) known.set(k, []);
    return {
      name: this.name,
      running: this.reachable,
      fields: [...known].map(([field, values]) => ({ field, values, name: names[field] ?? '' })),
      cueStart: cfg.library?.cueTags?.start ?? '',
      cueMix: cfg.library?.cueTags?.mixOut ?? '',
      measured: !!cfg.library?.measuredCues,
    };
  }

  setTags({ names, cueStart, cueMix, measured }) {
    const clean = {};
    for (const [k, v] of Object.entries(names ?? {})) {
      const key = String(k).trim().toLowerCase();
      const val = String(v ?? '').trim().slice(0, 40);
      if (key && val) clean[key] = val;
    }
    const start = String(cueStart ?? '').trim().toLowerCase();
    const mixOut = String(cueMix ?? '').trim().toLowerCase();
    this.writeConfig((cfg) => {
      cfg.library = { ...cfg.library, tagNames: clean, cueTags: { ...(start ? { start } : {}), ...(mixOut ? { mixOut } : {}) }, measuredCues: !!measured };
      if (!Object.keys(clean).length) delete cfg.library.tagNames;
      if (!start && !mixOut) delete cfg.library.cueTags;
    });
  }

  /** Logo and text sizes of the on-air graphics. */
  graphics() {
    const cfg = readJson(path.join(this.dir, 'config.json'), {});
    const ov = cfg.overlay ?? {};
    return {
      name: this.name,
      logo: ov.logo?.path ?? '',
      logoWidth: ov.logo?.width ?? 200,
      stillFile: ov.logo?.stillFile ?? '',
      stillAt: ov.logo?.stillAt ?? 2,
      stingerOn: ov.stinger?.enabled ?? true,
      stingerWidth: Math.round((ov.stinger?.logoWidth ?? 0.45) * 100),
      scale: Math.round((ov.scale ?? 1.3) * 100),
    };
  }

  setGraphics({ logoFile, logoWidth, stingerOn, stingerWidth, scale, stillFile, stillAt }) {
    const num = (v, lo, hi, name) => {
      const n = Number(v);
      if (!Number.isFinite(n) || n < lo || n > hi) throw new Error(`${name}: un numero tra ${lo} e ${hi}`);
      return n;
    };
    const w = Math.round(num(logoWidth, 60, 900, 'larghezza del logo'));
    const sw = num(stingerWidth, 5, 90, 'logo nelle transizioni') / 100;
    const sc = num(scale, 80, 200, 'grandezza delle scritte') / 100;
    const at = num(stillAt ?? 2, 0, 3600, 'secondo del logo animato');
    // A picture chosen from the computer is copied next to the settings; '' = none.
    let still = String(stillFile ?? '').trim();
    if (still && path.isAbsolute(still)) {
      if (!fs.existsSync(still)) throw new Error('immagine per le transizioni non trovata');
      const rel = `logo-transizioni${path.extname(still).toLowerCase()}`;
      fs.copyFileSync(still, path.join(this.dir, rel));
      still = rel;
    }
    if (logoFile) {
      if (!fs.existsSync(logoFile)) throw new Error('file del logo non trovato');
      this.setLogo(logoFile);
    }
    this.writeConfig((cfg) => {
      cfg.overlay = {
        ...cfg.overlay,
        scale: sc,
        logo: { ...cfg.overlay?.logo, width: w, stillAt: at, ...(still ? { stillFile: still } : {}) },
        stinger: { ...cfg.overlay?.stinger, enabled: !!stingerOn, logoWidth: sw },
      };
      if (!still) delete cfg.overlay.logo.stillFile;
    });
  }

  /** The news bar: on or off, timing, and the feeds with their logos. */
  ticker() {
    const cfg = readJson(path.join(this.dir, 'config.json'), {});
    const t = cfg.overlay?.ticker ?? {};
    return {
      name: this.name,
      enabled: !!t.enabled,
      label: t.label ?? 'INFO',
      seconds: t.seconds ?? 10,
      perBlock: t.perBlock ?? 4,
      newsFrom: t.newsFrom ?? '',
      newsTo: t.newsTo ?? '',
      feeds: (t.feeds ?? []).map((f) => ({ label: f.label ?? '', url: f.url ?? '', logo: f.logo ?? '' })),
      events: {
        url: cfg.events?.url ?? '',
        label: cfg.events?.label ?? 'PROGRAMMA',
        card: cfg.events?.card ?? true,
        cardEveryMinutes: cfg.events?.cardEveryMinutes ?? 10,
        logo: cfg.events?.logo ?? '',
        skipKinds: cfg.events?.skipKinds ?? ['resident-dj'],
        skipTowns: cfg.events?.skipTowns ?? [],
      },
    };
  }

  setTicker({ enabled, label, seconds, perBlock, feeds, events, newsFrom, newsTo }) {
    const time = (v, name) => {
      const s = String(v ?? '').trim();
      if (s && !/^([01]?\d|2[0-3]):[0-5]\d$/.test(s)) throw new Error(`${name}: un orario come 07:00`);
      return s;
    };
    const from = time(newsFrom, 'notizie dalle');
    const to = time(newsTo, 'notizie alle');
    if (!from !== !to) throw new Error('per le notizie a orario servono tutti e due gli orari, dalle e alle');
    const evUrl = String(events?.url ?? '').trim();
    if (evUrl && !/^https?:\/\/\S+$/i.test(evUrl)) throw new Error('l’indirizzo del programma deve iniziare con http:// o https://');
    const evEvery = Number(events?.cardEveryMinutes ?? 10);
    const evLogo = this.keepLogo(events?.logo, 'programma');
    if (!(evEvery >= 1 && evEvery <= 240)) throw new Error('scheda degli headliner: ogni quanti minuti, tra 1 e 240');
    const secs = Number(seconds);
    const per = Math.round(Number(perBlock));
    if (!(secs >= 5 && secs <= 60)) throw new Error('secondi per notizia: tra 5 e 60');
    if (!(per >= 1 && per <= 20)) throw new Error('notizie per fonte: tra 1 e 20');
    const seen = new Set();
    const list = [];
    for (const f of Array.isArray(feeds) ? feeds : []) {
      const name = String(f?.label ?? '').trim().slice(0, 30);
      const url = String(f?.url ?? '').trim();
      if (!name && !url) continue;
      if (!name) throw new Error('ogni fonte deve avere un nome');
      if (!/^https?:\/\/\S+$/i.test(url)) throw new Error(`${name}: l’indirizzo del feed deve iniziare con http:// o https://`);
      if (seen.has(name.toLowerCase())) throw new Error(`due fonti si chiamano ${name}`);
      seen.add(name.toLowerCase());
      const logo = this.keepLogo(f?.logo, name);
      list.push({ label: name, url, ...(logo ? { logo } : {}) });
    }
    this.writeConfig((cfg) => {
      cfg.overlay = {
        ...cfg.overlay,
        ticker: { ...cfg.overlay?.ticker, enabled: !!enabled, label: String(label ?? '').trim().slice(0, 20) || 'INFO', seconds: secs, perBlock: per, feeds: list, newsFrom: from, newsTo: to },
      };
      if (events) {
        cfg.events = {
          ...cfg.events, url: evUrl, label: String(events.label ?? '').trim().slice(0, 20) || 'PROGRAMMA', card: !!events.card, cardEveryMinutes: evEvery,
          logo: evLogo,
          skipTowns: (Array.isArray(events.skipTowns) ? events.skipTowns : []).map((t) => String(t).trim().slice(0, 40)).filter(Boolean),
          skipKinds: (Array.isArray(events.skipKinds) ? events.skipKinds : []).map((k) => String(k)).filter((k) => /^[a-z0-9-]*$/.test(k)),
        };
      }
    });
  }

  /** A logo chosen from the computer is copied next to the station's settings; others stay as written. */
  keepLogo(file, name) {
    const logo = String(file ?? '').trim();
    if (!logo || !path.isAbsolute(logo)) return logo;
    if (!fs.existsSync(logo)) throw new Error(`${name}: file del logo non trovato`);
    const rel = `feed-logos/${String(name).toLowerCase().replace(/[^a-z0-9]+/g, '-')}${path.extname(logo).toLowerCase()}`;
    fs.mkdirSync(path.join(this.dir, 'feed-logos'), { recursive: true });
    fs.copyFileSync(logo, path.join(this.dir, rel));
    return rel;
  }

  /** A new logo: copied into the station's folder and written in its config; on air after a restart. */
  setLogo(file) {
    const name = `logo${path.extname(file).toLowerCase()}`;
    fs.copyFileSync(file, path.join(this.dir, name));
    this.writeConfig((cfg) => {
      cfg.overlay = { ...cfg.overlay, logo: { ...cfg.overlay?.logo, path: name } };
    });
    // The copies made from the old logo must not be used again. They are made anew at every
    // start anyway, so one that cannot be removed now (still open on Windows) does no harm.
    for (const f of ['logo-trimmed.png', 'logo-still.png']) {
      try {
        fs.rmSync(path.join(this.dataDir, f), { force: true });
      } catch {
        // in use
      }
    }
  }

  /** Close the station's program (it stays off until started again). */
  async close() {
    await this.api('/api/quit', 'POST').catch(() => {});
  }

  async restart() {
    await this.close();
    for (let i = 0; i < 30 && (await this.ping()); i++) await new Promise((r) => setTimeout(r, 500));
    this.start();
  }

  /**
   * Change the station's files with its program closed, then start it again if it was on.
   * On Windows a file that ffmpeg has open (the logo) cannot be replaced or deleted.
   */
  async change(fn) {
    const was = this.reachable;
    if (was) {
      await this.close();
      for (let i = 0; i < 30 && (await this.ping()); i++) await new Promise((r) => setTimeout(r, 500));
    }
    try {
      return fn();
    } finally {
      if (was) this.start();
    }
  }

  async ping() {
    try {
      await this.api('/api/status');
      return true;
    } catch {
      return false;
    }
  }

  /** One supervision step: read the status; start the program if it should run and does not answer. */
  async poll() {
    try {
      // A busy program (a big library, the settings page) may answer slowly: wait for it a while.
      this.status = await this.api('/api/status', 'GET', undefined, 4000);
      this.reachable = true;
      this.failures = 0;
    } catch {
      this.failures++;
      // One missed answer does not make it unreachable: the panel would be reloaded (back on
      // Diretta) for nothing. Only after three in a row, as for the restart below.
      if (this.failures >= 3 || !this.reachable) {
        this.reachable = false;
        this.status = null;
      }
      const starting = Date.now() - this.startedAt < START_GRACE_MS;
      // Three missed polls in a row (6 s) and not just started: (re)start it.
      if (this.wanted && !starting && this.failures >= 3) {
        if (this.startedAt) this.emit('alert', `${this.name}: il programma non risponde, lo riavvio`);
        this.start();
      }
    }
  }

  /**
   * Is the channel really watchable at its public address? The playlist must
   * answer and its media sequence must move on between two checks.
   */
  async checkPublic() {
    if (!this.publicUrl) return (this.public = { state: 'none', seq: null, checkedAt: Date.now(), error: '' });
    try {
      let url = this.publicUrl;
      let text = await (await this.fetchOk(url)).text();
      const variant = text.split('\n').find((l) => l.trim() && !l.startsWith('#'));
      if (/#EXT-X-STREAM-INF/.test(text) && variant) {
        url = new URL(variant.trim(), url).href;
        text = await (await this.fetchOk(url)).text();
      }
      const seq = Number(text.match(/#EXT-X-MEDIA-SEQUENCE:(\d+)/)?.[1] ?? NaN);
      const moving = this.public.seq === null || Number.isNaN(seq) || seq !== this.public.seq;
      this.public = { state: moving ? 'ok' : 'stale', seq, checkedAt: Date.now(), error: moving ? '' : 'il flusso pubblico è fermo' };
    } catch (e) {
      this.public = { state: 'down', seq: null, checkedAt: Date.now(), error: String(e.message ?? e) };
    }
  }

  async fetchOk(url) {
    const r = await fetch(url, { signal: AbortSignal.timeout(10_000), cache: 'no-store' });
    if (!r.ok) throw new Error(`indirizzo pubblico: HTTP ${r.status}`);
    return r;
  }

  /** Summary for the window: a light (green / yellow / red / grey) and short texts. */
  view() {
    const s = this.status;
    const starting = !this.reachable && Date.now() - this.startedAt < START_GRACE_MS;
    const outputs = s?.outputs ?? [];
    const outOk = outputs.every((o) => o.state === 'attivo');
    let light = 'grey';
    let state = 'Programma chiuso';
    if (this.reachable && s) {
      if (!s.running) {
        light = 'grey';
        state = 'Diretta spenta';
      } else if (!s.encoder?.running || !outOk || this.public.state === 'down' || this.public.state === 'stale') {
        light = 'yellow';
        state = 'In onda con problemi';
        if (!s.encoder?.running) state = 'Encoder fermo';
        else if (!outOk) state = 'Uscita non attiva';
        else if (this.public.state !== 'ok') state = 'Non visibile in rete';
        if (this.public.state === 'down' || !s.encoder?.running) light = 'red';
      } else {
        light = 'green';
        state = 'In onda';
      }
    } else if (starting) {
      light = 'yellow';
      state = 'Avvio…';
    } else if (this.wanted) {
      light = 'red';
      state = 'Non risponde';
    }
    return {
      id: this.id,
      name: this.name,
      url: this.url,
      dir: this.dir,
      light,
      state,
      reachable: this.reachable,
      wanted: this.wanted,
      onAir: s?.onAir?.clip ? `${s.onAir.clip.artist ? s.onAir.clip.artist + ' – ' : ''}${s.onAir.clip.title}` : '',
      encoder: s?.encoder ? { speed: s.encoder.speed, fps: s.encoder.fps, bitrate: s.encoder.bitrate, uptime: s.encoder.uptime } : null,
      outputs: outputs.map((o) => ({ label: o.label, state: o.state })),
      public: { ...this.public, url: this.publicUrl },
    };
  }
}

/** Copy the contents of folder `from` into folder `to` (made if missing). */
function copyInto(from, to) {
  fs.mkdirSync(to, { recursive: true });
  fs.cpSync(from, to, { recursive: true });
}

export class Stations extends EventEmitter {
  constructor(env) {
    super();
    this.env = env;
    this.root = path.join(env.home, 'stations');
    fs.mkdirSync(this.root, { recursive: true });
    this.backups = new Backups(path.join(env.home, 'backups'));
    this.list = [];
    this.scan();
  }

  /** Every folder in stations/ with a config.json is a station. */
  scan() {
    const dirs = fs.readdirSync(this.root, { withFileTypes: true })
      .filter((d) => d.isDirectory() && fs.existsSync(path.join(this.root, d.name, 'config.json')))
      .map((d) => path.join(this.root, d.name));
    for (const dir of dirs) {
      if (this.list.some((s) => s.dir === dir)) continue;
      const st = new Station(dir, this.env);
      st.on('note', (m) => this.emit('note', m));
      st.on('alert', (m) => this.emit('alert', st, m));
      this.list.push(st);
    }
    this.list = this.list.filter((s) => dirs.includes(s.dir));
  }

  get(id) {
    return this.list.find((s) => s.id === id);
  }

  start() {
    const tick = async () => {
      await Promise.all(this.list.map((s) => s.poll()));
      for (const s of this.list) {
        const v = s.view();
        if (s.lastLight && s.lastLight !== v.light) this.emit('change', s, s.lastLight, v);
        s.lastLight = v.light;
      }
      this.emit('update', this.list.map((s) => s.view()));
    };
    const pub = async () => {
      await Promise.all(this.list.filter((s) => s.reachable && s.status?.running).map((s) => s.checkPublic()));
    };
    tick();
    setInterval(tick, POLL_MS);
    // A backup whenever a station's settings change, and at least one a day.
    const backup = () => this.backups.check(this.list).catch(() => {});
    setTimeout(backup, 20_000);
    setInterval(backup, 60_000);
    setTimeout(pub, 15_000);
    setInterval(pub, PUBLIC_MS);
  }

  /** The station in one file, for another computer or to keep. */
  async exportStation(id, file) {
    const s = this.get(id);
    if (!s) throw new Error('stazione non trovata');
    return packStation(s.dir, path.relative(s.dir, s.dataDir) || 'data', file);
  }

  /** What a station file holds, without importing it: name and the id it had. */
  async peek(file) {
    const tmp = path.join(this.env.home, 'importazione', fileStamp());
    try {
      const cfg = await unpackStation(file, tmp);
      return { name: cfg.channelName || '', tmp };
    } catch (e) {
      fs.rmSync(tmp, { recursive: true, force: true });
      throw e;
    }
  }

  /**
   * Import an unpacked station (from peek). `replace`: the id of a station whose settings it
   * replaces (a backup of that one is made first, its logs stay); else it becomes a new station,
   * stopped, with a free panel port. Returns the id and the clip folders this computer lacks.
   */
  async importStation(tmp, replace = '') {
    try {
      const cfgFile = path.join(tmp, 'config.json');
      const cfg = JSON.parse(fs.readFileSync(cfgFile, 'utf8'));
      let id;
      if (replace) {
        const s = this.get(replace);
        if (!s) throw new Error('stazione da sostituire non trovata');
        const wasOn = s.reachable;
        await this.backups.make(s, 'prima-di-importare');
        if (wasOn) {
          await s.close();
          for (let i = 0; i < 30 && (await s.ping()); i++) await new Promise((r) => setTimeout(r, 500));
        }
        // Same panel port as before: links and bookmarks keep working.
        cfg.server = { ...cfg.server, port: s.port };
        fs.writeFileSync(cfgFile, JSON.stringify(cfg, null, 1) + '\n');
        for (const f of fs.readdirSync(s.dir)) if (f !== (path.relative(s.dir, s.dataDir) || 'data')) fs.rmSync(path.join(s.dir, f), { recursive: true, force: true });
        copyInto(tmp, s.dir);
        s.reload();
        if (wasOn) s.start();
        id = s.id;
      } else {
        const slug = String(cfg.channelName || 'stazione').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'stazione';
        id = slug;
        for (let n = 2; fs.existsSync(path.join(this.root, id)); n++) id = `${slug}-${n}`;
        cfg.dataDir = 'data';
        cfg.server = { ...cfg.server, port: this.nextPort() };
        fs.writeFileSync(cfgFile, JSON.stringify(cfg, null, 1) + '\n');
        const dir = path.join(this.root, id);
        fs.mkdirSync(path.join(tmp, 'data'), { recursive: true });
        // Imported stopped: it starts when asked, after a look at its folders and server.
        fs.writeFileSync(path.join(tmp, 'data', 'closed-by-user'), new Date().toISOString());
        copyInto(tmp, dir);
        this.scan();
      }
      const missing = (cfg.library?.folders ?? []).map((f) => f.path).filter((p) => p && !fs.existsSync(path.isAbsolute(p) ? p : path.join(this.root, id, p)));
      return { id, missing };
    } finally {
      fs.rmSync(tmp, { recursive: true, force: true });
    }
  }

  /** Next free panel port. */
  nextPort() {
    const used = this.list.map((s) => s.port);
    let p = 8090;
    while (used.includes(p)) p++;
    return p;
  }

  /**
   * A new station folder, its settings copied from `base` (another station,
   * or the example) with what the form gives: name, logo, folders, output.
   */
  create(form) {
    const slug = String(form.name).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'stazione';
    let id = slug;
    for (let n = 2; fs.existsSync(path.join(this.root, id)); n++) id = `${slug}-${n}`;
    const dir = path.join(this.root, id);
    const base = form.base && this.get(form.base);
    const baseCfg = base ? readJson(path.join(base.dir, 'config.json'), {}) : readJson(path.join(this.env.codeDir, 'config.example.json'), {});
    const cfg = structuredClone(baseCfg);
    cfg.channelName = form.name;
    cfg.dataDir = 'data';
    cfg.server = { ...cfg.server, host: '127.0.0.1', port: this.nextPort() };
    const rtmp = form.rtmpUrl ? `${form.rtmpUrl.replace(/\/+$/, '')}${form.streamKey ? `/${form.streamKey}` : ''}` : '';
    cfg.output = { ...cfg.output, targets: rtmp ? [rtmp] : [], publicUrl: form.publicUrl || '' };
    cfg.library = {
      ...cfg.library,
      folders: [
        ...(form.musicDir ? [{ path: form.musicDir, type: 'music', ...(form.categoryTag ? { categoryTag: form.categoryTag } : {}) }] : []),
        ...(form.jingleDir ? [{ path: form.jingleDir, type: 'jingle' }] : []),
      ],
      zettaDb: form.zettaDb || undefined,
      cueTags: form.cueStart || form.cueMix ? { ...(form.cueStart ? { start: form.cueStart } : {}), ...(form.cueMix ? { mixOut: form.cueMix } : {}) } : undefined,
    };
    fs.mkdirSync(path.join(dir, 'data'), { recursive: true });
    cfg.overlay = { ...cfg.overlay, logo: { ...cfg.overlay?.logo } };
    if (form.logo && fs.existsSync(form.logo)) {
      fs.copyFileSync(form.logo, path.join(dir, `logo${path.extname(form.logo).toLowerCase()}`));
      cfg.overlay.logo.path = `logo${path.extname(form.logo).toLowerCase()}`;
    } else if (base && cfg.overlay.logo.path && !path.isAbsolute(cfg.overlay.logo.path)) {
      // Same logo as the station copied, until one is chosen.
      const src = path.join(base.dir, cfg.overlay.logo.path);
      if (fs.existsSync(src)) {
        fs.mkdirSync(path.dirname(path.join(dir, cfg.overlay.logo.path)), { recursive: true });
        fs.copyFileSync(src, path.join(dir, cfg.overlay.logo.path));
      }
    }
    fs.writeFileSync(path.join(dir, 'config.json'), JSON.stringify(cfg, null, 1) + '\n');
    // Clocks need the new library's categories: start with music only, then set them in Impostazioni.
    const schedule = form.copySchedule && base
      ? readJson(path.join(base.dir, 'schedule.json'), null)
      : null;
    fs.writeFileSync(path.join(dir, 'schedule.json'), JSON.stringify(schedule ?? {
      clocks: { standard: { slots: ['music'] } }, grid: [], defaultClock: 'standard', breaks: [],
    }, null, 2) + '\n');
    // Created stopped: it starts when asked.
    fs.writeFileSync(path.join(dir, 'data', 'closed-by-user'), new Date().toISOString());
    this.scan();
    return id;
  }
}
