/**
 * Watches the channel as viewers get it: the public HLS address of the CDN
 * (.m3u8). While the program sends, the playlist there must keep changing; when
 * it stands still or cannot be read for a few minutes, the CDN is no longer
 * showing the channel even though the connection to it looks fine, and the
 * outputs are connected again.
 */
const UA = { 'user-agent': 'Mozilla/5.0 (VisualRadioZ)' };
/** Minutes without news on the public address before the outputs are reconnected. */
const STUCK_MINUTES = 3;
/** At most one reconnection in this many minutes. */
const RECONNECT_EVERY_MINUTES = 10;

async function get(url: string): Promise<string> {
  const res = await fetch(url, { headers: UA, signal: AbortSignal.timeout(15000), cache: 'no-store' });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.text();
}

/** The media playlist: a master playlist leads to its first variant. */
export async function mediaPlaylist(url: string): Promise<string> {
  let text = await get(url);
  if (/#EXT-X-STREAM-INF/.test(text)) {
    const variant = text.split(/\r?\n/).find((l) => l.trim() && !l.startsWith('#'));
    if (variant) text = await get(new URL(variant.trim(), url).toString());
  }
  return text;
}

/** What changes in a live playlist as it moves on: sequence number and segment names. */
export function fingerprint(playlist: string): string {
  const seq = playlist.match(/#EXT-X-MEDIA-SEQUENCE:(\d+)/)?.[1] ?? '';
  const segs = playlist.split(/\r?\n/).filter((l) => l.trim() && !l.startsWith('#'));
  return `${seq}|${segs.slice(-2).join('|')}`;
}

export class PublicCheck {
  private timer: NodeJS.Timeout | null = null;
  private last = '';
  private changedAt = 0;
  private reconnectedAt = 0;
  private down = false;
  state = { ok: true, since: 0, error: '' };

  private url: string;
  private note: (msg: string) => void;
  private reconnect: (reason: string) => void;

  constructor(url: string, note: (msg: string) => void, reconnect: (reason: string) => void) {
    this.url = url;
    this.note = note;
    this.reconnect = reconnect;
  }

  get enabled() {
    return /^https?:\/\/\S+\.m3u8(\?\S*)?$/i.test(this.url);
  }

  start() {
    if (!this.enabled) return;
    this.stop();
    // The CDN needs a little time to show a stream that has just started.
    this.changedAt = Date.now();
    this.last = '';
    this.down = false;
    this.timer = setInterval(() => this.check().catch(() => {}), 60000);
  }

  stop() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }

  async check() {
    const now = Date.now();
    let error = '';
    try {
      const f = fingerprint(await mediaPlaylist(this.url));
      if (f !== this.last) {
        this.last = f;
        this.changedAt = now;
      }
    } catch (e) {
      error = String((e as Error).message ?? e);
    }
    const still = (now - this.changedAt) / 60000;
    if (still < STUCK_MINUTES) {
      if (this.down) this.note(`il canale sul sito è di nuovo in movimento dopo ${Math.round((now - this.state.since) / 60000)} min`);
      this.down = false;
      this.state = { ok: true, since: this.changedAt, error: '' };
      return;
    }
    if (!this.down) {
      this.down = true;
      this.state = { ok: false, since: this.changedAt, error };
      this.note(`il canale sul sito è fermo da ${Math.round(still)} min${error ? ` (${error})` : ''}, anche se il programma sta trasmettendo`);
    }
    if (now - this.reconnectedAt > RECONNECT_EVERY_MINUTES * 60000) {
      this.reconnectedAt = now;
      // Count again from now: the CDN gets a few minutes to show the new connection.
      this.changedAt = now;
      this.reconnect('il canale sul sito era fermo');
    }
  }
}
