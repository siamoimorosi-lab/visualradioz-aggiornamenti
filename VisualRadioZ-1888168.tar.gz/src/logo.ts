import fs from 'node:fs';
import path from 'node:path';
import { type Config, resolvePath } from './config.ts';
import { FFMPEG, FFPROBE, run } from './ffmpeg.ts';

/**
 * Logos are often delivered on a large transparent canvas. Crop the
 * transparent margins once at start-up so `logo.width` is the width of the
 * visible logo and the margins place it where intended. Returns the file to
 * overlay, or '' when there is no logo.
 */
export async function prepareLogo(cfg: Config): Promise<string> {
  delete cfg.overlay.logo.still;
  delete cfg.overlay.logo.crop;
  delete cfg.overlay.logo.animated;
  delete cfg.overlay.logo.duration;
  if (!cfg.overlay.logo.path) return '';
  const src = resolvePath(cfg.overlay.logo.path);
  if (!fs.existsSync(src)) {
    console.warn(`logo non trovato: ${src}`);
    return '';
  }
  const file = isAnimatedLogo(src) ? await prepareAnimated(cfg, src) : await trimPicture(src, path.join(resolvePath(cfg.dataDir), 'logo-trimmed.png'));
  if (file && !isAnimatedLogo(src)) cfg.overlay.logo.ratio = pngRatio(file);
  // A picture of its own for logo transitions and the ticker, when one was chosen.
  const own = cfg.overlay.logo.stillFile ? resolvePath(cfg.overlay.logo.stillFile) : '';
  if (file && own && fs.existsSync(own)) cfg.overlay.logo.still = await trimPicture(own, path.join(resolvePath(cfg.dataDir), 'logo-still-own.png'));
  return file;
}

/** The picture without its transparent margins, or the picture itself when it has none. */
async function trimPicture(src: string, out: string): Promise<string> {
  const r = await run(FFMPEG, ['-hide_banner', '-i', src, '-vf', 'alphaextract,cropdetect=limit=8:round=2:skip=0:reset=0', '-f', 'null', '-'], 30000);
  const crop = [...r.stderr.matchAll(/crop=(\d+:\d+:\d+:\d+)/g)].pop()?.[1];
  if (r.code !== 0 || !crop) return src; // no alpha channel: use as is
  const c = await run(FFMPEG, ['-hide_banner', '-v', 'error', '-y', '-i', src, '-vf', `crop=${crop}`, out], 30000);
  return c.code === 0 ? out : src;
}

/** A logo that moves: a video with transparency, played in a loop. */
export function isAnimatedLogo(file: string): boolean {
  return /\.(mov|webm|mp4|m4v|mkv|gif|apng)$/i.test(file);
}

/**
 * The animated logo over one segment, in segment time: `[input]` → `[output]`, with the logo
 * from ffmpeg input `logoInput` (opened with logoInputArgs). Drawn by the decoders, which run
 * ahead of time: the always-on encoder, which reads its input at the pace of the clock, stops
 * sending anything with an endless second input in the ffmpeg the Windows installer carries.
 */
export function logoInputArgs(cfg: Config, tsOffset: number, length: number): string[] {
  const lg = cfg.overlay.logo;
  if (!lg.animated) return [];
  // Each segment picks the loop up where the previous one left it.
  const phase = lg.duration ? tsOffset % lg.duration : 0;
  return [...logoLoop(lg.animated), ...logoDecoder(lg.animated), '-ss', phase.toFixed(3), '-t', (length + 1).toFixed(3), '-i', lg.animated];
}

export function animatedLogoGraph(cfg: Config, logoInput: number, input: string, output: string): string {
  const lg = cfg.overlay.logo;
  const mx = lg.marginX ?? lg.margin;
  const my = lg.marginY ?? lg.margin;
  return `[${logoInput}:v]fps=${cfg.output.fps},${lg.crop ? `crop=${lg.crop},` : ''}scale=${lg.width}:-2,format=rgba,` +
    `colorchannelmixer=aa=${lg.opacity},setpts=PTS-STARTPTS[alogo];` +
    `[${input}][alogo]overlay=W-w-${mx}:${my}:eof_action=repeat,format=yuv420p[${output}]`;
}

/**
 * How ffmpeg must open an animated logo. WebM keeps its transparency only with the libvpx
 * decoder (ffmpeg's own drops it); GIF and APNG loop by themselves.
 */
export function logoDecoder(file: string): string[] {
  return /\.webm$/i.test(file) ? ['-c:v', 'libvpx-vp9'] : [];
}
export function logoLoop(file: string): string[] {
  return /\.(gif|apng)$/i.test(file) ? ['-ignore_loop', '0'] : ['-stream_loop', '-1'];
}

/**
 * An animated logo is used as it is. Found here: its shape, the part of the frame it ever
 * covers (so `logo.width` is the width of the visible logo, as for pictures) and one still
 * frame for the places that need a picture (logo transitions, the ticker). A file this
 * ffmpeg cannot play is refused here, not on air.
 */
async function prepareAnimated(cfg: Config, src: string): Promise<string> {
  const still = path.join(resolvePath(cfg.dataDir), 'logo-still.png');
  const p = await run(FFPROBE, ['-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=width,height:format=duration', '-of', 'json', src], 30000);
  let info: { streams?: { width: number; height: number }[]; format?: { duration?: string } } = {};
  try {
    info = JSON.parse(p.stdout);
  } catch {
    // unreadable: handled below
  }
  const st = info.streams?.[0];
  // The frame for transitions and the ticker: the second chosen in Grafica (2 by default).
  const dur = Number(info.format?.duration ?? 0);
  const at = Math.max(0, Math.min(cfg.overlay.logo.stillAt ?? 2, dur > 0.5 ? dur - 0.2 : 0));
  const dec = logoDecoder(src);
  const shot = await run(FFMPEG, ['-hide_banner', '-v', 'error', '-y', ...dec, '-ss', at.toFixed(2), '-i', src, '-frames:v', '1', still], 60000);
  if (!st || shot.code !== 0 || !fs.existsSync(still)) {
    console.warn(`logo animato non leggibile, canale senza logo: ${src} ${shot.stderr.trim().split('\n').pop() ?? ''}`);
    return '';
  }
  // The largest area the logo covers over its whole length (a logo alternating two marks shows
  // the second one only later), ten frames a second to keep it quick, and a few pixels of margin for the frames in between; no transparency = the
  // whole frame.
  const r = await run(FFMPEG, ['-hide_banner', ...dec, '-t', String(Math.min(dur > 0 ? dur : 180, 180)), '-i', src, '-vf', 'fps=10,alphaextract,cropdetect=limit=8:round=2:skip=0:reset=0', '-f', 'null', '-'], 180000);
  const crop = r.code === 0 ? [...r.stderr.matchAll(/crop=(\d+):(\d+):(\d+):(\d+)/g)].pop() : undefined;
  if (crop && Number(crop[1]) > 8 && Number(crop[2]) > 8) {
    // Widened by PAD pixels a side (even numbers, inside the frame): a sampled measure can miss
    // the frame where the animation reaches furthest.
    const PAD = 4;
    const [w, h, x, y] = crop.slice(1, 5).map(Number);
    const x0 = Math.max(0, x - PAD);
    const y0 = Math.max(0, y - PAD);
    const x1 = Math.min(st.width, x + w + PAD);
    const y1 = Math.min(st.height, y + h + PAD);
    const even = (n: number) => n - (n % 2);
    cfg.overlay.logo.crop = `${even(x1 - x0)}:${even(y1 - y0)}:${x0}:${y0}`;
    cfg.overlay.logo.ratio = even(y1 - y0) / even(x1 - x0);
    const c = await run(FFMPEG, ['-hide_banner', '-v', 'error', '-y', '-i', still, '-vf', `crop=${cfg.overlay.logo.crop}`, still + '.png'], 30000);
    if (c.code === 0) fs.renameSync(still + '.png', still);
  } else {
    cfg.overlay.logo.ratio = st.height / st.width;
  }
  cfg.overlay.logo.still = still;
  cfg.overlay.logo.animated = src;
  cfg.overlay.logo.duration = Number(info.format?.duration) > 0.2 ? Number(info.format?.duration) : 0;
  return src;
}

/** Height / width of a PNG, from its header. */
function pngRatio(file: string): number | undefined {
  try {
    const b = fs.readFileSync(file);
    if (b.readUInt32BE(12) !== 0x49484452) return undefined; // 'IHDR'
    return b.readUInt32BE(20) / b.readUInt32BE(16);
  } catch {
    return undefined;
  }
}
