import fs from 'node:fs';
import path from 'node:path';
import { Resvg } from '@resvg/resvg-js';
import { type Config, gfxScale, resolvePath } from './config.ts';
import { FFMPEG, run } from './ffmpeg.ts';

/**
 * Turns each news source's logo into a white mark on transparent, all the
 * same height, for the ticker. Anything that is not near-white becomes white
 * (dark text, coloured accents); near-white becomes transparent, so logos
 * drawn as white letters in dark boxes come out as cut-outs.
 */
export async function prepareFeedLogos(cfg: Config): Promise<Map<string, string>> {
  const out = new Map<string, string>();
  const dir = path.join(resolvePath(cfg.dataDir), 'feed-logos');
  fs.mkdirSync(dir, { recursive: true });
  const { width: boxW, height: boxH } = feedLogoBox(cfg);
  // The event programme's logo is prepared the same way, under the block key 'events'.
  const programme = /^https?:\/\//i.test(cfg.events.url) && cfg.events.logo ? [{ label: 'events', logo: cfg.events.logo }] : [];
  for (const f of [...cfg.overlay.ticker.feeds, ...programme]) {
    if (!f.logo) continue;
    const src = resolvePath(f.logo);
    if (!fs.existsSync(src)) {
      console.warn(`logo della fonte non trovato: ${src}`);
      continue;
    }
    let raster = src;
    if (src.toLowerCase().endsWith('.svg')) {
      raster = path.join(dir, `${slug(f.label)}-raster.png`);
      fs.writeFileSync(raster, new Resvg(fs.readFileSync(src), { fitTo: { mode: 'height', value: 300 } }).render().asPng());
    }
    const white = path.join(dir, `${slug(f.label)}-white.png`);
    // A logo that is already white on transparent keeps its shape. Otherwise luma decides:
    // < ~65% → opaque white, > 90% → transparent (white letters in dark boxes become cut-outs).
    const avg = async (vf: string) => {
      const s = await run(FFMPEG, ['-hide_banner', '-i', raster, '-vf', `${vf},signalstats,metadata=print:key=lavfi.signalstats.YAVG`, '-f', 'null', '-'], 30000);
      return Number(s.stderr.match(/lavfi\.signalstats\.YAVG=([\d.]+)/)?.[1] ?? NaN);
    };
    const alpha = await avg('format=rgba,alphaextract');
    // Mean brightness of the visible pixels: the picture over black, divided by its coverage.
    const overBlack = await avg('format=rgba,premultiply=inplace=1,format=yuv444p');
    const lightShape = alpha > 1 && alpha < 235 && overBlack / (alpha / 255) > 200;
    const lum = '(0.299*r(X,Y)+0.587*g(X,Y)+0.114*b(X,Y))';
    const shape = lightShape ? 'alpha(X,Y)' : `alpha(X,Y)*clip((229-${lum})/64,0,1)`;
    let r = await run(FFMPEG, ['-hide_banner', '-v', 'error', '-y', '-i', raster, '-vf',
      `format=rgba,geq=r=255:g=255:b=255:a='${shape}'`, white], 60000);
    if (r.code !== 0) continue;
    r = await run(FFMPEG, ['-hide_banner', '-i', white, '-vf', 'alphaextract,cropdetect=limit=8:round=2:skip=0:reset=0', '-f', 'null', '-'], 30000);
    const crop = [...r.stderr.matchAll(/crop=(\d+:\d+:\d+:\d+)/g)].pop()?.[1];
    const file = path.join(dir, `${slug(f.label)}.png`);
    // Same height for all; very wide marks are limited by the box width instead.
    r = await run(FFMPEG, ['-hide_banner', '-v', 'error', '-y', '-i', white, '-vf',
      `${crop ? `crop=${crop},` : ''}scale=${boxW}:${boxH}:force_original_aspect_ratio=decrease:flags=lanczos,` +
      `pad=${boxW}:${boxH}:ow-iw:(oh-ih)/2:color=black@0,format=rgba`, file], 60000);
    if (r.code === 0) out.set(f.label, file);
  }
  return out;
}

export function feedLogoBox(cfg: Config) {
  const H = cfg.output.height * gfxScale(cfg);
  return { width: Math.round((H * 0.12) / 2) * 2, height: Math.round((H * 0.034) / 2) * 2 };
}

const slug = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, '-');
