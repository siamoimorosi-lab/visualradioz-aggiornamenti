/**
 * Broadcast-style audio processing on the final mix, in the spirit of
 * Omnia/Orban processors: a slow AGC rides levels between songs, a 4-band
 * compressor gives the dense "radio" sound and keeps the tonal balance even
 * from track to track, a little bass and air add emphasis, and a look-ahead
 * limiter catches the peaks.
 */

export type Preset = 'off' | 'light' | 'radio' | 'loud';

interface Band {
  /** Upper edge of the band in Hz (the last band has none). */
  upTo?: number;
  threshold: number; // dBFS
  ratio: number;
  attack: number; // ms
  release: number; // ms
  makeup: number; // dB
}

interface PresetDef {
  /**
   * Slow AGC on perceived loudness (loudnorm, real-time mode): target level
   * in LUFS and allowed loudness range in LU.
   */
  agc: { target: number; range: number } | null;
  bands: Band[];
  bassDb: number;
  airDb: number;
  /** Final AGC + true-peak limiter after the bands: output loudness (LUFS) and range (LU). */
  final: { target: number; range: number };
  /** Safety limiter ceiling in dBFS (sample peak). */
  ceiling: number;
}

const PRESETS: Record<Exclude<Preset, 'off'>, PresetDef> = {
  light: {
    agc: { target: -18, range: 9 },
    bands: [
      { upTo: 150, threshold: -22, ratio: 2, attack: 40, release: 400, makeup: 2 },
      { upTo: 1200, threshold: -22, ratio: 2, attack: 25, release: 300, makeup: 2 },
      { upTo: 5000, threshold: -24, ratio: 2, attack: 15, release: 200, makeup: 2 },
      { threshold: -26, ratio: 2, attack: 8, release: 150, makeup: 2 },
    ],
    bassDb: 1.5,
    airDb: 1,
    final: { target: -14, range: 7 },
    ceiling: -1.5,
  },
  radio: {
    agc: { target: -18, range: 4 },
    // Low thresholds + moderate ratios: each band is levelled, not just its peaks tamed.
    bands: [
      { upTo: 120, threshold: -38, ratio: 3, attack: 40, release: 400, makeup: 12 },
      { upTo: 1000, threshold: -38, ratio: 3, attack: 25, release: 300, makeup: 11 },
      { upTo: 5000, threshold: -40, ratio: 3, attack: 12, release: 200, makeup: 12 },
      { threshold: -42, ratio: 3, attack: 6, release: 150, makeup: 12 },
    ],
    bassDb: 3,
    airDb: 2,
    final: { target: -11, range: 3 },
    ceiling: -1.5,
  },
  loud: {
    agc: { target: -17, range: 3 },
    bands: [
      { upTo: 120, threshold: -26, ratio: 6, attack: 25, release: 250, makeup: 8 },
      { upTo: 1000, threshold: -26, ratio: 4, attack: 15, release: 200, makeup: 7 },
      { upTo: 5000, threshold: -28, ratio: 4, attack: 8, release: 120, makeup: 8 },
      { threshold: -30, ratio: 4, attack: 4, release: 80, makeup: 8 },
    ],
    bassDb: 4,
    airDb: 3,
    final: { target: -9, range: 2 },
    ceiling: -1.5,
  },
};

const lin = (db: number) => Math.pow(10, db / 20).toFixed(4);

/**
 * Filtergraph text that turns the audio stream labelled `input` into
 * `output`. Labels inside use the `ap` prefix.
 */
export interface Tuning {
  loudness: number | null;
  compression: number | null;
  bassDb: number | null;
  airDb: number | null;
}

/** A preset with the values set on the Quality page. Compression k scales how far each band is from no compression. */
export function tuned(preset: Exclude<Preset, 'off'>, t?: Tuning): PresetDef {
  const p = PRESETS[preset];
  const k = t?.compression ?? 1;
  const ref = p.agc?.target ?? -18;
  return {
    ...p,
    bands: p.bands.map((b) => ({
      ...b,
      ratio: Math.max(1, 1 + (b.ratio - 1) * k),
      threshold: Math.min(0, ref + (b.threshold - ref) * k),
      makeup: Math.max(0, b.makeup * k),
    })),
    bassDb: t?.bassDb ?? p.bassDb,
    airDb: t?.airDb ?? p.airDb,
    final: { ...p.final, target: t?.loudness ?? p.final.target },
  };
}

/** The preset's own values, for the Quality page. */
export function presetValues(preset: Preset) {
  if (preset === 'off') return null;
  const p = PRESETS[preset];
  return { loudness: p.final.target, compression: 1, bassDb: p.bassDb, airDb: p.airDb };
}

export function audioProcessing(preset: Preset, input: string, output: string, tuning?: Tuning): string {
  if (preset === 'off') return `[${input}]alimiter=limit=${lin(-1)}:level=false[${output}]`;
  const p = tuned(preset, tuning);
  const parts: string[] = [];
  let pre = `[${input}]`;
  // loudnorm works at 192 kHz internally: resample back before the band split.
  if (p.agc) pre += `loudnorm=I=${p.agc.target}:LRA=${p.agc.range}:TP=-4,aresample=48000,`;
  const splits = p.bands.filter((b) => b.upTo).map((b) => b.upTo).join(' ');
  const labels = p.bands.map((_, i) => `apb${i}`);
  parts.push(`${pre}acrossover=split=${splits}:order=4th${labels.map((l) => `[${l}]`).join('')}`);
  p.bands.forEach((b, i) => {
    parts.push(
      `[${labels[i]}]acompressor=threshold=${lin(b.threshold)}:ratio=${b.ratio}:attack=${b.attack}:` +
        `release=${b.release}:makeup=${lin(b.makeup)}:knee=4[apc${i}]`,
    );
  });
  parts.push(
    `${labels.map((_, i) => `[apc${i}]`).join('')}amix=inputs=${p.bands.length}:normalize=0,` +
      `bass=g=${p.bassDb}:f=80,treble=g=${p.airDb}:f=9000,` +
      `loudnorm=I=${p.final.target}:LRA=${p.final.range}:TP=${p.ceiling},aresample=48000,` +
      `alimiter=limit=${lin(p.ceiling)}:attack=1:release=50:level=false[${output}]`,
  );
  return parts.join(';');
}
