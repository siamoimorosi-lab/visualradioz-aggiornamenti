// Fitting texts to the room they have, measured with the real font: a long title is
// drawn a little smaller, then cut at a word with "…" only if it still does not fit,
// or spread over two lines.
import { Resvg } from '@resvg/resvg-js';

const widths = new Map<string, number>();

/** Width in pixels of `text` drawn with `font` at `size` (measured once, then cached). */
export function textWidth(font: string, size: number, text: string): number {
  const key = `${font}|${size}|${text}`;
  let w = widths.get(key);
  if (w === undefined) {
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${Math.ceil(size * text.length * 2) + 10}" height="${size * 3}">` +
      `<text x="0" y="${size * 2}" font-size="${size}">${text.replace(/&/g, '&amp;').replace(/</g, '&lt;')}</text></svg>`;
    let box;
    try {
      box = new Resvg(svg, { font: { fontFiles: [font], loadSystemFonts: false, defaultFontFamily: 'Poppins' } }).getBBox();
    } catch {
      box = undefined;
    }
    // Not a Poppins file (e.g. a system font): an estimate is good enough for spacing.
    w = box ? box.x + box.width : size * 0.6 * text.length;
    if (widths.size > 5000) widths.clear();
    widths.set(key, w);
  }
  return w;
}

/** `text` cut at a word boundary, with "…", so that it fits in `max` pixels. */
export function fitWidth(font: string, size: number, text: string, max: number): string {
  if (textWidth(font, size, text) <= max) return text;
  const words = text.split(' ');
  for (let n = words.length - 1; n > 0; n--) {
    const t = words.slice(0, n).join(' ').replace(/[\s,.;:–-]+$/, '') + '…';
    if (textWidth(font, size, t) <= max) return t;
  }
  // One long word: by characters.
  for (let n = text.length - 1; n > 0; n--) {
    const t = text.slice(0, n) + '…';
    if (textWidth(font, size, t) <= max) return t;
  }
  return '…';
}

/**
 * Size and text for a line of at most `max` pixels: the size goes down as far as `minScale`
 * of `size` so that the whole text fits; only beyond that it is cut.
 */
export function shrinkToFit(font: string, size: number, text: string, max: number, minScale = 0.75): { text: string; size: number } {
  const w = textWidth(font, size, text);
  if (w <= max) return { text, size };
  const smaller = Math.max(Math.round(size * minScale), Math.floor((size * max) / w));
  if (textWidth(font, smaller, text) <= max) return { text, size: smaller };
  return { text: fitWidth(font, smaller, text, max), size: smaller };
}

/** `text` on two lines of at most `max` pixels, broken at a word; the second cut with "…" if needed. */
export function twoLines(font: string, size: number, text: string, max: number): [string, string] {
  const words = text.split(' ');
  let first = '';
  let i = 0;
  for (; i < words.length; i++) {
    const t = first ? `${first} ${words[i]}` : words[i];
    if (textWidth(font, size, t) > max && first) break;
    first = t;
  }
  if (textWidth(font, size, first) > max) first = fitWidth(font, size, first, max);
  return [first, fitWidth(font, size, words.slice(i).join(' '), max)];
}
