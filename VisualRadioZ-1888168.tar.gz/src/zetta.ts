import fs from 'node:fs';
import { DatabaseSync } from 'node:sqlite';

/** Cue points of one song, in seconds from the start of its audio file. */
export interface ExternalCue {
  /** Where the song starts (trim start). */
  start: number | null;
  /** Where the next song starts while this one fades (early next / trim end). */
  mixOut: number | null;
  /** Release year, e.g. "1965". */
  year?: string;
}

/** "03:29", "1:02:03", "228.43" → seconds; empty or invalid → null. */
export function parseTime(v: unknown): number | null {
  const s = String(v ?? '').trim().replace(',', '.');
  if (!s) return null;
  const parts = s.split(':').map(Number);
  if (parts.some((n) => !Number.isFinite(n))) return null;
  return parts.reduce((acc, n) => acc * 60 + n, 0);
}

/**
 * Reads mix points from a ZettaReload/GSelector song archive (SQLite,
 * table `canzoni`), keyed by song GUID. The videoclips built by VideoDJ
 * carry the radio audio file, so these times apply to them unchanged.
 */
export function loadZettaCues(dbPath: string): Map<string, ExternalCue> {
  const out = new Map<string, ExternalCue>();
  if (!fs.existsSync(dbPath)) throw new Error(`archivio Zetta non trovato: ${dbPath}`);
  const db = new DatabaseSync(dbPath, { readOnly: true });
  try {
    const rows = db.prepare('SELECT guid, trim_start, trim_end, early_next, anno FROM canzoni').all() as Record<string, unknown>[];
    for (const r of rows) {
      const start = parseTime(r.trim_start);
      const mixOut = parseTime(r.early_next) ?? parseTime(r.trim_end);
      const year = String(r.anno ?? '').match(/\b(19|20)\d\d\b/)?.[0];
      if (start === null && mixOut === null && !year) continue;
      out.set(String(r.guid).toLowerCase(), { start, mixOut, ...(year ? { year } : {}) });
    }
  } finally {
    db.close();
  }
  return out;
}

const GUID = /([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})/i;

/** The song GUID in a file name such as VIDEO_<guid>.mp4. */
export function guidOf(file: string): string | null {
  return file.match(GUID)?.[1].toLowerCase() ?? null;
}
