/**
 * Desktop launcher: starts the playout in the background if it is not running
 * yet, then opens the panel in its own browser window (Edge/Chrome "app"
 * mode), so the channel works like an application. The playout keeps running
 * when the window is closed; it stops from the panel ("Esci").
 *
 * With --background (the watchdog, run every few minutes by Windows Task
 * Scheduler) it only starts the playout if it is down, and opens no window;
 * after "Esci" it leaves it off until someone opens it from the icon.
 */
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { loadConfig, resolvePath, rootDir } from './config.ts';

const cfg = loadConfig();
const background = process.argv.includes('--background');
/** Written by "Esci" in the panel: the program was closed on purpose. */
const closedMark = path.join(resolvePath(cfg.dataDir), 'closed-by-user');
const host = cfg.server.host === '0.0.0.0' ? '127.0.0.1' : cfg.server.host;
const url = `http://${host}:${cfg.server.port}/${cfg.server.token ? `?token=${encodeURIComponent(cfg.server.token)}` : ''}`;

async function running(): Promise<boolean> {
  try {
    const r = await fetch(new URL('/api/status', url).href + (cfg.server.token ? `?token=${encodeURIComponent(cfg.server.token)}` : ''), {
      signal: AbortSignal.timeout(1500),
    });
    return r.ok;
  } catch {
    return false;
  }
}

function startPlayout() {
  const dataDir = resolvePath(cfg.dataDir);
  fs.mkdirSync(dataDir, { recursive: true });
  const log = fs.openSync(path.join(dataDir, 'run-live.log'), 'a');
  fs.writeSync(log, `\n---- avvio ${new Date().toLocaleString()}${background ? ' (watchdog: il programma non era attivo)' : ''} ----\n`);
  const child = spawn(process.execPath, [path.join(rootDir, 'src', 'main.ts')], {
    cwd: rootDir,
    detached: true,
    windowsHide: true,
    stdio: ['ignore', log, log],
  });
  child.unref();
}

/** The panel in a window of its own, without tabs and address bar where the browser allows it. */
function openWindow() {
  const app = [`--app=${url}`, '--window-size=1440,920'];
  const candidates =
    process.platform === 'win32'
      ? [
          `${process.env['ProgramFiles(x86)']}\\Microsoft\\Edge\\Application\\msedge.exe`,
          `${process.env.ProgramFiles}\\Microsoft\\Edge\\Application\\msedge.exe`,
          `${process.env.ProgramFiles}\\Google\\Chrome\\Application\\chrome.exe`,
          `${process.env.LOCALAPPDATA}\\Google\\Chrome\\Application\\chrome.exe`,
        ]
      : process.platform === 'darwin'
        ? ['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge']
        : ['/usr/bin/google-chrome', '/usr/bin/chromium', '/usr/bin/microsoft-edge'];
  const browser = candidates.find((f) => fs.existsSync(f));
  const [cmd, args] = browser
    ? [browser, app]
    : process.platform === 'win32'
      ? ['cmd', ['/c', 'start', '', url]]
      : [process.platform === 'darwin' ? 'open' : 'xdg-open', [url]];
  spawn(cmd, args, { detached: true, stdio: 'ignore', windowsHide: false }).unref();
}

/** A second click while the program is starting must not start it twice. */
function claimLaunch(): boolean {
  const lock = path.join(resolvePath(cfg.dataDir), 'launch.lock');
  try {
    if (Date.now() - fs.statSync(lock).mtimeMs < 40_000) return false;
    fs.rmSync(lock);
  } catch {
    // no lock
  }
  try {
    fs.writeFileSync(lock, String(process.pid), { flag: 'wx' });
    return true;
  } catch {
    return false;
  }
}

if (background && fs.existsSync(closedMark)) process.exit(0);
if (!background) fs.rmSync(closedMark, { force: true });
if (!(await running())) {
  if (claimLaunch()) {
    if (background) console.log('watchdog: programma non attivo, lo riavvio');
    startPlayout();
  }
  // The panel answers within a few seconds (the library loads from library.json).
  for (let i = 0; i < 60 && !(await running()); i++) await new Promise((r) => setTimeout(r, 500));
}
if (!background) openWindow();
