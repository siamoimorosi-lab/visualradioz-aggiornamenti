import type { Config } from './config.ts';
import type { Card } from './cards.ts';
import { tickerLayout } from './graphics.ts';
import { sec } from './ffmpeg.ts';

/**
 * Squeeze-back for info cards: the clip shrinks smoothly to the right over a
 * blurred, darkened copy of itself while a side panel (weather/traffic)
 * slides in from the left; at the end everything returns to full screen.
 */

const MOVE = 0.9; // seconds for each move
const PAGE_FADE = 0.35;

/**
 * The panel slides in from the left with the squeeze; later pages fade in over
 * the previous one. With a page bar, the segment of the page on screen fills
 * up in white while that page lasts.
 */
function panelPages(
  L: ReturnType<typeof squeezeLayout>, fps: number, at: number, end: number, first: number, pages: number, e: string, output: string,
  progress?: Card['progress'],
): string[] {
  const out: string[] = [];
  const slot = (end - at) / pages;
  let cur = 'sqv';
  for (let i = 0; i < pages; i++) {
    const s = at + i * slot;
    const t = i === pages - 1 ? end : s + slot + PAGE_FADE;
    const fadeIn = i > 0 ? `,fade=t=in:st=0:d=${sec(PAGE_FADE)}:alpha=1` : '';
    out.push(`[${first + i}:v]format=rgba${fadeIn},setpts=PTS+${sec(s)}/TB[sqcard${i}]`);
    const seg = progress?.segments[i];
    const label = i === pages - 1 && !seg ? output : `sqp${i}`;
    const panelX = `${L.margin}-(${L.panelW}+${L.margin})*(1-${e})`;
    out.push(`[${cur}][sqcard${i}]overlay=x='${panelX}':y=${L.y}:eval=frame:eof_action=pass:` +
      `enable='between(t,${sec(s)},${sec(t)})'[${label}]`);
    cur = label;
    if (seg && progress) {
      const pageEnd = i === pages - 1 ? end : s + slot;
      const fill = `clip((t-${sec(s)})/${sec(pageEnd - s)},0,1)`;
      const barLabel = i === pages - 1 ? output : `sqb${i}`;
      out.push(
        `color=c=white:s=${seg.w}x${progress.h}:r=${fps}:d=${sec(end)},format=rgba,` +
          `scale=w='max(2,trunc(${seg.w}*${fill}/2)*2)':h=${progress.h}:eval=frame[sqbar${i}]`,
        `[${cur}][sqbar${i}]overlay=x='${panelX}+${seg.x}':y=${L.y + progress.y}:eval=frame:eof_action=pass:` +
          `enable='between(t,${sec(s)},${sec(pageEnd)})'[${barLabel}]`,
      );
      cur = barLabel;
    }
  }
  return out;
}

/**
 * Same as squeezeGraph, but the costly part (blurred background, animated
 * scaling, compositing) runs only during the card: the clip is cut into
 * before / during / after and joined again, frame-exact.
 */
export function squeezeWindow(
  cfg: Config, at: number, seconds: number, firstInput: number, pages: number, input: string, output: string, progress?: Card['progress'],
): string {
  const end = at + seconds;
  return [
    `[${input}]split=3[sw0][sw1][sw2]`,
    `[sw0]trim=end=${sec(at)},setpts=PTS-STARTPTS[swpre]`,
    `[sw1]trim=start=${sec(at)}:end=${sec(end)},setpts=PTS-STARTPTS[swmid]`,
    `[sw2]trim=start=${sec(end)},setpts=PTS-STARTPTS[swpost]`,
    squeezeGraph(cfg, 0, seconds, firstInput, pages, 'swmid', 'swsq', progress),
    `[swpre][swsq][swpost]concat=n=3:v=1:a=0,format=yuv420p[${output}]`,
  ].join(';');
}

/** Final layout of the squeezed state, also used to size the side panel. */
export function squeezeLayout(cfg: Config) {
  const { width: W, height: H } = cfg.output;
  const scale = cfg.cards.squeeze;
  const margin = Math.round(H * 0.06);
  const avail = H - tickerLayout(cfg).bar; // above the ticker bar
  const w = Math.round((W * scale) / 2) * 2;
  const h = Math.round((H * scale) / 2) * 2;
  const y = Math.round((avail - h) / 2);
  const panelW = W - w - 3 * margin;
  return { W, H, w, h, x: W - w - margin, y, margin, avail, panelW, panelH: h };
}

/**
 * `[input]` → `[output]`, squeezed during [at, at + seconds]; the panel pages
 * come from ffmpeg inputs `firstInput`…, one after the other, cross-fading.
 */
export function squeezeGraph(
  cfg: Config, at: number, seconds: number, firstInput: number, pages: number, input: string, output: string, progress?: Card['progress'],
): string {
  const L = squeezeLayout(cfg);
  const s = cfg.cards.squeeze;
  const end = at + seconds;
  // Eased amount of squeeze, 0 (full screen) … 1 (squeezed): smoothstep in and out.
  const up = `clip((t-${sec(at)})/${MOVE},0,1)`;
  const down = `clip((${sec(end)}-t)/${MOVE},0,1)`;
  const p = `min(${up},${down})`;
  const e = `(${p}*${p}*(3-2*${p}))`;
  const w = `trunc(${L.W}*(1-${1 - s}*${e})/2)*2`;
  return [
    `[${input}]split[sqa][sqb]`,
    // The background is blurred anyway: the cheapest scaling is good enough for it.
    `[sqa]scale=${Math.round(L.W / 4 / 2) * 2}:${Math.round(L.H / 4 / 2) * 2}:flags=fast_bilinear,gblur=sigma=14,` +
      `eq=brightness=-0.22:saturation=0.75,scale=${L.W}:${L.H}:flags=fast_bilinear[sqbg]`,
    `[sqb]scale=w='${w}':h=-2:eval=frame:flags=bilinear[sqfg]`,
    `[sqbg][sqfg]overlay=x='(W-w)-${L.margin}*${e}':y='${e}*(${L.avail}-h)/2':eval=frame[sqv]`,
    ...panelPages(L, cfg.output.fps, at, end, firstInput, pages, e, output, progress),
  ].join(';');
}
