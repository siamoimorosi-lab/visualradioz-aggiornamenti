import fs from 'node:fs';
import path from 'node:path';
import { type Config, gfxScale, resolvePath } from './config.ts';
import { filterValue } from './ffmpeg.ts';
import { feedLogoBox } from './feedlogos.ts';

/**
 * The ticker runs in blocks: the channel's own slot (text typed in the panel,
 * or what is on air), then `perBlock` headlines of each feed in order. The
 * layout depends only on the config, so the encoder (which shows each
 * block's logo) and the Ticker (which writes the texts) agree on what airs
 * in every cycle without talking to each other.
 */
export interface TickerBlock {
  key: string;
  label: string;
  slots: number;
  logo?: string;
  /** A news source: off outside the news hours. */
  feed?: boolean;
}

const hhmm = (s: string) => {
  const m = /^(\d{1,2}):(\d{2})$/.exec(String(s ?? '').trim());
  return m && Number(m[1]) < 24 && Number(m[2]) < 60 ? Number(m[1]) * 3600 + Number(m[2]) * 60 : null;
};

/** News hours in seconds of the day, or null for all day. `from` > `to` crosses midnight. */
export function newsWindow(cfg: Config): { from: number; to: number } | null {
  const from = hhmm(cfg.overlay.ticker.newsFrom);
  const to = hhmm(cfg.overlay.ticker.newsTo);
  if (from === null || to === null || from === to) return null;
  return { from, to };
}

export function newsOnAt(cfg: Config, daySec: number): boolean {
  const w = newsWindow(cfg);
  if (!w) return true;
  const x = ((daySec % 86400) + 86400) % 86400;
  return w.from < w.to ? x >= w.from && x < w.to : x >= w.from || x < w.to;
}

/**
 * The blocks of a ticker cycle that starts `daySec` seconds after midnight. Outside the news
 * hours the news sources drop out. Cycle n starts at dayOffset + n * seconds, where dayOffset
 * is the time of day at the encoder's t = 0: encoder and Ticker both work it out this way.
 */
export function blocksAt(cfg: Config, blocks: TickerBlock[], daySec: number): TickerBlock[] {
  return newsOnAt(cfg, daySec) ? blocks : blocks.filter((b) => !b.feed);
}

export function tickerBlocks(cfg: Config, feedLogos: Map<string, string> = new Map(), channelLogo = ''): TickerBlock[] {
  const t = cfg.overlay.ticker;
  return [
    { key: 'channel', label: t.label, slots: 1, logo: channelLogo || undefined },
    // The event programme is the channel's own: it carries the channel's logo.
    ...(/^https?:\/\//i.test(cfg.events.url) ? [{ key: 'events', label: cfg.events.label, slots: t.perBlock, logo: feedLogos.get('events') ?? (channelLogo || undefined) }] : []),
    ...t.feeds.map((f) => ({ key: f.label, label: f.label, slots: t.perBlock, logo: feedLogos.get(f.label), feed: true })),
  ];
}

/** Which block and which slot inside it a ticker cycle belongs to. */
export function blockAt(blocks: TickerBlock[], cycle: number): { block: TickerBlock; index: number } {
  const total = blocks.reduce((n, b) => n + b.slots, 0);
  let s = ((cycle % total) + total) % total;
  for (const block of blocks) {
    if (s < block.slots) return { block, index: s };
    s -= block.slots;
  }
  return { block: blocks[0], index: 0 };
}

/**
 * On-air graphics drawn by the encoder: clock and news ticker. The ticker
 * shows one headline at a time: it rises from below, stays for `seconds`
 * while a thin grey line fills up to announce the next one, then leaves
 * upwards. Its texts live in two files that drawtext re-reads exactly at
 * each cycle start (reload every `seconds * fps` frames).
 */

/** What each file last got: one that does not change is not written again (ffmpeg re-reads them). */
const written = new Map<string, string>();

/** Replace a text file atomically; Windows briefly refuses while ffmpeg reads it. */
export function writeAtomic(file: string, text: string) {
  // On Windows the encoder re-reading a file while it is being replaced fails ("Permission
  // denied") and drawtext stops the encoder: replace only files whose text changes.
  if (written.get(file) === text && fs.existsSync(file)) return;
  written.delete(file);
  const tmp = file + '.tmp';
  fs.writeFileSync(tmp, text);
  for (let i = 0; ; i++) {
    try {
      fs.renameSync(tmp, file);
      written.set(file, text);
      return;
    } catch (e) {
      if (i >= 20) throw e;
      const until = Date.now() + 25;
      while (Date.now() < until);
    }
  }
}

export function tickerFiles(cfg: Config) {
  const dir = resolvePath(cfg.dataDir);
  return {
    label: path.join(dir, 'ticker-label.txt'),
    text: path.join(dir, 'ticker-text.txt'),
    sub: path.join(dir, 'ticker-sub.txt'),
    /** A headline without a summary, centred in the bar (the two lines above stay blank). */
    solo: path.join(dir, 'ticker-solo.txt'),
    /** A headline too long for one line: over two lines, a little smaller, without the summary. */
    long1: path.join(dir, 'ticker-long1.txt'),
    long2: path.join(dir, 'ticker-long2.txt'),
  };
}

/**
 * Top-left block: clock | title / artist · year. One grid for the encoder
 * (clock) and the decoders (texts), positioned by baselines (drawtext
 * y_align=baseline): the title's cap line sits on the clock's cap line and
 * the second line shares the clock's baseline. Poppins cap height ≈ 0.70 em.
 */
export function topLeftLayout(cfg: Config) {
  const { width: W, height: H } = cfg.output;
  const x0 = cfg.overlay.logo.marginX ?? Math.round(W * 0.05);
  const CAP = 0.7;
  const s = gfxScale(cfg);
  // The clock and the song on air next to it, readable at a glance (1080p: 48, 24 and 18 px).
  const clockSize = Math.round(H * 0.045 * s);
  const capTop = Math.round(H * 0.045);
  const baseline = Math.round(capTop + CAP * clockSize);
  const titleSize = Math.round(H * 0.0225 * s);
  const metaSize = Math.round(H * 0.0168 * s);
  // Poppins digits are proportional: the widest time ("00:00") is about 2.5 em, so the
  // divider goes there and the clock is right-aligned against it (constant gap).
  const gap = Math.round(H * 0.016 * s);
  const sepX = x0 + Math.round(clockSize * 2.5) + gap;
  // Title on the clock's top line, artist a full line below it (its foot just under the clock's).
  const titleBaseline = Math.round(capTop + CAP * titleSize);
  const metaBaseline = Math.max(baseline, titleBaseline + Math.round(metaSize * 1.35));
  return {
    x0, clockSize, clockBaseline: baseline, clockRight: sepX - gap,
    sepX, sepY: capTop, sepH: metaBaseline - capTop, sepW: Math.max(2, Math.round(H * 0.0019)),
    textX: sepX + gap,
    titleSize, titleBaseline,
    metaSize, metaBaseline,
  };
}

/** Geometry shared by the filters and by Ticker (to fit headlines to the bar). */
export function tickerLayout(cfg: Config) {
  const { width: W, height: H } = cfg.output;
  const s = gfxScale(cfg);
  const bar = Math.round(H * 0.082 * s);
  const margin = cfg.overlay.logo.marginX ?? Math.round(W * 0.05);
  const labelCol = Math.round(H * 0.2 * s);
  const textSize = Math.round(H * 0.026 * s);
  const subSize = Math.round(H * 0.0185 * s);
  const gap = Math.round(H * 0.007 * s);
  // Title and summary as one block, centred in the bar.
  const titleY = Math.round((bar - textSize - gap - subSize) / 2);
  const textX = margin + labelCol + Math.round(H * 0.025 * s);
  // Two lines of a long headline fill the same block as title and summary.
  const longSize = Math.round((textSize + subSize) / 2);
  const longY = Math.round((bar - 2 * longSize - gap) / 2);
  return {
    W, H, bar, margin, labelCol, labelSize: Math.round(H * 0.02 * s), textSize, subSize,
    titleY, subY: titleY + textSize + gap, soloY: Math.round((bar - textSize) / 2), textX, textWidth: W - textX - margin,
    longSize, longY1: longY, longY2: longY + longSize + gap,
  };
}

/** Clock and ticker filters: `[in]` → `[out]`. */
export function encoderGraphics(cfg: Config, input: string, output: string, blocks: TickerBlock[] = [], logoInputs: number[] = [], dayOffset = 0): string {
  const ov = cfg.overlay;
  const { fps } = cfg.output;
  const L = tickerLayout(cfg);
  const steps: string[] = [];
  const extra: string[] = [];
  let cur = input;
  const chain = (f: string) => steps.push(f);

  if (ov.clock.enabled) {
    const T = topLeftLayout(cfg);
    chain(
      `drawtext=fontfile=${filterValue(ov.fontBold)}:text='%{localtime\\:%H\\\\\\:%M}':fontsize=${T.clockSize}:` +
        `fontcolor=white:x=${T.clockRight}-tw:y=${T.clockBaseline}:y_align=baseline:shadowcolor=black@0.4:shadowx=0:shadowy=2`,
    );
  }

  if (ov.ticker.enabled) {
    const C = ov.ticker.seconds;
    const top = L.H - L.bar;
    const line = Math.max(2, Math.round(L.H * 0.002));
    const files = tickerFiles(cfg);
    for (const f of Object.values(files)) if (!fs.existsSync(f)) writeAtomic(f, ' ');
    // Every expression below sits inside '...', so its commas need no escaping.
    const p = `mod(t,${C})`;
    // A short, slow rise (1-2 px per frame) with an ease-out; a quicker exit upwards.
    const IN = 0.6;
    const OUT = 0.4;
    const dy = Math.round(L.bar * 0.3);
    const motion = (delay: number) => {
      const pin = `clip((${p}-${delay})/${IN},0,1)`;
      const pout = `clip((${p}-${C - OUT})/${OUT},0,1)`;
      return { y: `${dy}*pow(1-${pin},3)-${dy}*pow(${pout},2)`, alpha: `${pin}*(1-${pout})` };
    };
    const reload = Math.round(C * fps);
    chain(`drawbox=x=0:y=${top}:w=${L.W}:h=${L.bar}:color=0x0b0e17@0.86:t=fill`);
    chain(`drawbox=x=0:y=${top - line}:w=${L.W}:h=${line}:color=0x1a1e27@0.9:t=fill`);
    steps.push(`null[tk0]`);
    // Progress line: a light strip sliding in from the left over one cycle.
    // Discreet: it is always moving, so a mid grey instead of near-white.
    extra.push(`color=c=0x5d626d:s=${L.W}x${line}:r=${fps}[tkline]`);
    extra.push(`[tk0][tkline]overlay=x='-w+w*${p}/${C}':y=${top - line}:eval=frame:shortest=1[tk1]`);
    const draw = (font: string, file: string, size: number, color: string, x: string, y: number, delay: number, box = '') => {
      const m = motion(delay);
      return `drawtext=fontfile=${filterValue(font)}:textfile=${filterValue(file)}:reload=${reload}:expansion=none:` +
        `fontsize=${size}:fontcolor=${color}${box}:x=${x}:y='${top + y}+${m.y}':alpha='${m.alpha}'`;
    };
    const pill = `:box=1:boxcolor=${ov.accent}:boxborderw=${Math.round(L.labelSize * 0.45)}|${Math.round(L.labelSize * 0.8)}`;
    // With a logo for every block the logos replace the text label.
    const useLogos = blocks.length > 0 && blocks.every((b) => b.logo) && logoInputs.length === blocks.length;
    const label = useLogos ? 'null' : draw(ov.fontSemiBold, files.label, L.labelSize, ov.accentText,
      `${L.margin}+(${L.labelCol}-tw)/2`, Math.round((L.bar - L.labelSize) / 2), 0, pill);
    const text = draw(ov.fontSemiBold, files.text, L.textSize, 'white', String(L.textX), L.titleY, 0.04) + ',' +
      draw(ov.font, files.sub, L.subSize, '0xaab0bb', String(L.textX), L.subY, 0.12) + ',' +
      draw(ov.fontSemiBold, files.solo, L.textSize, 'white', String(L.textX), L.soloY, 0.04) + ',' +
      draw(ov.fontSemiBold, files.long1, L.longSize, 'white', String(L.textX), L.longY1, 0.04) + ',' +
      draw(ov.fontSemiBold, files.long2, L.longSize, 'white', String(L.textX), L.longY2, 0.08);
    extra.push(`[tk1]${label},${text}[tk2]`);
    if (useLogos) {
      const box = feedLogoBox(cfg);
      // Where each block airs within a round of a layout (seconds), all day or outside news hours.
      const spans = (list: TickerBlock[]) => {
        const total = list.reduce((n, b) => n + b.slots, 0) * C;
        let at = 0;
        const out = new Map<string, string>();
        for (const b of list) {
          out.set(b.key, `gte(mod(t,${total}),${at})*lt(mod(t,${total}),${at + b.slots * C})`);
          at += b.slots * C;
        }
        return out;
      };
      const all = spans(blocks);
      const w = newsWindow(cfg);
      // News hours, tested on the time of day at which the current cycle started.
      const x = `mod(${C}*floor(t/${C})+${Math.round(dayOffset)},86400)`;
      const on = w ? (w.from < w.to ? `gte(${x},${w.from})*lt(${x},${w.to})` : `(gte(${x},${w.from})+lt(${x},${w.to}))`) : '';
      const off = w ? spans(blocks.filter((b) => !b.feed)) : null;
      const enable = (b: TickerBlock) => {
        if (!on) return all.get(b.key)!;
        return b.feed ? `${on}*${all.get(b.key)}` : `${on}*${all.get(b.key)}+(1-${on})*${off!.get(b.key)}`;
      };
      // Right-aligned just before the headline.
      const lx = L.textX - Math.round(L.H * 0.022) - box.width;
      const ly = top + Math.round((L.bar - box.height) / 2);
      let cur = 'tk2';
      blocks.forEach((b, i) => {
        // Every logo is fitted into the same box (the channel logo is not prepared beforehand)
        // and toned down to light grey, so the headline stays the main thing.
        extra.push(`[${logoInputs[i]}:v]scale=${box.width}:${box.height}:force_original_aspect_ratio=decrease,format=rgba,` +
          `colorchannelmixer=rr=0.7:gg=0.71:bb=0.74,` +
          `pad=${box.width}:${box.height}:ow-iw:(oh-ih)/2:color=black@0[tklogo${i}]`);
        extra.push(`[${cur}][tklogo${i}]overlay=x=${lx}:y=${ly}:eof_action=repeat:` +
          `enable='${enable(b)}'[tkl${i}]`);
        cur = `tkl${i}`;
      });
      extra.push(`[${cur}]null[tk2l]`);
    }
    const head = steps.length > 1 ? steps.slice(0, -1).join(',') + ',' : '';
    return [`[${cur}]${head}null[tk0]`, ...extra, `[${useLogos ? 'tk2l' : 'tk2'}]null[${output}]`].join(';');
  }
  return `[${cur}]${steps.length ? steps.join(',') : 'null'}[${output}]`;
}
