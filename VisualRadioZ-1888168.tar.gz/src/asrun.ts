import fs from 'node:fs';
import path from 'node:path';
import { type Config, resolvePath } from './config.ts';
import type { Clip } from './library.ts';

const HEADER = 'inizio;fine;durata_s;tipo;artista;titolo;file;esito\n';

const csv = (s: string) => (/[;"\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s);

function localIso(d: Date): string {
  const off = d.getTimezoneOffset() * 60000;
  return new Date(d.getTime() - off).toISOString().slice(0, 19).replace('T', ' ');
}

/** One CSV per day of what actually went to air (start, end, played seconds). */
export class AsRunLog {
  private dir: string;

  constructor(cfg: Config) {
    this.dir = path.join(resolvePath(cfg.dataDir), 'asrun');
    fs.mkdirSync(this.dir, { recursive: true });
  }

  fileFor(day: string): string {
    return path.join(this.dir, `asrun-${day}.csv`);
  }

  write(clip: Clip, startedAt: number, endedAt: number, outcome: string) {
    const start = new Date(startedAt);
    const file = this.fileFor(localIso(start).slice(0, 10));
    if (!fs.existsSync(file)) fs.writeFileSync(file, '﻿' + HEADER);
    const row = [
      localIso(start), localIso(new Date(endedAt)), ((endedAt - startedAt) / 1000).toFixed(1),
      clip.type, clip.artist, clip.title, clip.file, outcome,
    ].map((v) => csv(String(v)));
    fs.appendFileSync(file, row.join(';') + '\n');
  }

  days(): string[] {
    return fs.readdirSync(this.dir).filter((f) => f.endsWith('.csv')).map((f) => f.slice(6, 16)).sort().reverse();
  }
}
