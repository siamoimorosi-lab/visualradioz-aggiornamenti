import { Worker, isMainThread, parentPort, workerData } from 'node:worker_threads';
import { type FilterCategory, type Rule, categoryMatches, fieldsOf, parts, ruleMatches } from './filters.ts';

/**
 * What the settings page shows about the library: clips per category, the tags found in the
 * files, the clocks whose exclusions leave a slot without songs. With ten thousand clips that
 * takes seconds, so it is worked out in a thread of its own and the program on air never waits.
 */
export interface LibClip { id: string; type: string; category: string; artist: string; title: string; album: string; tagYear?: string; duration: number; file: string; tags?: Record<string, string> }
export interface LibInfoInput { clips: LibClip[]; filters: FilterCategory[]; clocks: Record<string, { slots: string[]; exclude?: Rule[]; excludeMatch?: 'any' | 'all' }> }
export interface LibInfo { categories: Record<string, number>; tagFields: { field: string; clips: number; values: string[] }[]; warnings: string[] }

const NOT_ABOUT_THE_SONG = ['file', 'title', 'duration', 'major_brand', 'minor_version', 'compatible_brands', 'encoder', 'creation_time', 'handler_name', 'vendor_id'];

export function computeLibInfo({ clips, filters, clocks }: LibInfoInput): LibInfo {
  const fields = new Map(clips.map((c) => [c.id, fieldsOf(c)]));
  const categories: Record<string, number> = {};
  for (const c of clips) {
    const k = c.type === 'music' ? c.category : c.type;
    categories[k] = (categories[k] ?? 0) + 1;
  }
  const inFilter = new Map<string, LibClip[]>();
  for (const f of filters) {
    const list = clips.filter((c) => c.type === 'music' && categoryMatches(c, f));
    inFilter.set(f.name, list);
    categories[f.name] = list.length;
  }
  // Tags found in the music clips, with how many clips have each and its most common values.
  const seen = new Map<string, { clips: number; values: Map<string, number> }>();
  for (const c of clips) {
    if (c.type !== 'music') continue;
    for (const [k, v] of fields.get(c.id)!) {
      if (NOT_ABOUT_THE_SONG.includes(k)) continue;
      const f = seen.get(k) ?? { clips: 0, values: new Map<string, number>() };
      f.clips++;
      for (const t of k === 'artist' || k === 'album' ? [v.trim()] : parts(v)) {
        if (t && t.length <= 40) f.values.set(t, (f.values.get(t) ?? 0) + 1);
      }
      seen.set(k, f);
    }
  }
  const tagFields = [...seen].map(([field, f]) => ({
    field, clips: f.clips, values: [...f.values].sort((a, b) => b[1] - a[1]).slice(0, 30).map(([v]) => v),
  })).sort((a, b) => b.clips - a.clips);
  // Clocks whose exclusions take out every song of a slot (they are then ignored on air).
  const warnings: string[] = [];
  for (const [name, clock] of Object.entries(clocks)) {
    if (!clock.exclude?.length) continue;
    const match = clock.excludeMatch === 'all' ? 'every' : 'some';
    for (const slot of new Set(clock.slots)) {
      if (slot === 'jingle') continue;
      const all = (inFilter.get(slot) ?? clips.filter((c) => c.type === slot || c.category === slot)).filter((c) => c.type === 'music');
      if (all.length && all.every((c) => clock.exclude![match]((r) => ruleMatches(fields.get(c.id)!, r)))) {
        warnings.push(`orologio "${name}": le esclusioni tolgono tutti i ${all.length} brani di "${slot}", quindi non vengono applicate`);
      }
    }
  }
  return { categories, tagFields, warnings };
}

/** The same in a worker thread; worked out here if a thread cannot be started. */
export function libInfoAsync(input: LibInfoInput): Promise<LibInfo> {
  return new Promise((resolve) => {
    try {
      const w = new Worker(new URL(import.meta.url), { workerData: input });
      w.once('message', (m: LibInfo) => resolve(m));
      w.once('error', () => resolve(computeLibInfo(input)));
    } catch {
      resolve(computeLibInfo(input));
    }
  });
}

if (!isMainThread && parentPort && workerData?.clips) parentPort.postMessage(computeLibInfo(workerData as LibInfoInput));
