import fs from 'node:fs';
import path from 'node:path';
import { Resvg } from '@resvg/resvg-js';
import { type Config, assetPath, resolvePath } from './config.ts';
import { fit } from './ticker.ts';
import { type EventProgram, dayName } from './events.ts';

/**
 * Info cards shown over clips (top left, under the clock): weather for the
 * south of the Alps from MeteoSwiss and traffic in Ticino (queues, accidents,
 * closures — no roadworks) from the TCS/Viasuisse traffic service.
 *
 * Each card is drawn as SVG and rendered to a transparent PNG when a clip is
 * planned; the clip's decoder overlays it, so a card never changes while on air.
 */

interface Forecast {
  date: string;
  icon: number;
  max: number;
  min: number;
}

interface Place {
  name: string;
  now: { icon: number; temp: number } | null;
  days: Forecast[];
}

export interface TrafficEvent {
  cat: number;
  road: string;
  text: string;
  updated: string;
}

export type Kind = 'weatherToday' | 'traffic' | 'weatherWeek' | 'headliner';

/**
 * A card: one PNG per page (shown one after the other) and, when it has more
 * than one page, where the page bar is (panel pixels): segment i fills up
 * while page i is on screen.
 */
export interface Card {
  files: string[];
  kind: Kind;
  progress?: { y: number; h: number; segments: { x: number; w: number }[] };
}

const UA = { 'user-agent': 'Mozilla/5.0 (WebTV Playout)' };
const DAYS = ['DOM', 'LUN', 'MAR', 'MER', 'GIO', 'VEN', 'SAB'];
/** Viasuisse categories: 12 queue/slow traffic, 13 accident, 21 closure/hazard, 90 danger. 11 = roadworks, left out. */
const TRAFFIC_LABEL: Record<number, string> = { 13: 'INCIDENTE', 12: 'CODA', 90: 'PERICOLO', 21: 'CHIUSURA' };
const TRAFFIC_ORDER = [13, 12, 90, 21];
/** The source mangles some accented letters; fix the names that matter around Ticino. */
const MANGLED: [RegExp, string][] = [
  [/Z�rich/g, 'Zürich'], [/G�schenen/g, 'Göschenen'], [/Gr�nenwald/g, 'Grünenwald'],
  [/�/g, ''],
];

/** Split into at most `lines` lines of `max` characters, the last one shortened with "…". */
function wrap(text: string, max: number, lines: number): string[] {
  const out: string[] = [];
  let rest = text;
  while (rest && out.length < lines - 1) {
    if (rest.length <= max) break;
    const cut = rest.lastIndexOf(' ', max);
    const at = cut > max * 0.5 ? cut : max;
    out.push(rest.slice(0, at).trim());
    rest = rest.slice(at).trim();
  }
  if (rest) out.push(fit(rest, max));
  return out;
}

const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const fixText = (s: string) => MANGLED.reduce((acc, [re, to]) => acc.replace(re, to), s).replace(/\s+/g, ' ').trim();

export class InfoCards {
  private cfg: Config;
  private dir: string;
  private iconDir: string;
  places: Place[] = [];
  traffic: TrafficEvent[] = [];
  weatherAt = 0;
  trafficAt = 0;
  lastError = '';
  /** When each kind of card last went to air; weather alternates today / next days. */
  private shownAt: Record<'weather' | 'traffic' | 'headliner', number> = { weather: 0, traffic: 0, headliner: 0 };
  private program: EventProgram | null = null;

  /** The event programme, for the card with the coming main acts. */
  setEvents(program: EventProgram) {
    this.program = program;
  }
  private weatherWeekNext = false;
  private serial = 0;
  private timers: NodeJS.Timeout[] = [];

  constructor(cfg: Config) {
    this.cfg = cfg;
    this.dir = path.join(resolvePath(cfg.dataDir), 'cards');
    this.iconDir = path.join(resolvePath(cfg.dataDir), 'icons');
    fs.mkdirSync(this.dir, { recursive: true });
    fs.mkdirSync(this.iconDir, { recursive: true });
  }

  start() {
    const c = this.cfg.cards;
    if (!c.enabled) return; // only the event card: nothing to fetch here
    const weather = () => this.refreshWeather().catch((e) => (this.lastError = `meteo: ${e.message ?? e}`));
    const traffic = () => this.refreshTraffic().catch((e) => (this.lastError = `traffico: ${e.message ?? e}`));
    weather();
    traffic();
    this.timers.push(setInterval(weather, c.weather.refreshMinutes * 60000));
    this.timers.push(setInterval(traffic, c.traffic.refreshMinutes * 60000));
  }

  stop() {
    for (const t of this.timers) clearInterval(t);
  }

  // ------------------------------------------------------------------ data

  async refreshWeather() {
    const places: Place[] = [];
    for (const loc of this.cfg.cards.weather.locations) {
      const res = await fetch(`https://app-prod-ws.meteoswiss-app.ch/v1/plzDetail?plz=${loc.plz}`, { headers: UA, signal: AbortSignal.timeout(20000) });
      if (!res.ok) throw new Error(`MeteoSvizzera HTTP ${res.status}`);
      const j: any = await res.json();
      const now = j.currentWeather?.iconV2 ? { icon: j.currentWeather.iconV2, temp: Math.round(j.currentWeather.temperature) } : null;
      const days: Forecast[] = (j.forecast ?? []).map((d: any) => ({
        date: d.dayDate, icon: d.iconDayV2 ?? d.iconDay, max: Math.round(d.temperatureMax), min: Math.round(d.temperatureMin),
      }));
      places.push({ name: loc.name, now, days });
    }
    const icons = new Set(places.flatMap((p) => [...(p.now ? [p.now.icon] : []), ...p.days.map((d) => d.icon)]));
    for (const n of icons) await this.icon(n);
    this.places = places;
    this.weatherAt = Date.now();
  }

  async refreshTraffic() {
    const t = this.cfg.cards.traffic;
    const url = `https://trafficmaptcs.trafficintelligence.ch/api/event/GetEventsTrafficApi/45.1996,5.8559,48.3546,12.0009/${t.categories.join(',')}/3/5/2`;
    const res = await fetch(url, { headers: { ...UA, referer: 'https://trafficmaptcs.trafficintelligence.ch/3' }, signal: AbortSignal.timeout(20000) });
    if (!res.ok) throw new Error(`traffico HTTP ${res.status}`);
    const j: any = await res.json();
    const [s, w, n, e] = t.area;
    const events: TrafficEvent[] = [];
    for (const ev of j.Entity ?? []) {
      const { Lat: lat, Lng: lng } = ev.Pos ?? {};
      if (!(lat >= s && lat <= n && lng >= w && lng <= e) || !t.categories.includes(ev.Cat)) continue;
      const name = fixText(String(ev.Name ?? ''));
      const desc = fixText(String(ev.Dic?.Description ?? ''));
      const roadNo = fixText(String(ev.Dic?.RoadNo ?? ''));
      // Motorway events: Name = "A2 - S. Gottardo direzione Chiasso", Description = what happens where.
      // Others carry a whole sentence in Name, starting with the road.
      const sentence = name.length > 50 || !desc;
      const road = sentence ? roadNo || name.split(' - ')[0] : name;
      const rest = name.startsWith(roadNo) ? name.slice(roadNo.length).replace(/^\s*-\s*/, '') : name;
      // Descriptions are sometimes left in German: the Italian sentence in Name is better then.
      const german = /(Uhr|gesperrt|zwischen|Richtung)/.test(desc);
      const text = sentence ? rest : !german ? desc : rest;
      // "A2 - S. Gottardo direzione Chiasso" → "A2 direzione Chiasso": the direction is what matters on screen.
      const short = road.replace(/^([A-Z]\d+[A-Z]?) - .*?(direzione .+)$/, '$1 $2').replace(/ - /, ' · ');
      events.push({ cat: ev.Cat, road: short, text, updated: String(ev.Dic?.LastUpdated ?? '') });
    }
    events.sort((a, b) => TRAFFIC_ORDER.indexOf(a.cat) - TRAFFIC_ORDER.indexOf(b.cat));
    this.traffic = events;
    this.trafficAt = Date.now();
  }

  private async icon(n: number): Promise<string | null> {
    const f = path.join(this.iconDir, `${n}.svg`);
    if (!fs.existsSync(f)) {
      const res = await fetch(`https://www.meteosvizzera.admin.ch/static/resources/weather-symbols/${n}.svg`, { headers: UA, signal: AbortSignal.timeout(20000) });
      if (!res.ok) return null;
      fs.writeFileSync(f, Buffer.from(await res.arrayBuffer()));
    }
    return f;
  }

  private iconData(n: number): string | null {
    const f = path.join(this.iconDir, `${n}.svg`);
    return fs.existsSync(f) ? `data:image/svg+xml;base64,${fs.readFileSync(f).toString('base64')}` : null;
  }

  // -------------------------------------------------------------- drawing

  /**
   * The card due now (or the kind asked for) rendered for a panel of the given
   * size, or null when none is due or there is nothing to show. Weather and
   * traffic each come back every `everyMinutes`; the one waiting longest goes first.
   */
  next(width: number, height: number, only?: Kind): Card | null {
    const now = Date.now();
    const c = this.cfg.cards;
    const ev = this.cfg.events;
    const every = { weather: c.weather.everyMinutes, traffic: c.traffic.everyMinutes, headliner: ev.cardEveryMinutes };
    // Weather and traffic when the cards are on; the main acts when the channel has a programme.
    const groups = [
      ...(c.enabled ? (['weather', 'traffic'] as const) : []),
      ...(this.program?.enabled && ev.card ? (['headliner'] as const) : []),
    ];
    const wait = (k: (typeof groups)[number]) => now - this.shownAt[k] - every[k] * 60_000;
    const due = only
      ? [only]
      : groups
          .filter((k) => wait(k) >= 0)
          .sort((x, y) => wait(y) - wait(x))
          .map((k): Kind => (k === 'weather' ? (this.weatherWeekNext ? 'weatherWeek' : 'weatherToday') : k));
    for (const kind of due) {
      const card = this.pages(kind, width, height);
      if (!card?.pages.length) continue;
      const group = kind === 'traffic' || kind === 'headliner' ? kind : 'weather';
      this.shownAt[group] = now;
      if (group === 'weather') this.weatherWeekNext = kind === 'weatherToday';
      const files = card.pages.map((svg) => {
        const file = path.join(this.dir, `card-${this.serial++ % 16}.png`);
        fs.writeFileSync(file, new Resvg(svg, {
          font: {
            fontFiles: ['Medium', 'SemiBold', 'Bold'].map((w) => assetPath(`assets/fonts/Poppins-${w}.ttf`)),
            loadSystemFonts: false,
            defaultFontFamily: 'Poppins',
          },
        }).render().asPng());
        return file;
      });
      return { files, kind, progress: card.progress };
    }
    return null;
  }

  private pages(kind: Kind, width: number, height: number): { pages: string[]; progress?: Card['progress'] } | null {
    const k = this.cfg.output.height / 1080;
    const z = (n: number) => Math.round(n * k);
    if (kind === 'traffic') return this.trafficPages(z, width, height);
    if (kind === 'headliner') return this.headlinerPages(z, width, height);
    if (!this.places.length || Date.now() - this.weatherAt > 6 * 3600_000) return null;
    return this.weatherPages(z, width, height, kind === 'weatherWeek');
  }

  /**
   * Page bar: one segment per page, those already shown white, the others
   * grey; the engine fills the current one as its page goes by. With `labels`
   * (weather places) each segment carries its name above it, the current one white.
   */
  private pageBar(z: (n: number) => number, width: number, y: number, count: number, current: number, labels?: string[]) {
    const gap = z(10);
    const x0 = z(32);
    const segW = (width - 2 * x0 - gap * (count - 1)) / count;
    const h = Math.max(3, z(4));
    const barY = labels ? y + z(34) : y;
    const segments = Array.from({ length: count }, (_, i) => ({ x: Math.round(x0 + i * (segW + gap)), w: Math.round(segW) }));
    const svg = segments.map((sg, i) => [
      `<rect x="${sg.x}" y="${barY}" width="${sg.w}" height="${h}" rx="${h / 2}" fill="${i < current ? '#ffffff' : '#343a47'}"/>`,
      labels
        ? `<text x="${sg.x}" y="${y + z(22)}" font-family="Poppins" font-weight="600" font-size="${z(20)}" fill="${i === current ? '#ffffff' : '#7d8390'}">${esc(labels[i])}</text>`
        : '',
    ].join('')).join('\n');
    return { svg, progress: { y: barY, h, segments } };
  }

  /** Side panel frame: rounded dark panel, white top line, kicker pill and subtitle. Content starts at z(132). */
  private frame(z: (n: number) => number, width: number, height: number, kicker: string, subtitle: string, body: string, page = '') {
    const pillW = z(22 + kicker.length * 14);
    const pageTag = page
      ? `<text x="${width - z(32)}" y="${z(58)}" text-anchor="end" font-family="Poppins" font-weight="600" font-size="${z(19)}" fill="#9aa0ab">${page}</text>`
      : '';
    return `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">
  <defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#161b27"/><stop offset="1" stop-color="#0b0e17"/></linearGradient></defs>
  <rect x="0" y="0" width="${width}" height="${height}" rx="${z(20)}" fill="url(#g)" fill-opacity="0.94"/>
  <rect x="${z(32)}" y="0" width="${z(64)}" height="${z(4)}" fill="#ffffff"/>
  <rect x="${z(32)}" y="${z(34)}" width="${pillW}" height="${z(34)}" rx="${z(5)}" fill="#ffffff"/>
  <text x="${z(32) + pillW / 2}" y="${z(58)}" text-anchor="middle" font-family="Poppins" font-weight="600" font-size="${z(19)}" fill="#0b0e17">${esc(kicker)}</text>
  <text x="${z(32)}" y="${z(104)}" font-family="Poppins" font-weight="600" font-size="${z(25)}" fill="#ffffff">${esc(subtitle)}</text>
  ${pageTag}
${body}
</svg>`;
  }

  /**
   * One page per coming main act: its picture, name, day and time, and where.
   * The pictures come from the programme page and change as the acts go by.
   */
  private headlinerPages(z: (n: number) => number, width: number, height: number): { pages: string[]; progress?: Card['progress'] } | null {
    const acts = this.program?.picturesReady ? this.program.headliners(new Date()) : [];
    if (!acts.length) return null;
    const now = new Date();
    const x = z(32);
    const w = width - 2 * x;
    let progress: Card['progress'];
    const pages = acts.map((e, i) => {
      const bar = this.pageBar(z, width, z(126), acts.length, i);
      progress = bar.progress;
      const top = z(150);
      const file = this.program!.pictureOf(e);
      // Pictures are 3:2; without one the text moves up.
      const ih = file ? Math.round((w * 2) / 3) : 0;
      const img = file
        ? `<clipPath id="hc"><rect x="${x}" y="${top}" width="${w}" height="${ih}" rx="${z(12)}"/></clipPath>` +
          `<image href="data:image/png;base64,${fs.readFileSync(file).toString('base64')}" x="${x}" y="${top}" width="${w}" height="${ih}" ` +
          `preserveAspectRatio="xMidYMid slice" clip-path="url(#hc)"/>`
        : '';
      const size = z(40);
      const lines = wrap(e.title, Math.max(8, Math.floor(w / (size * 0.6))), 2);
      let y = top + ih + (file ? z(26) : 0) + size;
      const name = lines.map((l, li) =>
        `<text x="${x}" y="${y + li * Math.round(size * 1.15)}" font-family="Poppins" font-weight="700" font-size="${size}" fill="#ffffff">${esc(l)}</text>`).join('');
      y += (lines.length - 1) * Math.round(size * 1.15) + z(46);
      const when = `${dayName(e.date, now)}${e.time ? ` · ${e.time}` : ''}`;
      const where = [e.town, e.place].filter(Boolean).join(' · ');
      const body = [
        acts.length > 1 ? bar.svg : '', img, name,
        `<text x="${x}" y="${y}" font-family="Poppins" font-weight="600" font-size="${z(28)}" fill="#ffffff">${esc(when)}</text>`,
        `<text x="${x}" y="${y + z(36)}" font-family="Poppins" font-weight="500" font-size="${z(22)}" fill="#aab0bb">${esc(fit(where, Math.floor(w / (z(22) * 0.55))))}</text>`,
      ].join('\n');
      return this.frame(z, width, height, this.cfg.events.label.toUpperCase(), 'Prossimi headliner', body);
    });
    return { pages, progress: acts.length > 1 ? progress : undefined };
  }

  private iconTag(n: number, x: number, y: number, size: number): string {
    const d = this.iconData(n);
    return d ? `<image href="${d}" x="${x}" y="${y}" width="${size}" height="${size}"/>` : '';
  }

  private divider(z: (n: number) => number, width: number, y: number) {
    return `<rect x="${z(32)}" y="${y}" width="${width - z(64)}" height="${Math.max(1, z(1))}" fill="#2a2f3a"/>`;
  }

  /**
   * One page per place, with the places as tabs over a page bar. Today: the
   * sky and temperature now, max/min and the next three days; next days: one
   * row per day.
   */
  private weatherPages(z: (n: number) => number, width: number, height: number, week: boolean) {
    const places = this.places.slice(0, 4);
    const names = places.map((p) => p.name);
    let progress: Card['progress'];
    const pages = places.map((p, pi) => {
      const bar = this.pageBar(z, width, z(126), places.length, pi, names);
      progress = bar.progress;
      const top = z(190);
      const body = week ? this.weekBody(z, width, height, p, top) : this.todayBody(z, width, height, p, top);
      return this.frame(z, width, height, 'METEO', week ? 'Sud delle Alpi · prossimi giorni' : 'Sud delle Alpi · oggi', bar.svg + '\n' + body);
    });
    return { pages, progress: places.length > 1 ? progress : undefined };
  }

  private todayBody(z: (n: number) => number, width: number, height: number, p: Place, top: number) {
    const today = p.days[0];
    const icon = p.now?.icon ?? today?.icon;
    const iconSize = z(170);
    const out = [
      icon ? this.iconTag(icon, z(18), top, iconSize) : '',
      p.now ? `<text x="${width - z(32)}" y="${top + z(118)}" text-anchor="end" font-family="Poppins" font-weight="700" font-size="${z(104)}" fill="#ffffff">${p.now.temp}°</text>` : '',
      `<text x="${z(32)}" y="${top + iconSize + z(44)}" font-family="Poppins" font-weight="600" font-size="${z(38)}" fill="#ffffff">${esc(p.name)}</text>`,
      today ? `<text x="${z(32)}" y="${top + iconSize + z(84)}" font-family="Poppins" font-weight="500" font-size="${z(22)}" fill="#9aa0ab">max<tspan dx="${z(6)}" fill="#ffffff" font-weight="600">${today.max}°</tspan><tspan dx="${z(18)}">min</tspan><tspan dx="${z(6)}" fill="#ffffff" font-weight="600">${today.min}°</tspan></text>` : '',
    ];
    // The next three days side by side at the bottom.
    const days = p.days.slice(1, 4);
    // At the bottom of the panel, below the place and its max/min.
    const rowTop = Math.max(top + iconSize + z(118), height - z(176));
    if (days.length && rowTop + z(150) <= height) {
      out.push(this.divider(z, width, rowTop));
      const colW = (width - z(64)) / days.length;
      days.forEach((d, i) => {
        const cx = z(32) + colW * i + colW / 2;
        const dt = new Date(`${d.date}T12:00:00`);
        const s = z(64);
        out.push(
          `<text x="${cx}" y="${rowTop + z(40)}" text-anchor="middle" font-family="Poppins" font-weight="600" font-size="${z(19)}" fill="#9aa0ab">${DAYS[dt.getDay()]}</text>`,
          this.iconTag(d.icon, cx - s / 2, rowTop + z(50), s),
          `<text x="${cx}" y="${rowTop + z(146)}" text-anchor="middle" font-family="Poppins" font-weight="700" font-size="${z(22)}" fill="#ffffff">${d.max}°<tspan dx="${z(6)}" font-weight="500" fill="#9aa0ab">${d.min}°</tspan></text>`,
        );
      });
    }
    return out.join('\n');
  }

  private weekBody(z: (n: number) => number, width: number, height: number, p: Place, top: number) {
    const days = p.days.slice(1, 6);
    const rowH = (height - top - z(16)) / days.length;
    return days.map((d, i) => {
      const y = top + i * rowH;
      const dt = new Date(`${d.date}T12:00:00`);
      const iconSize = Math.min(z(72), rowH * 0.86);
      const mid = y + rowH / 2;
      return [
        i ? this.divider(z, width, y) : '',
        `<text x="${z(32)}" y="${mid + z(9)}" font-family="Poppins" font-weight="600" font-size="${z(25)}" fill="#ffffff">${DAYS[dt.getDay()]}<tspan dx="${z(8)}" font-weight="500" fill="#9aa0ab">${dt.getDate()}</tspan></text>`,
        this.iconTag(d.icon, width / 2 - iconSize / 2 - z(10), mid - iconSize / 2, iconSize),
        `<text x="${width - z(32)}" y="${mid + z(10)}" text-anchor="end" font-family="Poppins" font-weight="700" font-size="${z(30)}" fill="#ffffff">${d.max}°<tspan dx="${z(10)}" font-weight="500" font-size="${z(24)}" fill="#9aa0ab">${d.min}°</tspan></text>`,
      ].join('\n');
    }).join('\n');
  }

  /** Small pictograms in the channel's black-and-white style. */
  private trafficIcon(cat: number, x: number, y: number, s: number): string {
    const stroke = `stroke="#0b0e17" stroke-width="${Math.max(2, s * 0.08)}" stroke-linecap="round" stroke-linejoin="round" fill="none"`;
    const bg = `<rect x="${x}" y="${y}" width="${s}" height="${s}" rx="${s * 0.22}" fill="#ffffff"/>`;
    const cx = x + s / 2, cy = y + s / 2;
    if (cat === 12) {
      return bg + [0, 1, 2].map((i) => `<rect x="${x + s * 0.16 + i * s * 0.24}" y="${cy - s * 0.09}" width="${s * 0.18}" height="${s * 0.18}" rx="${s * 0.04}" fill="#0b0e17"/>`).join('');
    }
    if (cat === 21) {
      return bg + `<circle cx="${cx}" cy="${cy}" r="${s * 0.3}" ${stroke}/><line x1="${cx - s * 0.17}" y1="${cy}" x2="${cx + s * 0.17}" y2="${cy}" ${stroke}/>`;
    }
    return bg + `<path d="M${cx} ${y + s * 0.2} L${x + s * 0.8} ${y + s * 0.78} L${x + s * 0.2} ${y + s * 0.78} Z" ${stroke}/>` +
      `<line x1="${cx}" y1="${y + s * 0.42}" x2="${cx}" y2="${y + s * 0.6}" ${stroke}/><circle cx="${cx}" cy="${y + s * 0.69}" r="${s * 0.025}" fill="#0b0e17"/>`;
  }

  /**
   * Every event in full — road and description wrapped, nothing cut — in a
   * compact layout (small pictogram with its label under it, road and text
   * beside), spread over as few pages as possible, with a page bar.
   */
  private trafficPages(z: (n: number) => number, width: number, height: number): { pages: string[]; progress?: Card['progress'] } | null {
    if (!this.trafficAt || Date.now() - this.trafficAt > 30 * 60000) return null;
    const bottom = height - z(20);
    const icon = z(38);
    const tx = z(32) + icon + z(16);
    const textW = width - tx - z(28);
    const roadSize = z(20), textSize = z(17);
    const roadLine = z(25), textLine = z(22);
    if (!this.traffic.length) {
      const y = z(132) + z(80);
      return { pages: [this.frame(z, width, height, 'TRAFFICO', 'Ticino e Moesano', [
        `<circle cx="${width / 2}" cy="${y}" r="${z(42)}" fill="#ffffff"/>`,
        `<path d="M${width / 2 - z(18)} ${y} L${width / 2 - z(4)} ${y + z(15)} L${width / 2 + z(20)} ${y - z(14)}" stroke="#0b0e17" stroke-width="${z(7)}" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`,
        `<text x="${width / 2}" y="${y + z(92)}" text-anchor="middle" font-family="Poppins" font-weight="600" font-size="${z(26)}" fill="#ffffff">Nessuna coda o incidente</text>`,
        `<text x="${width / 2}" y="${y + z(126)}" text-anchor="middle" font-family="Poppins" font-weight="500" font-size="${z(20)}" fill="#9aa0ab">Traffico regolare a sud delle Alpi</text>`,
      ].join('\n'))] };
    }
    const blocks = this.traffic.map((ev) => {
      const road = wrap(ev.road, Math.floor(textW / (roadSize * 0.56)), 2);
      const text = wrap(ev.text, Math.floor(textW / (textSize * 0.52)), 8);
      const h = Math.max(z(16) + road.length * roadLine + text.length * textLine + z(14), icon + z(46));
      return { ev, road, text, h };
    });
    // Pages are filled top to bottom; with more than one page the bar takes the first rows.
    const paginate = (top: number) => {
      const pages: (typeof blocks)[] = [[]];
      let used = 0;
      for (const b of blocks) {
        if (used + b.h > bottom - top && pages[pages.length - 1].length) {
          pages.push([]);
          used = 0;
        }
        pages[pages.length - 1].push(b);
        used += b.h;
      }
      return pages;
    };
    let top = z(126);
    let pages = paginate(top);
    if (pages.length > 1) pages = paginate((top = z(148)));
    let progress: Card['progress'];
    const svgs = pages.map((page, pi) => {
      let y = top;
      const body: string[] = [];
      if (pages.length > 1) {
        const bar = this.pageBar(z, width, z(124), pages.length, pi);
        progress = bar.progress;
        body.push(bar.svg);
      }
      page.forEach((b, i) => {
        if (i) body.push(this.divider(z, width, y));
        body.push(
          this.trafficIcon(b.ev.cat, z(32), y + z(14), icon),
          `<text x="${z(32) + icon / 2}" y="${y + z(14) + icon + z(18)}" text-anchor="middle" font-family="Poppins" font-weight="600" font-size="${z(11)}" fill="#9aa0ab">${TRAFFIC_LABEL[b.ev.cat] ?? ''}</text>`,
          ...b.road.map((l, j) => `<text x="${tx}" y="${y + z(34) + j * roadLine}" font-family="Poppins" font-weight="600" font-size="${roadSize}" fill="#ffffff">${esc(l)}</text>`),
          ...b.text.map((l, j) => `<text x="${tx}" y="${y + z(34) + b.road.length * roadLine + j * textLine}" font-family="Poppins" font-weight="500" font-size="${textSize}" fill="#c9cdd4">${esc(l)}</text>`),
        );
        y += b.h;
      });
      return this.frame(z, width, height, 'TRAFFICO', 'Ticino e Moesano', body.join('\n'));
    });
    return { pages: svgs, progress };
  }

  status() {
    return {
      weatherAt: this.weatherAt,
      trafficAt: this.trafficAt,
      places: this.places.map((p) => p.name),
      traffic: this.traffic.length,
      error: this.lastError,
    };
  }
}
