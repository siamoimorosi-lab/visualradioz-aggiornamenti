import type { Config } from './config.ts';
import { sec } from './ffmpeg.ts';

/**
 * Stingers: short logo transitions between clips, instead of a plain
 * dissolve. Each style pairs an xfade transition with a logo animation;
 * the logo keeps a fixed size and moves only by position and opacity.
 */
export type StingerStyle = 'pop' | 'swipe' | 'flash' | 'slice' | 'circle' | 'band';

interface StyleDef {
  /** xfade transition and its length. */
  transition: string;
  video: number;
  /** How long the logo is on screen, starting `lead` seconds before the cut. */
  logo: number;
  lead: number;
  motion: 'still' | 'cross' | 'band';
}

const STYLES: Record<StingerStyle, StyleDef> = {
  pop: { transition: 'fade', video: 0.15, logo: 0.8, lead: 0.2, motion: 'still' },
  swipe: { transition: 'smoothleft', video: 0.6, logo: 0.9, lead: 0.15, motion: 'cross' },
  flash: { transition: 'fadewhite', video: 0.35, logo: 0.7, lead: 0.05, motion: 'still' },
  slice: { transition: 'hlslice', video: 0.5, logo: 0.8, lead: 0.15, motion: 'still' },
  circle: { transition: 'circleopen', video: 0.7, logo: 0.9, lead: 0.1, motion: 'still' },
  band: { transition: 'wipeleft', video: 0.6, logo: 0.9, lead: 0.15, motion: 'band' },
};

export const STINGER_STYLES = Object.keys(STYLES) as StingerStyle[];

export function stingerVideoDuration(style: StingerStyle): number {
  return STYLES[style].video;
}

/** Extra ffmpeg input for the logo (a short looped still). */
export function stingerInput(cfg: Config, style: StingerStyle, logo: string): string[] {
  const s = STYLES[style];
  return ['-loop', '1', '-framerate', String(cfg.output.fps), '-t', sec(s.logo), '-i', logo];
}

/**
 * Filters for the video transition at `cut` (seconds into the segment) from
 * `[a]` to `[b]`, with the logo from input `logoInput`, into `[out]`.
 */
export function stingerGraph(cfg: Config, style: StingerStyle, cut: number, logoInput: number, a: string, b: string, out: string): string {
  const { width: W, height: H, fps } = cfg.output;
  const s = STYLES[style];
  // The logo fills `logoWidth` of the frame's width, and never more than 70% of its height.
  const lw = Math.round((W * Math.min(0.9, Math.max(0.05, cfg.overlay.stinger.logoWidth))) / 2) * 2;
  const lhMax = Math.round((H * 0.7) / 2) * 2;
  const lh = Math.min(lhMax, lw * (cfg.overlay.logo.ratio ?? 0.42));
  const t0 = Math.max(0, cut - s.lead);
  const T = s.logo;
  const fadeIn = Math.min(0.15, T / 4);
  const fadeOut = Math.min(0.25, T / 3);
  const parts = [
    `[${a}][${b}]xfade=transition=${s.transition}:duration=${sec(s.video)}:offset=${sec(cut)}[stx]`,
    `[${logoInput}:v]scale=${lw}:${lhMax}:force_original_aspect_ratio=decrease,format=rgba,` +
      `fade=t=in:st=0:d=${sec(fadeIn)}:alpha=1,fade=t=out:st=${sec(T - fadeOut)}:d=${sec(fadeOut)}:alpha=1,` +
      `setpts=PTS+${sec(t0)}/TB[stl]`,
  ];
  // Progress of the logo window, 0..1, in the main stream's time.
  const prog = `clip((t-${sec(t0)})/${sec(T)},0,1)`;
  if (s.motion === 'still') {
    parts.push(`[stx][stl]overlay=x=(W-w)/2:y=(H-h)/2:eof_action=pass[${out}]`);
  } else if (s.motion === 'cross') {
    parts.push(`[stx][stl]overlay=x='W-(W+w)*${prog}':y=(H-h)/2:eval=frame:eof_action=pass[${out}]`);
  } else {
    // A band in the brand colour sweeps across, carrying the logo.
    const bh = Math.round(Math.max(H * 0.2, lh * 1.3) / 2) * 2;
    parts.push(
      `color=c=${cfg.overlay.accent}:s=${W}x${bh}:r=${fps}:d=${sec(T)},format=rgba,` +
        `fade=t=in:st=0:d=${sec(fadeIn)}:alpha=1,fade=t=out:st=${sec(T - fadeOut)}:d=${sec(fadeOut)}:alpha=1,` +
        `setpts=PTS+${sec(t0)}/TB[stb]`,
      `[stx][stb]overlay=x='-W+2*W*${prog}':y=(H-h)/2:eval=frame:eof_action=pass[stxb]`,
      `[stxb][stl]overlay=x='-W+2*W*${prog}+(W-w)/2':y=(H-h)/2:eval=frame:eof_action=pass[${out}]`,
    );
  }
  return parts.join(';');
}
