import fs from 'node:fs';
import path from 'node:path';
import { type Config, resolvePath } from './config.ts';
import { blockAt, blocksAt, tickerBlocks, tickerFiles, tickerLayout, writeAtomic } from './graphics.ts';
import { fitWidth, textWidth, twoLines } from './textfit.ts';

export interface FeedState {
  label: string;
  url: string;
  items: NewsItem[];
  updatedAt: number;
  error: string;
}

const ENTITIES: Record<string, string> = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ' };

function decode(s: string): string {
  return s
    .replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCodePoint(parseInt(h, 16)))
    .replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(Number(d)))
    .replace(/&(\w+);/g, (m, n) => ENTITIES[n.toLowerCase()] ?? m);
}

/** Plain one-line text the ticker font can draw: no tags, emoji or control characters. */
export function clean(s: string): string {
  // Decoded twice: feeds often escape HTML that itself contains entities (&amp;nbsp;).
  return decode(decode(s.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')).replace(/<[^>]+>/g, ' '))
    .replace(/<[^>]+>/g, '')
    .replace(/[\u{1F000}-\u{1FFFF}\u{2600}-\u{27BF}️‍]/gu, '')
    .replace(/[\u0000-\u001f\u007f]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

export interface NewsItem {
  title: string;
  /** Summary from the feed, or the publication time when there is none. */
  sub: string;
}

/** Headlines (title and summary) of an RSS or Atom document, in feed order. */
export function parseFeed(xml: string): NewsItem[] {
  const out: NewsItem[] = [];
  for (const m of xml.matchAll(/<(item|entry)\b[\s\S]*?<\/\1>/g)) {
    const raw = m[0].match(/<title[^>]*>([\s\S]*?)<\/title>/)?.[1];
    if (!raw) continue;
    let title = clean(raw);
    // Aggregators (Google News) append " - Source" to every title.
    const source = m[0].match(/<source[^>]*>([\s\S]*?)<\/source>/)?.[1];
    if (source) {
      const suffix = ` - ${clean(source)}`;
      if (title.endsWith(suffix)) title = title.slice(0, -suffix.length);
    }
    if (!title) continue;
    const desc = m[0].match(/<(description|summary|content:encoded|content)[^>]*>([\s\S]*?)<\/\1>/)?.[2];
    let sub = desc ? clean(desc) : '';
    // Some aggregators repeat the title (plus the source) as the summary: then there is no
    // second line (just the time of the update says nothing to the viewer).
    if (sub.toLowerCase().startsWith(title.toLowerCase())) sub = '';
    out.push({ title, sub });
  }
  return out;
}

/** Shorten to `max` characters at a word boundary. */
export function fit(text: string, max: number): string {
  if (text.length <= max) return text;
  const cut = text.slice(0, max - 1);
  const space = cut.lastIndexOf(' ');
  return (space > max * 0.6 ? cut.slice(0, space) : cut).replace(/[\s,.;:–-]+$/, '') + '…';
}

export interface TickerItem {
  label: string;
  text: string;
  sub: string;
}

/**
 * One headline at a time: the text typed in the panel, then the latest
 * headlines of each feed in the configured order, round and round. The next
 * item is written mid-cycle, so drawtext picks it up exactly when the next
 * cycle (and its animation) starts.
 */
export class Ticker {
  private cfg: Config;
  private manualFile: string;
  manual: string;
  feeds: FeedState[];
  private timers: NodeJS.Timeout[] = [];
  private position = 0;
  private preparedFor = -1;
  current: TickerItem | null = null;
  /** Seconds on the encoder's output timeline (same `t` the filters see). */
  private clock: () => number = () => 0;
  /** What is on air and next, for the channel's own slot when no text is typed. */
  private nowPlaying: () => { now: string; next: string } | null = () => null;
  private feedPos = new Map<string, number>();

  /** Lines of the event programme (today and tomorrow), when the channel has one. */
  private events: () => { text: string; sub: string }[] = () => [];

  private eventsStatus: () => unknown = () => null;

  setEvents(fn: () => { text: string; sub: string }[], status: () => unknown) {
    this.events = fn;
    this.eventsStatus = status;
  }

  setNowPlaying(fn: () => { now: string; next: string } | null) {
    this.nowPlaying = fn;
  }

  constructor(cfg: Config) {
    this.cfg = cfg;
    this.manualFile = path.join(resolvePath(cfg.dataDir), 'ticker-manual.txt');
    this.manual = fs.existsSync(this.manualFile) ? fs.readFileSync(this.manualFile, 'utf8') : cfg.overlay.ticker.text;
    this.feeds = cfg.overlay.ticker.feeds.map((f) => ({ label: f.label, url: f.url, items: [], updatedAt: 0, error: '' }));
  }

  setClock(fn: () => number) {
    this.clock = fn;
  }

  /** Time of day (seconds) at the encoder's t = 0, for the news hours. */
  private dayOffset: () => number = () => 0;

  setDayOffset(fn: () => number) {
    this.dayOffset = fn;
  }

  start() {
    this.writeFor(0);
    this.timers.push(setInterval(() => this.tick(), 250));
    if (!this.feeds.length) return;
    const refresh = () => this.refresh().catch((e) => console.error('ticker:', e));
    refresh();
    this.timers.push(setInterval(refresh, this.cfg.overlay.ticker.refreshMinutes * 60000));
  }

  stop() {
    for (const t of this.timers) clearInterval(t);
  }

  private vote: () => { text: string; sub: string } | null = () => null;
  setVote(fn: () => { text: string; sub: string } | null) {
    this.vote = fn;
  }

  setManual(text: string) {
    this.manual = clean(text);
    fs.writeFileSync(this.manualFile, this.manual);
  }

  /** Fetch all feeds; a feed that fails keeps its previous headlines. */
  async refresh() {
    await Promise.all(this.feeds.map(async (f) => {
      try {
        const res = await fetch(f.url, {
          headers: { 'user-agent': 'Mozilla/5.0 (WebTV Playout ticker)' },
          signal: AbortSignal.timeout(20000),
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const items = parseFeed(await res.text()).slice(0, this.cfg.overlay.ticker.itemsPerFeed);
        if (!items.length) throw new Error('nessuna notizia nel feed');
        Object.assign(f, { items, updatedAt: Date.now(), error: '' });
      } catch (e) {
        f.error = String((e as Error).message ?? e);
      }
    }));
  }

  /** All items in airing order. */
  items(): TickerItem[] {
    const out: TickerItem[] = [];
    if (this.manual.trim()) out.push({ label: this.cfg.overlay.ticker.label, text: this.manual.trim(), sub: this.cfg.channelName });
    for (const f of this.feeds) for (const n of f.items) out.push({ label: f.label, text: n.title, sub: n.sub });
    return out;
  }

  private tick() {
    const C = this.cfg.overlay.ticker.seconds;
    const t = this.clock();
    const cycle = Math.floor(t / C);
    const phase = t - cycle * C;
    // Mid-cycle, well away from the reload at the cycle boundary.
    if (cycle !== this.preparedFor && phase > 2 && phase < C - 2) {
      this.preparedFor = cycle;
      this.writeFor(cycle + 1);
    }
  }

  /** The item that airs in `cycle`, following the block layout shared with the encoder. */
  private itemFor(cycle: number): TickerItem {
    const C = this.cfg.overlay.ticker.seconds;
    const { block } = blockAt(blocksAt(this.cfg, tickerBlocks(this.cfg), this.dayOffset() + cycle * C), cycle);
    if (block.key === 'channel') {
      // While people can vote, every other channel slot invites them to.
      const v = this.vote();
      if (v && cycle % 2 === 0) return { label: 'VOTA', text: v.text, sub: v.sub };
      if (this.manual.trim()) return { label: block.label, text: this.manual.trim(), sub: this.cfg.channelName };
      const np = this.nowPlaying();
      return np
        ? { label: block.label, text: `Ora in onda: ${np.now}`, sub: np.next ? `A seguire: ${np.next}` : this.cfg.channelName }
        : { label: block.label, text: this.cfg.channelName, sub: '' };
    }
    if (block.key === 'events') {
      const lines = this.events();
      if (!lines.length) return { label: block.label, text: this.cfg.channelName, sub: 'Programma in aggiornamento' };
      const pos = this.feedPos.get('\u0000events') ?? 0;
      this.feedPos.set('\u0000events', pos + 1);
      return { label: block.label, ...lines[pos % lines.length] };
    }
    const feed = this.feeds.find((f) => f.label === block.key);
    if (!feed?.items.length) return { label: block.label, text: this.cfg.channelName, sub: 'Notizie in aggiornamento' };
    const pos = this.feedPos.get(feed.label) ?? 0;
    this.feedPos.set(feed.label, pos + 1);
    const n = feed.items[pos % feed.items.length];
    return { label: feed.label, text: n.title, sub: n.sub };
  }

  private writeFor(cycle: number) {
    const L = tickerLayout(this.cfg);
    const ov = this.cfg.overlay;
    const item = this.itemFor(cycle);
    const files = tickerFiles(this.cfg);
    writeAtomic(files.label, item.label.toUpperCase());
    // drawtext refuses an empty file: a space keeps a line blank.
    const lines = { text: ' ', sub: ' ', solo: ' ', long1: ' ', long2: ' ' };
    if (textWidth(ov.fontSemiBold, L.textSize, item.text) <= L.textWidth) {
      // The headline fits: with its summary under it, or alone in the middle.
      const sub = item.sub ? fitWidth(ov.font, L.subSize, item.sub, L.textWidth) : '';
      if (sub) Object.assign(lines, { text: item.text, sub });
      else lines.solo = item.text;
    } else {
      // Too long for one line: the whole headline over two, a little smaller; the summary goes.
      const [a, b] = twoLines(ov.fontSemiBold, L.longSize, item.text, L.textWidth);
      Object.assign(lines, { long1: a || ' ', long2: b || ' ' });
    }
    for (const [k, v] of Object.entries(lines)) writeAtomic(files[k as keyof typeof lines], v);
    this.current = item;
  }

  status() {
    return {
      manual: this.manual,
      current: this.current,
      events: this.eventsStatus(),
      feeds: this.feeds.map((f) => ({ label: f.label, items: f.items.length, updatedAt: f.updatedAt, error: f.error })),
    };
  }
}
