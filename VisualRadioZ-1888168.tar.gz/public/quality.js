// Quality page: picture enhancement and clean-up, audio processor, bitrate.
// Uses api and $ from app.js.

let q = null; // as loaded

const pct = (v) => `${v >= 1 ? '+' : ''}${Math.round((v - 1) * 100)}%`;
const fmt = {
  qContrast: pct,
  qSaturation: pct,
  qSharpness: (v) => (v > 0 ? v.toFixed(2) : 'spenta'),
  qZoom: (v) => (v > 1 ? `fino al ${Math.round((v - 1) * 100)}%` : 'spento'),
  qLoud: (v) => `${v} LUFS`,
  qComp: (v) => `${Math.round(v * 100)}%`,
  qBass: (v) => `+${v} dB`,
  qAir: (v) => `+${v} dB`,
  qRate: (v) => `${(v / 1000).toFixed(2).replace(/\.?0+$/, '')} Mbit/s`,
};
const AUDIO = { qLoud: 'loudness', qComp: 'compression', qBass: 'bassDb', qAir: 'airDb' };

function showValues() {
  for (const [id, f] of Object.entries(fmt)) $(`${id}V`).textContent = f(Number($(id).value));
  const enh = $('qEnhance').checked;
  for (const id of ['qContrast', 'qSaturation', 'qSharpness']) $(id).closest('.slider').classList.toggle('off', !enh);
  const off = $('qPreset').value === 'off';
  for (const id of Object.keys(AUDIO)) $(id).closest('.slider').classList.toggle('off', off);
  $('qPresetReset').disabled = off;
}

/** Sliders of the audio section at the preset's values, or at the saved tuning where set. */
function setAudio(preset, tuning) {
  $('qPreset').value = preset;
  const base = q.presets[preset];
  for (const [id, key] of Object.entries(AUDIO)) {
    $(id).disabled = !base;
    if (base) $(id).value = tuning?.[key] ?? base[key];
  }
}

function fill() {
  const v = q.video;
  $('qEnhance').checked = v.enhance !== 'off';
  $('qContrast').value = v.contrast;
  $('qSaturation').value = v.saturation;
  $('qSharpness').value = v.sharpness;
  $('qCleanup').value = v.cleanup;
  $('qZoom').value = v.fillZoom;
  setAudio(q.audio.processing, q.audio.tuning);
  $('qRate').value = q.videoBitrate;
  $('qMsg').textContent = '';
  showValues();
}

window.loadQuality = async () => {
  q = await api('/api/quality');
  fill();
};

function form() {
  const preset = $('qPreset').value;
  const base = q.presets[preset];
  const tuning = {};
  // Only the values moved away from the preset are saved; the others follow the preset.
  for (const [id, key] of Object.entries(AUDIO)) {
    const val = Number($(id).value);
    tuning[key] = base && Math.abs(val - base[key]) > 1e-9 ? val : null;
  }
  return {
    video: {
      enhance: $('qEnhance').checked,
      contrast: Number($('qContrast').value),
      saturation: Number($('qSaturation').value),
      sharpness: Number($('qSharpness').value),
      cleanup: $('qCleanup').value,
      fillZoom: Number($('qZoom').value),
    },
    audio: { processing: preset, tuning },
    videoBitrate: Number($('qRate').value),
  };
}

document.querySelectorAll('#view-quality input, #view-quality select').forEach((el) => el.addEventListener('input', showValues));
$('qPreset').addEventListener('change', () => {
  setAudio($('qPreset').value, null);
  showValues();
});
$('qPresetReset').onclick = () => {
  setAudio($('qPreset').value, null);
  showValues();
};
$('qReset').onclick = fill;
$('qSave').onclick = async () => {
  const body = form();
  const t = q.audio.tuning;
  const encoderChanged = body.audio.processing !== q.audio.processing || body.videoBitrate !== q.videoBitrate ||
    Object.keys(body.audio.tuning).some((k) => (body.audio.tuning[k] ?? null) !== (t[k] ?? null));
  if (encoderChanged && !confirm('Audio o bitrate cambiati: l’encoder si riavvia, con 1–2 secondi di pausa in onda. Procedere?')) return;
  $('qSave').disabled = true;
  try {
    const r = await api('/api/quality', 'POST', body);
    q = await api('/api/quality');
    fill();
    $('qMsg').textContent = r.encoderRestarted
      ? 'Applicato: video dal prossimo brano, audio e bitrate già in onda.'
      : 'Applicato: le modifiche al video valgono dal prossimo brano.';
  } catch (e) {
    $('qMsg').textContent = `Non applicato: ${e.message}`;
  } finally {
    $('qSave').disabled = false;
  }
};
if (location.hash === '#qualita') window.loadQuality();
