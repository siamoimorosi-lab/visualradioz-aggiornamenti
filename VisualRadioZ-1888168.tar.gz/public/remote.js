// Settings of the remote control page (Impostazioni → Controllo remoto).
let rm = null;
async function loadRemote() {
  rm = await api('/api/remote');
  $('rmOn').checked = rm.enabled;
  $('rmUrl').value = rm.url;
  $('rmAdmin').placeholder = rm.hasAdmin ? 'impostata: lascia vuoto per non cambiarla' : 'da impostare (almeno 6 caratteri)';
  $('rmUser').placeholder = rm.hasUser ? 'impostata: lascia vuoto per non cambiarla' : 'da impostare (almeno 6 caratteri)';
  $('rmUserOff').checked = false;
  $('rmSkips').value = rm.limits.skipsPerHour;
  $('rmDisable').checked = rm.limits.disable;
  $('rmReport').checked = rm.limits.report;
  $('rmClockMin').value = rm.limits.clockMinutes;
  $('rmClocks').innerHTML = rm.clocks.map((c) => `<label class="check"><input type="checkbox" value="${esc(c)}"${rm.limits.clocks.includes(c) ? ' checked' : ''}> ${esc(c)}</label>`).join('');
  showRemoteState();
}
function showRemoteState() {
  if (!rm) return;
  const s = rm.state;
  $('rmState').textContent = !rm.enabled ? 'spento'
    : s.lastOk && Date.now() - s.lastOk < 15000 ? 'collegato alla pagina'
    : s.lastError ? `non collegato: ${s.lastError}` : 'in attesa del primo contatto';
}
setInterval(async () => {
  if (views.settings.hidden || !rm?.enabled) return;
  try {
    rm.state = (await api('/api/remote')).state;
    showRemoteState();
  } catch {
    // shown at the next try
  }
}, 5000);
window.addEventListener('hashchange', () => !views.settings.hidden && loadRemote());
if (!views.settings.hidden) loadRemote();
$('rmSave').onclick = async () => {
  $('rmMsg').textContent = 'Salvo…';
  try {
    await api('/api/remote', 'POST', {
      enabled: $('rmOn').checked,
      url: $('rmUrl').value.trim(),
      adminPassword: $('rmAdmin').value,
      userPassword: $('rmUser').value,
      userOff: $('rmUserOff').checked,
      limits: {
        skipsPerHour: Number($('rmSkips').value),
        disable: $('rmDisable').checked,
        report: $('rmReport').checked,
        clockMinutes: Number($('rmClockMin').value),
        clocks: [...$('rmClocks').querySelectorAll('input:checked')].map((i) => i.value),
      },
    });
    $('rmAdmin').value = $('rmUser').value = '';
    await loadRemote();
    $('rmMsg').textContent = 'Salvato.';
  } catch (e) {
    $('rmMsg').textContent = `Non salvato: ${e.message}`;
  }
};
