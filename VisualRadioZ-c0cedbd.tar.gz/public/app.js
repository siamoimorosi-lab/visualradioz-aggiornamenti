// Control panel: live status over SSE, actions over the JSON API.
const token = new URLSearchParams(location.search).get('token');
const withToken = (u) => (token ? `${u}${u.includes('?') ? '&' : '?'}token=${encodeURIComponent(token)}` : u);
const $ = (id) => document.getElementById(id);

async function api(path, method = 'GET', body) {
  const r = await fetch(withToken(path), {
    method,
    headers: body ? { 'content-type': 'application/json' } : {},
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error ?? r.statusText);
  return r.json();
}

const mmss = (s) => {
  s = Math.max(0, Math.round(s));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
};
const name = (c) => (c ? (c.artist ? `${c.artist} – ${c.title}` : c.title) : '—');
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[ch]);

function li(html) {
  const el = document.createElement('li');
  el.innerHTML = html;
  return el;
}

function render(s) {
  $('channel').textContent = s.channel;
  document.title = `${s.channel} · Playout`;
  $('liveDot').classList.toggle('live', s.encoder.running);
  $('airState').textContent = s.running ? 'IN ONDA' : 'SPENTA';
  $('airState').className = `air ${s.running ? 'on' : 'off'}`;
  if (!$('airToggle').dataset.busy) {
    $('airToggle').disabled = false;
    $('airToggle').textContent = s.running ? 'Spegni diretta' : 'Accendi diretta';
    $('airToggle').dataset.on = s.running ? '1' : '';
  }
  $('encMeta').textContent = s.encoder.running
    ? `${s.encoder.name} · ${s.encoder.fps} fps · ${s.encoder.speed}x · ${s.encoder.bitrate} · attivo da ${mmss(s.encoder.uptime)}`
    : 'encoder fermo';
  if (s.version) $('encMeta').textContent += ` · versione ${s.version}`;


  if (s.cards) {
    const t = (ms) => (ms ? new Date(ms).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '—');
    $('cardInfo').dataset.base = `Meteo aggiornato ${t(s.cards.weatherAt)} · traffico ${t(s.cards.trafficAt)} (${s.cards.traffic} segnalazioni)`;
    if (!$('cardInfo').textContent || $('cardInfo').textContent.startsWith('Meteo aggiornato')) $('cardInfo').textContent = $('cardInfo').dataset.base;
  }
  const lp = s.library;
  $('libProgress').textContent = lp.probed < lp.total
    ? `· lettura tag ${lp.probed}/${lp.total}`
    : lp.analyzed < lp.total ? `· misure audio ${lp.analyzed}/${lp.total}` : '';

  const sc = s.schedule;
  $('clockName').textContent = `Orologio: ${sc.clock}`;
  $('breakNow').hidden = !sc.activeBreak;
  const breakOnAir = ['ad', 'bumper'].includes(s.onAir?.clip?.type);
  $('breakNow').textContent = sc.activeBreak ? `break ${breakOnAir ? 'in onda' : 'in arrivo'}: ${sc.activeBreak}` : '';
  $('slots').replaceChildren(...sc.slots.map((sl, i) => {
    const el = document.createElement('li');
    el.textContent = sl;
    el.className = i === sc.slotIndex ? 'cur' : '';
    return el;
  }));
  $('breaks').replaceChildren(...sc.upcoming.map((b) => {
    const left = Math.round((b.at - Date.now()) / 1000);
    return li(`<span class="t">${new Date(b.at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} · ${esc(b.name)}</span>
      <span class="row"><span class="sub">${left > 0 ? `tra ${mmss(left)}` : 'ora'}</span><span class="badge ${b.mode}">${b.mode}</span></span>`);
  }));
  if (!sc.upcoming.length) $('breaks').replaceChildren(li('<span class="sub">Nessun break nelle prossime ore</span>'));
  $('fireRow').hidden = !sc.breaks.length;
  const sel = $('fireName');
  if (sel.options.length !== sc.breaks.length) {
    sel.replaceChildren(...sc.breaks.map((n) => new Option(n, n)));
  }

  const q = $('queue');
  q.replaceChildren(...s.queue.map((c, i) => {
    const el = li(`<span class="t">${esc(name(c))}</span><span class="row">
      <span class="sub">${mmss(c.duration)}</span>
      <button class="ghost small" data-up="${i}" ${i === 0 ? 'disabled' : ''}>↑</button>
      <button class="ghost small" data-del="${i}">✕</button></span>`);
    return el;
  }));
  $('queueEmpty').hidden = s.queue.length > 0;

  $('outputs').replaceChildren(...s.outputs.map((o) =>
    li(`<span class="t" title="${esc(o.lastError)}">${esc(o.label)}</span>
      <span class="row"><span class="sub">${o.restarts ? `${o.restarts} riconn.` : ''}</span>
      <span class="badge ${o.state}">${o.state}</span></span>`)));

  $('history').replaceChildren(...s.history.map((h) =>
    li(`<span class="t">${esc(name(h))}</span><span class="sub">${new Date(h.at).toLocaleTimeString()}</span>`)));

  const log = $('log');
  const atBottom = log.scrollTop + log.clientHeight >= log.scrollHeight - 4;
  log.textContent = s.log.join('\n');
  if (atBottom) log.scrollTop = log.scrollHeight;
}

$('queue').addEventListener('click', async (e) => {
  const b = e.target.closest('button');
  if (!b) return;
  if (b.dataset.del !== undefined) await api(`/api/queue/${b.dataset.del}`, 'DELETE');
  if (b.dataset.up !== undefined) await api('/api/queue/move', 'POST', { from: +b.dataset.up, to: +b.dataset.up - 1 });
});

$('skip').onclick = () => api('/api/skip', 'POST');
$('airToggle').onclick = async () => {
  const b = $('airToggle');
  const on = !b.dataset.on;
  if (!on && !confirm('Spegnere la diretta? Il canale smette di trasmettere finché non la riaccendi.')) return;
  b.dataset.busy = '1';
  b.disabled = true;
  b.textContent = on ? 'Accensione…' : 'Spegnimento…';
  try {
    await api('/api/onair', 'POST', { on });
  } catch (e) {
    alert(e.message);
  } finally {
    delete b.dataset.busy;
  }
};
$('quit').onclick = async () => {
  if (!confirm('Chiudere il programma? La diretta si ferma. Per riaprirlo usa l’icona sul desktop.')) return;
  await api('/api/quit', 'POST').catch(() => {});
  document.body.innerHTML = '<p style="padding:40px;font:16px system-ui;color:#8b93a7">Programma chiuso. Puoi chiudere questa finestra.</p>';
  setTimeout(() => window.close(), 800);
};
document.querySelectorAll('[data-card]').forEach((b) => {
  b.onclick = async () => {
    const r = await api('/api/cards/force', 'POST', { kind: b.dataset.card }).catch((e) => ({ error: e.message }));
    $('cardInfo').textContent = r.error ? r.error
      : r.mode === 'now' ? 'In onda tra un istante.'
      : r.mode === 'next' ? 'Andrà in onda all’inizio del prossimo clip.'
      : 'Dati non ancora disponibili.';
  };
});
$('fire').onclick = () => api('/api/breaks/fire', 'POST', { name: $('fireName').value }).catch((e) => alert(e.message));
$('tickerSave').onclick = async () => {
  await api('/api/ticker', 'POST', { text: $('ticker').value });
  $('tickerSave').textContent = 'Aggiornato ✓';
  setTimeout(() => ($('tickerSave').textContent = 'Aggiorna'), 1500);
};
$('rescan').onclick = async () => {
  await api('/api/rescan', 'POST');
  setTimeout(loadLibrary, 1500);
};

let library = [];
const MAX_ROWS = 300;
function renderLibrary() {
  const f = $('search').value.trim().toLowerCase();
  const rows = library
    .filter((c) => !f || `${c.artist} ${c.title} ${c.category} ${c.file}`.toLowerCase().includes(f))
    .sort((a, b) => a.artist.localeCompare(b.artist) || a.title.localeCompare(b.title));
  $('libCount').textContent = rows.length > MAX_ROWS
    ? `${rows.length} clip, ne mostro ${MAX_ROWS}: affina la ricerca`
    : `${rows.length} clip`;
  $('library').innerHTML = rows.slice(0, MAX_ROWS).map((c) => `<tr>
      <td>${esc(c.artist)}</td><td>${esc(c.title)}</td>
      <td><span class="badge ${c.type}">${esc(c.category)}</span></td>
      <td>${c.probed ? mmss(c.duration) : '…'}${c.silentTail ? ` <span class="badge warn" title="Nel file il suono finisce ${mmss(c.silentTail)} prima del video: il brano va in onda solo fino alla fine del suono">audio corto</span>` : ''}</td>
      <td>${c.width ? `${c.width}×${c.height}` : ''}</td>
      <td>${c.lufs ?? (c.probed && !c.analyzed ? '<span class="sub">da misurare</span>' : '')}</td>
      ${c.error ? `<td class="err" title="${esc(c.error)}">errore</td>`
        : c.probed ? `<td><button class="small" data-q="${c.id}">Accoda</button> <button class="small ghost" data-qf="${c.id}">Subito dopo</button></td>`
        : '<td class="sub">lettura…</td>'}
    </tr>`).join('');
}
async function loadLibrary() {
  library = await api('/api/library');
  renderLibrary();
}
$('search').oninput = renderLibrary;
$('library').addEventListener('click', async (e) => {
  const b = e.target.closest('button');
  if (b?.dataset.q) await api('/api/queue', 'POST', { id: b.dataset.q });
  if (b?.dataset.qf) await api('/api/queue', 'POST', { id: b.dataset.qf, front: true });
});

async function loadAsrun() {
  const days = await api('/api/asrun');
  $('asrun').replaceChildren(...days.slice(0, 10).map((d) =>
    li(`<span>${d}</span><a href="${withToken(`/api/asrun/${d}`)}">Scarica CSV</a>`)));
}

let hls = null;
function startPreview() {
  const v = $('preview');
  const src = withToken('/preview/stream.m3u8');
  hls?.destroy();
  if (window.Hls?.isSupported()) {
    hls = new Hls({ liveSyncDuration: 4, xhrSetup: (xhr, url) => xhr.open('GET', withToken(url)) });
    hls.loadSource(src);
    hls.attachMedia(v);
    hls.on(Hls.Events.ERROR, (_, d) => d.fatal && setTimeout(startPreview, 3000));
  } else {
    v.src = `${src}${src.includes('?') ? '&' : '?'}t=${Date.now()}`; // Safari plays HLS natively
  }
  v.play().catch(() => {});
}
// A preview nobody sees costs the computer for nothing (and takes time from the encoder):
// paused while the page is hidden, started again when it comes back.
document.addEventListener('visibilitychange', () => {
  const v = $('preview');
  if (document.hidden) v.pause();
  else startPreview();
});
// If the picture stops moving (e.g. the playout restarted), start the preview again.
let lastTime = -1;
let stalledFor = 0;
setInterval(() => {
  if (document.hidden) return;
  const v = $('preview');
  stalledFor = v.currentTime === lastTime ? stalledFor + 2 : 0;
  lastTime = v.currentTime;
  if (stalledFor >= 8) {
    stalledFor = 0;
    startPreview();
  }
}, 2000);
$('unmute').onclick = () => {
  const v = $('preview');
  v.muted = !v.muted;
  $('unmute').textContent = v.muted ? 'Audio anteprima' : 'Muto';
};

const es = new EventSource(withToken('/api/events'));
es.onmessage = (e) => render(JSON.parse(e.data));
async function loadTicker(first = false) {
  const t = await api('/api/ticker');
  if (first) $('ticker').value = t.manual;
  const hhmm = (ms) => new Date(ms).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const row = (label, count, at, error) =>
    li(`<span class="t">${esc(label)}</span><span class="row">
      <span class="sub">${error ? esc(error) : `${count}${at ? ` · aggiornato ${hhmm(at)}` : ' · in attesa'}`}</span>
      <span class="badge ${error ? 'riconnessione' : 'attivo'}">${error ? 'errore' : at ? 'ok' : '…'}</span></span>`);
  // What the bar shows: the state of the bar, each news source and the event programme.
  const rows = [];
  if (!t.enabled) rows.push(li('<span class="t">Barra delle notizie spenta</span><span class="sub">si accende dal pulsante Notizie del gestore</span>'));
  if (t.events?.enabled) rows.push(row('Programma', `${t.events.events} eventi`, t.events.updatedAt, t.events.error));
  for (const f of t.feeds) rows.push(row(f.label, `${f.items} notizie`, f.updatedAt, f.error));
  $('feeds').replaceChildren(...rows);
}
loadTicker(true);
setInterval(loadTicker, 60000);
loadLibrary();
loadAsrun();
setInterval(loadAsrun, 60000);
setTimeout(startPreview, 1500);
