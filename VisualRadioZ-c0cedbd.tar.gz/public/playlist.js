// Views, the playlist (what aired, what is on air, the next three days) and the settings page.
// Uses api, $, esc and mmss from app.js.

const views = { live: $('view-live'), playlist: $('view-playlist'), settings: $('view-settings'), quality: $('view-quality') };
function showView() {
  const v = { '#playlist': 'playlist', '#impostazioni': 'settings', '#qualita': 'quality' }[location.hash] ?? 'live';
  for (const [k, el] of Object.entries(views)) el.hidden = k !== v;
  document.querySelectorAll('#nav a').forEach((a) => a.classList.toggle('on', a.dataset.view === v));
  if (v === 'playlist') loadPlaylist(true);
  if (v === 'live') loadSeq();
  if (v === 'quality') window.loadQuality?.();
  if (v === 'settings') loadSettings();
}
window.addEventListener('hashchange', showView);

// ---------------------------------------------------------------- playlist

let pl = null;
let plDay = null;
let clockOffset = 0; // server time − local time
const serverNow = () => Date.now() + clockOffset;
const hhmm = (ms, sec = false) =>
  new Date(ms).toLocaleTimeString('it-CH', { hour: '2-digit', minute: '2-digit', ...(sec ? { second: '2-digit' } : {}) });
const dayKey = (ms) => {
  const d = new Date(ms);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};
function dayLabel(key) {
  const [y, m, d] = key.split('-').map(Number);
  const date = new Date(y, m - 1, d);
  const today = new Date(serverNow());
  today.setHours(0, 0, 0, 0);
  const diff = Math.round((date - today) / 86400000);
  const names = { '-1': 'Ieri', 0: 'Oggi', 1: 'Domani', 2: 'Dopodomani' };
  const wd = date.toLocaleDateString('it-CH', { weekday: 'short', day: 'numeric', month: 'short' });
  return names[diff] ? `${names[diff]} · ${wd}` : wd;
}
const allRows = () => (pl ? [...pl.past, ...(pl.onAir ? [pl.onAir] : []), ...pl.future] : []);

async function loadPlaylist(scroll = false) {
  const before = pl?.onAir?.at;
  pl = await api('/api/playlist');
  clockOffset = pl.now - Date.now();
  const days = [...new Set(allRows().map((r) => dayKey(r.at)))].sort();
  if (!plDay || !days.includes(plDay)) plDay = dayKey(serverNow());
  $('plDays').replaceChildren(...days.map((k) => {
    const b = document.createElement('button');
    b.className = `small${k === plDay ? ' on' : ''}`;
    b.textContent = dayLabel(k);
    b.onclick = () => {
      plDay = k;
      loadPlaylist(k === dayKey(serverNow()));
    };
    return b;
  }));
  const fut = pl.future.length;
  const last = pl.future[fut - 1];
  $('plInfo').textContent = last ? `${fut} elementi pianificati, fino a ${dayLabel(dayKey(last.at)).toLowerCase()} alle ${hhmm(last.at)}` : '';
  renderPlaylist();
  if (scroll || ($('plFollow').checked && before !== pl.onAir?.at)) scrollToNow();
  tickPlaylist();
}

function rowHtml(r) {
  const cls = ['pl-row', r.kind, r.type === 'jingle' ? 'jingle' : ''].join(' ');
  const slot = r.kind === 'queue' ? 'CODA' : r.type === 'jingle' ? 'JINGLE' : r.slot;
  const sub = [r.artist, r.type === 'music' ? r.year : ''].filter(Boolean).join(' · ');
  return `<div class="${cls}">${r.kind === 'onair' ? '<div class="pl-fill"></div>' : ''}
    <span class="pl-time">${hhmm(r.at, true)}</span>
    <span class="slot" title="${esc(slot)}">${esc(slot)}</span>
    <div class="pl-what"><div class="pl-title">${esc(r.title)}</div><div class="pl-artist">${esc(sub)}</div></div>
    <span class="pl-dur">${mmss(r.duration)}</span>
    ${r.kind === 'onair' ? '<span></span>' : `<button class="play" title="Manda in onda ora" aria-label="Manda in onda ora"
      data-play="${esc(r.id)}"${r.uid !== undefined ? ` data-uid="${r.uid}"` : ''}${r.queueIndex !== undefined ? ` data-qi="${r.queueIndex}"` : ''}>▶</button>`}</div>`;
}

/** ▶ next to an item: it goes on air now, cutting the clip on air. */
async function playNow(e) {
  const b = e.target.closest('[data-play]');
  if (!b) return;
  const title = b.closest('.pl-row').querySelector('.pl-title').textContent;
  if (!confirm(`Mandare in onda ora «${title}»? Il brano in onda viene interrotto.`)) return;
  b.disabled = true;
  try {
    await api('/api/playnow', 'POST', {
      id: b.dataset.play,
      uid: b.dataset.uid !== undefined ? +b.dataset.uid : undefined,
      queueIndex: b.dataset.qi !== undefined ? +b.dataset.qi : undefined,
    });
    setTimeout(() => {
      loadSeq();
      if (!views.playlist.hidden) loadPlaylist();
    }, 1500);
  } catch (err) {
    alert(err.message);
    b.disabled = false;
  }
}
$('plList').addEventListener('click', playNow);
$('seq').addEventListener('click', playNow);

// The sequencer under the preview: one item that aired, the one on air, the next four.
let seq = null;
async function loadSeq() {
  seq = await api('/api/playlist?past=1&future=4');
  clockOffset = seq.now - Date.now();
  $('seq').innerHTML = [...seq.past, ...(seq.onAir ? [seq.onAir] : []), ...seq.future].map(rowHtml).join('');
  tickRow($('seq'), seq.onAir);
}
setInterval(() => !views.live.hidden && loadSeq(), 15000);

/** Fill and title colour of the row on air in `list`; returns how far it has gone (0–1). */
function tickRow(list, a) {
  if (!a) return 0;
  const p = Math.min(1, Math.max(0, (serverNow() - a.at) / Math.max(1, a.endsAt - a.at)));
  const row = list.querySelector('.onair');
  if (row) {
    row.querySelector('.pl-fill').style.width = `${p * 100}%`;
    row.querySelector('.pl-title').style.color = `color-mix(in srgb, var(--gold) ${Math.round(p * 100)}%, var(--text))`;
    // The row on air counts down to the next item.
    row.querySelector('.pl-dur').textContent = `-${mmss((a.endsAt - serverNow()) / 1000)}`;
  }
  return p;
}
setInterval(() => {
  if (views.live.hidden || !seq) return;
  tickRow($('seq'), seq.onAir);
  if (seq.onAir && serverNow() > seq.onAir.endsAt + 1500 && !loadSeq.busy) {
    loadSeq.busy = true;
    loadSeq().finally(() => (loadSeq.busy = false));
  }
}, 1000);

function renderPlaylist() {
  const rows = allRows().filter((r) => dayKey(r.at) === plDay);
  if (!rows.length) {
    $('plList').innerHTML = '<div class="pl-empty">Niente in questo giorno.</div>';
    return;
  }
  const out = [];
  let hour = null;
  for (const r of rows) {
    const h = new Date(r.at).getHours();
    if (h !== hour) {
      hour = h;
      const n = rows.filter((x) => new Date(x.at).getHours() === h && x.type === 'music').length;
      out.push(`<div class="pl-hour"><span>${String(h).padStart(2, '0')}:00</span><span>${n} brani</span></div>`);
    }
    out.push(rowHtml(r));
  }
  $('plList').innerHTML = out.join('');
}

function scrollToNow() {
  const el = $('plList').querySelector('.onair') ?? $('plList').querySelector('.next');
  el?.scrollIntoView({ block: 'center', behavior: 'smooth' });
}

/** Every second: how far the clip on air has gone, as a yellow fill and a title turning yellow. */
function tickPlaylist() {
  if (views.playlist.hidden || !pl) return;
  const a = pl.onAir;
  const now = serverNow();
  if (!a) {
    $('plHeroTitle').textContent = '—';
    return;
  }
  const total = Math.max(1, a.endsAt - a.at);
  const p = Math.min(1, Math.max(0, (now - a.at) / total));
  const color = `color-mix(in srgb, var(--gold) ${Math.round(p * 100)}%, var(--text))`;
  $('plHeroSlot').textContent = a.type === 'jingle' ? 'JINGLE' : a.slot;
  $('plHeroSlot').className = `slot${a.type === 'jingle' ? ' jingle' : ''}`;
  $('plHeroTitle').textContent = a.title;
  $('plHeroTitle').style.color = color;
  $('plHeroArtist').textContent = [a.artist, a.type === 'music' ? a.year : ''].filter(Boolean).join(' · ');
  $('plHeroFill').style.width = `${p * 100}%`;
  $('plHeroPos').textContent = mmss((now - a.at) / 1000);
  $('plHeroLeft').textContent = `-${mmss((a.endsAt - now) / 1000)}`;
  tickRow($('plList'), a);
  // The next item has taken the air: fetch the new state.
  if (now > a.endsAt + 1500 && !tickPlaylist.loading) {
    tickPlaylist.loading = true;
    loadPlaylist().finally(() => (tickPlaylist.loading = false));
  }
}
setInterval(tickPlaylist, 1000);
setInterval(() => !views.playlist.hidden && loadPlaylist(), 30000);
$('plNow').onclick = () => {
  plDay = dayKey(serverNow());
  loadPlaylist(true);
};
$('plRegen').onclick = async () => {
  if (!confirm('Rifare da capo la playlist dei prossimi tre giorni? Il brano in onda e il successivo restano.')) return;
  await api('/api/playlist/regenerate', 'POST');
  loadPlaylist(true);
};

// ---------------------------------------------------------------- settings

let st = null; // as loaded
let draft = null; // being edited
let focusClock = 0;

async function loadSettings() {
  st = await api('/api/settings');
  resetDraft();
}
function resetDraft() {
  const s = st.schedule;
  draft = {
    rotation: { ...st.rotation, sequence: (st.rotation.sequence ?? []).map((r) => ({ ...r })), backups: (st.rotation.backups ?? []).map((b) => ({ ...b })) },
    cards: { ...st.cards },
    clocks: Object.entries(s.clocks).map(([name, c]) => ({ name, slots: [...c.slots], continuous: !!c.continuous, exclude: (c.exclude ?? []).map((r) => ({ ...r })) })),
    grid: s.grid.map((g) => ({ ...g })),
    defaultClock: s.defaultClock,
    filters: (st.filters ?? []).map((f) => ({ name: f.name, match: f.match, rules: f.rules.map((r) => ({ ...r })) })),
  };
  $('stArtistMin').value = draft.rotation.artistSeparationMinutes;
  $('stTitleMin').value = draft.rotation.titleSeparationMinutes;
  $('stArtistCount').value = draft.rotation.artistSeparation;
  $('stJingle').value = draft.rotation.jingleEvery;
  $('stWeather').value = draft.cards.weatherEveryMinutes;
  $('stTraffic').value = draft.cards.trafficEveryMinutes;
  $('stMsg').textContent = '';
  renderSettings();
}

const catCount = (slot) => st.categories[slot] ?? (slot === 'music' ? Object.entries(st.categories).filter(([k]) => k !== 'jingle').reduce((s, [, n]) => s + n, 0) : 0);

function renderSettings() {
  const cats = Object.entries(st.categories).sort((a, b) => b[1] - a[1]);
  $('stCats').innerHTML = cats.map(([k, n]) => `<button class="chip" data-cat="${esc(k)}">${esc(k)}<small>${n}</small></button>`).join('');
  $('stClocks').innerHTML = draft.clocks.map((c, i) => `
    <details class="clock${i === focusClock ? ' focus' : ''}" data-i="${i}"${openClocks.has(i) ? ' open' : ''}>
      <summary><b>${esc(c.name)}</b><span class="sub">${c.slots.length} slot${c.exclude.length ? ` · ${c.exclude.length} esclusion${c.exclude.length === 1 ? 'e' : 'i'}` : ''}${c.name === draft.defaultClock ? ' · nelle altre ore' : ''}</span></summary>
      <div class="row between">
        <input class="clock-name" value="${esc(c.name)}" aria-label="Nome orologio">
        <label class="check"><input type="checkbox" class="clock-cont"${c.continuous ? ' checked' : ''}> Continua la sequenza tra un’ora e l’altra</label>
        <button class="ghost small clock-del"${draft.clocks.length < 2 ? ' disabled' : ''}>Elimina</button>
      </div>
      <div class="slots-edit">${c.slots.map((s, j) => `
        <span class="slot-chip${catCount(s) ? '' : ' missing'}" title="${catCount(s) ? `${catCount(s)} clip` : 'nessun clip in questa categoria'}">
          <span class="n">${j + 1}</span>${esc(s)}
          <button data-move="-1" data-j="${j}" aria-label="Sposta a sinistra">‹</button><button data-move="1" data-j="${j}" aria-label="Sposta a destra">›</button><button data-rm="${j}" aria-label="Togli">✕</button>
        </span>`).join('') || '<span class="sub">Nessuno slot: aggiungine uno.</span>'}
      </div>
      <p class="hint">${c.continuous ? 'La sequenza prosegue dall’ultimo slot anche al cambio d’ora.' : 'Ogni ora riparte dal primo slot.'} Un jingle ogni ${draft.rotation.jingleEvery || '—'} brani si aggiunge a parte.</p>
      <div class="excl"><span class="label">Escludi in questo orologio</span>
        ${c.exclude.map((r, j) => ruleRow(r, j)).join('')}
        <button class="ghost small x-add">+ Esclusione</button>
      </div>
    </details>`).join('');
  $('stGrid').innerHTML = draft.grid.map((g, i) => `
    <div class="grid-row" data-g="${i}">
      <input class="g-days" value="${esc(g.days)}" placeholder="giorni, es. lun-ven" aria-label="Giorni">
      <input class="g-hours" value="${esc(g.hours)}" placeholder="ore, es. 6-10" aria-label="Ore">
      <select class="g-clock" aria-label="Orologio">${draft.clocks.map((c) => `<option${c.name === g.clock ? ' selected' : ''}>${esc(c.name)}</option>`).join('')}</select>
      <button class="ghost small g-del">✕</button>
    </div>`).join('') || '<p class="hint">Nessuna regola: tutto il giorno va l’orologio qui sotto.</p>';
  renderFilters();
  renderSeq();
  renderBackups();
  $('stDefault').innerHTML = draft.clocks.map((c) => `<option${c.name === draft.defaultClock ? ' selected' : ''}>${esc(c.name)}</option>`).join('');
}

// ------------------------------------------------------ filter categories

const FIELD_NAMES = { genre: 'Genere', comment: 'Commento', artist: 'Artista', title: 'Titolo', album: 'Album', year: 'Anno', track: 'Traccia', composer: 'Compositore', bpm: 'BPM', content: 'Contenuto (dal commento)', temi: 'Temi (dal commento)', language: 'Lingua', lyricist: 'Autore del testo', copyright: 'Copyright', duration: 'Durata (secondi)', file: 'Percorso del file', albumartist: 'Artista dell’album', grouping: 'Gruppo' };
const OP_NAMES = { has: 'ha la voce', is: 'è', not: 'non è', contains: 'contiene', notContains: 'non contiene', starts: 'inizia con', gte: 'almeno', lte: 'al massimo' };
const fieldName = (f) => st.tagNames?.[f] ?? FIELD_NAMES[f] ?? f;

const openClocks = new Set();
const openFilters = new Set();
const knownFields = () => [...new Set(['genre', 'comment', 'artist', 'title', 'album', 'year', 'duration', 'file', ...(st.tagFields ?? []).map((t) => t.field)])];
const fieldSelect = (cls, value) =>
  `<select class="${cls}" aria-label="Campo">${[...new Set([...knownFields(), value])].filter(Boolean).map((k) => `<option value="${esc(k)}"${k === value ? ' selected' : ''}>${esc(fieldName(k))}</option>`).join('')}</select>`;
/** One rule (field, op, value), the same in filter categories and in clock exclusions. */
function ruleRow(r, j) {
  return `
      <div class="grid-row rule" data-r="${j}">
        ${fieldSelect('r-field', r.field)}
        <select class="r-op" aria-label="Regola">${Object.entries(OP_NAMES).map(([k, n]) => `<option value="${k}"${k === r.op ? ' selected' : ''}>${n}</option>`).join('')}</select>
        <input class="r-value" value="${esc(r.value)}" placeholder="valore, o più valori separati da virgola" aria-label="Valore">
        <button class="ghost small r-del">✕</button>
      </div>`;
}

// ------------------------------------------------------ backup categories

const allCategories = () => [...new Set([...Object.keys(st.categories).filter((k) => k !== 'jingle'), ...draft.filters.map((f) => f.name).filter(Boolean)])].sort();
function renderBackups() {
  const cats = allCategories();
  const sel = (cls, v) => `<select class="${cls}">${[...new Set([...cats, v])].filter(Boolean).map((k) => `<option${k === v ? ' selected' : ''}>${esc(k)}</option>`).join('')}</select>`;
  $('stBackups').innerHTML = draft.rotation.backups.map((b, i) => `
    <div class="seq-row" data-b="${i}">${sel('b-cat', b.category)}<span class="sub">riserva</span>${sel('b-backup', b.backup)}<button class="ghost small b-del">✕</button></div>`).join('')
    || '<p class="hint">Nessuna riserva.</p>';
}
$('stAddBackup').onclick = () => {
  const cats = allCategories();
  draft.rotation.backups.push({ category: cats[0] ?? '', backup: cats[1] ?? cats[0] ?? '' });
  renderBackups();
};
$('stBackups').addEventListener('change', (e) => {
  const row = e.target.closest('[data-b]');
  if (!row) return;
  const b = draft.rotation.backups[+row.dataset.b];
  b.category = row.querySelector('.b-cat').value;
  b.backup = row.querySelector('.b-backup').value;
});
$('stBackups').addEventListener('click', (e) => {
  const row = e.target.closest('[data-b]');
  if (row && e.target.closest('.b-del')) {
    draft.rotation.backups.splice(+row.dataset.b, 1);
    renderBackups();
  }
});

// ------------------------------------------------------ sequence rules

function renderSeq() {
  $('stSeq').innerHTML = draft.rotation.sequence.map((r, i) => `
    <div class="seq-row" data-s="${i}">
      ${fieldSelect('s-field', r.field)}
      <input class="s-value" value="${esc(r.value)}" placeholder="valore (vuoto = uguale)" aria-label="Valore">
      <select class="s-max" aria-label="Quanti di fila">${[1, 2, 3, 4].map((n) => `<option value="${n}"${n === r.max ? ' selected' : ''}>${n} di fila</option>`).join('')}</select>
      <button class="ghost small s-del">✕</button>
    </div>`).join('') || '<p class="hint">Nessuna regola.</p>';
}
$('stAddSeq').onclick = () => {
  draft.rotation.sequence.push({ field: knownFields().includes('lingua') ? 'lingua' : 'genre', value: '', max: 1 });
  renderSeq();
};
$('stSeq').addEventListener('change', (e) => {
  const row = e.target.closest('[data-s]');
  if (!row) return;
  const r = draft.rotation.sequence[+row.dataset.s];
  r.field = row.querySelector('.s-field').value;
  r.value = row.querySelector('.s-value').value.trim();
  r.max = Number(row.querySelector('.s-max').value);
});
$('stSeq').addEventListener('click', (e) => {
  const row = e.target.closest('[data-s]');
  if (row && e.target.closest('.s-del')) {
    draft.rotation.sequence.splice(+row.dataset.s, 1);
    renderSeq();
  }
});

function renderFilters() {
  $('stFilters').innerHTML = draft.filters.map((f, i) => `
    <details class="clock filter" data-f="${i}"${openFilters.has(i) ? ' open' : ''}>
      <summary><b>${esc(f.name || 'senza nome')}</b><span class="sub">${st.categories[f.name] !== undefined ? `${st.categories[f.name]} brani · ` : ''}${f.rules.length} regol${f.rules.length === 1 ? 'a' : 'e'}</span></summary>
      <div class="row between">
        <input class="clock-name f-name" value="${esc(f.name)}" placeholder="Nome della categoria" aria-label="Nome della categoria">
        <select class="f-match" aria-label="Quante regole"><option value="all"${f.match === 'all' ? ' selected' : ''}>Tutte le regole</option><option value="any"${f.match === 'any' ? ' selected' : ''}>Almeno una regola</option></select>
        <span class="sub">${st.categories[f.name] !== undefined ? `${st.categories[f.name]} brani (al salvataggio)` : 'salva per contare i brani'}</span>
        <button class="ghost small f-del">Elimina</button>
      </div>
      ${f.rules.map((r, j) => ruleRow(r, j)).join('')}
      <button class="ghost small f-add">+ Regola</button>
    </details>`).join('') || '<p class="hint">Nessuna categoria a filtri.</p>';
  $('stTags').innerHTML = (st.tagFields ?? []).map((t) =>
    `<p class="hint"><b>${esc(fieldName(t.field))}</b> <small>(${t.clips} brani)</small>: ${t.values.map(esc).join(' · ')}</p>`).join('') || '<p class="hint">Ancora nessun tag letto.</p>';
}

$('stAddFilter').onclick = () => {
  draft.filters.push({ name: '', match: 'all', rules: [{ field: 'genre', op: 'has', value: '' }] });
  openFilters.add(draft.filters.length - 1);
  renderFilters();
};
$('stFilters').addEventListener('toggle', (e) => {
  const d = e.target.closest?.('[data-f]');
  if (d) d.open ? openFilters.add(+d.dataset.f) : openFilters.delete(+d.dataset.f);
}, true);
$('stClocks').addEventListener('toggle', (e) => {
  const d = e.target.closest?.('[data-i]');
  if (!d) return;
  if (d.open) {
    openClocks.add(+d.dataset.i);
    focusClock = +d.dataset.i;
    renderFocus();
  } else openClocks.delete(+d.dataset.i);
}, true);
$('stFilters').addEventListener('click', (e) => {
  const box = e.target.closest('[data-f]');
  if (!box) return;
  const f = draft.filters[+box.dataset.f];
  if (e.target.closest('.f-del')) {
    draft.filters.splice(+box.dataset.f, 1);
    openFilters.clear();
  }
  else if (e.target.closest('.f-add')) f.rules.push({ field: 'genre', op: 'has', value: '' });
  else if (e.target.closest('.r-del')) f.rules.splice(+e.target.closest('[data-r]').dataset.r, 1);
  else return;
  renderFilters();
});
$('stFilters').addEventListener('change', (e) => {
  const box = e.target.closest('[data-f]');
  if (!box) return;
  const f = draft.filters[+box.dataset.f];
  const row = e.target.closest('[data-r]');
  const r = row && f.rules[+row.dataset.r];
  const c = e.target.classList;
  if (c.contains('f-name')) f.name = e.target.value.trim();
  else if (c.contains('f-match')) f.match = e.target.value;
  else if (r && c.contains('r-field')) r.field = e.target.value;
  else if (r && c.contains('r-op')) r.op = e.target.value;
  else if (r && c.contains('r-value')) r.value = e.target.value.trim();
});

$('stCats').addEventListener('click', (e) => {
  const b = e.target.closest('[data-cat]');
  if (!b || !draft.clocks[focusClock]) return;
  draft.clocks[focusClock].slots.push(b.dataset.cat);
  renderSettings();
});
$('stClocks').addEventListener('focusin', (e) => {
  const el = e.target.closest('.clock');
  if (el && +el.dataset.i !== focusClock) {
    focusClock = +el.dataset.i;
    document.querySelectorAll('.clock').forEach((c) => c.classList.toggle('focus', +c.dataset.i === focusClock));
  }
});
$('stClocks').addEventListener('click', (e) => {
  const el = e.target.closest('.clock');
  if (!el) return;
  const i = +el.dataset.i;
  const c = draft.clocks[i];
  focusClock = i;
  const b = e.target.closest('button');
  if (!b) return renderFocus();
  if (b.classList.contains('x-add')) {
    c.exclude.push({ field: knownFields().includes('energia') ? 'energia' : 'genre', op: 'lte', value: '' });
    return renderSettings();
  }
  if (b.classList.contains('r-del')) {
    c.exclude.splice(+b.closest('[data-r]').dataset.r, 1);
    return renderSettings();
  }
  if (b.dataset.rm !== undefined) c.slots.splice(+b.dataset.rm, 1);
  if (b.dataset.move !== undefined) {
    const j = +b.dataset.j;
    const k = j + +b.dataset.move;
    if (k >= 0 && k < c.slots.length) [c.slots[j], c.slots[k]] = [c.slots[k], c.slots[j]];
  }
  if (b.classList.contains('clock-del')) {
    draft.clocks.splice(i, 1);
    openClocks.clear();
    const first = draft.clocks[0].name;
    draft.grid.forEach((g) => g.clock === c.name && (g.clock = first));
    if (draft.defaultClock === c.name) draft.defaultClock = first;
    focusClock = 0;
  }
  renderSettings();
});
function renderFocus() {
  document.querySelectorAll('.clock').forEach((c) => c.classList.toggle('focus', +c.dataset.i === focusClock));
}
$('stClocks').addEventListener('change', (e) => {
  const el = e.target.closest('.clock');
  if (!el) return;
  const c = draft.clocks[+el.dataset.i];
  const row = e.target.closest('[data-r]');
  if (row) {
    const r = c.exclude[+row.dataset.r];
    r.field = row.querySelector('.r-field').value;
    r.op = row.querySelector('.r-op').value;
    r.value = row.querySelector('.r-value').value.trim();
    return;
  }
  if (e.target.classList.contains('clock-cont')) c.continuous = e.target.checked;
  if (e.target.classList.contains('clock-name')) {
    const name = e.target.value.trim() || c.name;
    draft.grid.forEach((g) => g.clock === c.name && (g.clock = name));
    if (draft.defaultClock === c.name) draft.defaultClock = name;
    c.name = name;
  }
  renderSettings();
});
$('stAddClock').onclick = () => {
  let n = 1;
  while (draft.clocks.some((c) => c.name === `orologio ${n}`)) n++;
  draft.clocks.push({ name: `orologio ${n}`, slots: [], continuous: false, exclude: [] });
  focusClock = draft.clocks.length - 1;
  openClocks.add(focusClock);
  renderSettings();
};
$('stGrid').addEventListener('change', (e) => {
  const row = e.target.closest('.grid-row');
  if (!row) return;
  const g = draft.grid[+row.dataset.g];
  g.days = row.querySelector('.g-days').value.trim() || '*';
  g.hours = row.querySelector('.g-hours').value.trim() || '*';
  g.clock = row.querySelector('.g-clock').value;
});
$('stGrid').addEventListener('click', (e) => {
  const row = e.target.closest('.grid-row');
  if (row && e.target.closest('.g-del')) {
    draft.grid.splice(+row.dataset.g, 1);
    renderSettings();
  }
});
$('stAddRule').onclick = () => {
  draft.grid.push({ days: 'lun-ven', hours: '6-10', clock: draft.clocks[0].name });
  renderSettings();
};
$('stDefault').onchange = (e) => (draft.defaultClock = e.target.value);
$('stWeather').onchange = (e) => (draft.cards.weatherEveryMinutes = Number(e.target.value));
$('stTraffic').onchange = (e) => (draft.cards.trafficEveryMinutes = Number(e.target.value));
for (const [id, key] of [['stArtistMin', 'artistSeparationMinutes'], ['stTitleMin', 'titleSeparationMinutes'], ['stArtistCount', 'artistSeparation'], ['stJingle', 'jingleEvery']]) {
  $(id).onchange = (e) => {
    draft.rotation[key] = Number(e.target.value);
    if (key === 'jingleEvery') renderSettings();
  };
}
$('stReset').onclick = resetDraft;
$('stSave').onclick = async () => {
  const names = draft.clocks.map((c) => c.name);
  if (new Set(names).size !== names.length) return ($('stMsg').textContent = 'Due orologi hanno lo stesso nome.');
  const empty = draft.clocks.find((c) => !c.slots.length);
  if (empty) return ($('stMsg').textContent = `L’orologio “${empty.name}” non ha slot.`);
  const { artistSeparation, artistSeparationMinutes, titleSeparationMinutes, jingleEvery, sequence, backups } = draft.rotation;
  const body = {
    rotation: { artistSeparation, artistSeparationMinutes, titleSeparationMinutes, jingleEvery, sequence, backups },
    cards: draft.cards,
    schedule: {
      clocks: Object.fromEntries(draft.clocks.map((c) => [c.name, { slots: c.slots, continuous: c.continuous, exclude: c.exclude }])),
      grid: draft.grid,
      defaultClock: draft.defaultClock,
    },
    filters: draft.filters,
  };
  $('stSave').disabled = true;
  $('stMsg').textContent = 'Salvo e ripianifico…';
  try {
    const r = await api('/api/settings', 'POST', body);
    await loadSettings();
    $('stMsg').textContent = `Salvato. Playlist ripianificata: ${r.planned} elementi nei prossimi tre giorni.`;
    pl = null;
  } catch (e) {
    $('stMsg').textContent = `Non salvato: ${e.message}`;
  } finally {
    $('stSave').disabled = false;
  }
};

showView();
