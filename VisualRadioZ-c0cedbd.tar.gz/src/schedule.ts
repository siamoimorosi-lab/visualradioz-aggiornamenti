import type { Rule } from './filters.ts';
import fs from 'node:fs';
import { type Config, resolvePath } from './config.ts';

/**
 * Programme schedule (schedule.json):
 * - clocks: a sequence of slots per hour, restarting at every hour;
 * - grid: which clock runs on which days and hours;
 * - breaks: ad blocks at fixed times.
 */

/** A slot names a category or a type, e.g. "music", "rock", "jingle". */
export type Slot = string;

export interface Clock {
  slots: Slot[];
  /** false (default): the clock starts again from its first slot every hour. */
  continuous?: boolean;
  /** Songs left out while this clock is on air (any rule that holds leaves the song out). */
  exclude?: Rule[];
}

export interface GridRule {
  /** "*", "mon-fri", "sat,sun" (Italian lun..dom also accepted). */
  days: string;
  /** "6-10" means from 06:00 to 09:59. "*" = all day. */
  hours: string;
  clock: string;
}

export interface BreakRule {
  name: string;
  days: string;
  hours: string;
  /** Minutes past each hour within `hours`, e.g. [15, 45]. */
  minutes?: number[];
  /** Or fixed times, e.g. ["08:30", "12:00"]. */
  at?: string[];
  /** soft: after the clip on air ends; hard: at the exact time, cutting with a fade. */
  mode: 'soft' | 'hard';
  /** Category or type the spots are taken from (rotated, least recently played first). */
  pool: string;
  /** Number of spots, and/or a cap on the block length in seconds. */
  count?: number;
  maxSeconds?: number;
  /** Optional bumpers, as file names (or parts of them) from the library. */
  intro?: string;
  outro?: string;
  /** Skip the break if it could not start within this many minutes of its time. */
  maxLateMinutes?: number;
}

export interface Schedule {
  clocks: Record<string, Clock>;
  grid: GridRule[];
  defaultClock: string;
  breaks: BreakRule[];
}

const DAY_NAMES: Record<string, number> = {
  sun: 0, mon: 1, tue: 2, wed: 3, thu: 4, fri: 5, sat: 6,
  dom: 0, lun: 1, mar: 2, mer: 3, gio: 4, ven: 5, sab: 6,
};

/** Parse "mon-fri", "sat,sun", "*" into a set of weekday numbers (0 = Sunday). */
export function parseDays(spec: string): Set<number> {
  const out = new Set<number>();
  for (const part of spec.toLowerCase().split(',').map((s) => s.trim()).filter(Boolean)) {
    if (part === '*') return new Set([0, 1, 2, 3, 4, 5, 6]);
    const [a, b] = part.split('-').map((s) => DAY_NAMES[s.slice(0, 3)]);
    if (a === undefined) throw new Error(`giorno non valido: ${part}`);
    if (b === undefined) out.add(a);
    else for (let d = a; ; d = (d + 1) % 7) { out.add(d); if (d === b) break; }
  }
  return out;
}

/** Parse "6-10", "22-2", "8", "*" into the set of hours covered. */
export function parseHours(spec: string): Set<number> {
  const out = new Set<number>();
  for (const part of spec.split(',').map((s) => s.trim()).filter(Boolean)) {
    if (part === '*') return new Set([...Array(24).keys()]);
    const [a, b] = part.split('-').map(Number);
    if (!(a >= 0 && a < 24)) throw new Error(`ora non valida: ${part}`);
    if (b === undefined) out.add(a);
    else if (a === b % 24) return parseHours('*'); // "0-24"
    else for (let h = a; h !== b % 24; h = (h + 1) % 24) out.add(h);
  }
  return out;
}

export interface BreakOccurrence {
  rule: BreakRule;
  at: number; // ms
  key: string;
}

export class ScheduleBook {
  sched: Schedule;
  private days = new Map<object, Set<number>>();
  private hours = new Map<object, Set<number>>();

  constructor(sched: Schedule) {
    this.sched = sched;
    for (const r of [...sched.grid, ...sched.breaks]) {
      this.days.set(r, parseDays(r.days));
      this.hours.set(r, parseHours(r.hours));
    }
    for (const g of sched.grid) if (!sched.clocks[g.clock]) throw new Error(`orologio sconosciuto: ${g.clock}`);
    if (!sched.clocks[sched.defaultClock]) throw new Error(`orologio di default sconosciuto: ${sched.defaultClock}`);
  }

  private matches(rule: object, d: Date): boolean {
    return this.days.get(rule)!.has(d.getDay()) && this.hours.get(rule)!.has(d.getHours());
  }

  /** The clock in effect at `at`; the first matching grid rule wins. */
  clockAt(at: number): { name: string; clock: Clock } {
    const d = new Date(at);
    const rule = this.sched.grid.find((g) => this.matches(g, d));
    const name = rule?.clock ?? this.sched.defaultClock;
    return { name, clock: this.sched.clocks[name] };
  }

  /** All break occurrences in [from, to], in time order. */
  breaksBetween(from: number, to: number): BreakOccurrence[] {
    const out: BreakOccurrence[] = [];
    const day0 = new Date(from);
    day0.setHours(0, 0, 0, 0);
    for (let day = new Date(day0); day.getTime() <= to; day.setDate(day.getDate() + 1)) {
      for (const rule of this.sched.breaks) {
        if (!this.days.get(rule)!.has(day.getDay())) continue;
        const times: Date[] = [];
        for (const t of rule.at ?? []) {
          const [h, m] = t.split(':').map(Number);
          times.push(new Date(day.getFullYear(), day.getMonth(), day.getDate(), h, m));
        }
        for (const h of rule.minutes ? this.hours.get(rule)! : []) {
          for (const m of rule.minutes!) times.push(new Date(day.getFullYear(), day.getMonth(), day.getDate(), h, m));
        }
        for (const t of times) {
          const ms = t.getTime();
          if (ms >= from && ms <= to && (rule.at || this.hours.get(rule)!.has(t.getHours()))) {
            out.push({ rule, at: ms, key: `${rule.name}@${ms}` });
          }
        }
      }
    }
    return out.sort((a, b) => a.at - b.at);
  }
}

/** Without schedule.json: music only (jingles come from rotation.jingleEvery). */
function fallbackSchedule(_cfg: Config): Schedule {
  return { clocks: { standard: { slots: ['music'] } }, grid: [], defaultClock: 'standard', breaks: [] };
}

export const scheduleFile = () => resolvePath(process.env.WEBTV_SCHEDULE ?? 'schedule.json');

/** Write schedule.json (from the settings page); throws, writing nothing, if it is not valid. */
export function saveSchedule(sched: Schedule): ScheduleBook {
  const book = new ScheduleBook(sched);
  fs.writeFileSync(scheduleFile(), JSON.stringify(sched, null, 2) + '\n');
  return book;
}

export function loadSchedule(cfg: Config, file = scheduleFile()): ScheduleBook {
  const full = file;
  if (!fs.existsSync(full)) return new ScheduleBook(fallbackSchedule(cfg));
  const raw = JSON.parse(fs.readFileSync(full, 'utf8'));
  return new ScheduleBook({
    clocks: raw.clocks ?? {},
    grid: raw.grid ?? [],
    defaultClock: raw.defaultClock ?? Object.keys(raw.clocks ?? {})[0],
    breaks: (raw.breaks ?? []).map((b: Partial<BreakRule>) => ({ mode: 'soft', days: '*', hours: '*', maxLateMinutes: 10, ...b }) as BreakRule),
  });
}
