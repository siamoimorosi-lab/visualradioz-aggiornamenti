import { spawn, type ChildProcess } from 'node:child_process';
import os from 'node:os';

export const FFMPEG = process.env.FFMPEG ?? 'ffmpeg';
export const FFPROBE = process.env.FFPROBE ?? 'ffprobe';

/** Quote a value for use as a filter option inside a filtergraph (paths, text). */
export function filterValue(v: string): string {
  const s = v.replace(/\\/g, '/').replace(/'/g, "'\\''").replace(/:/g, '\\:');
  return `'${s}'`;
}

/** Format seconds for ffmpeg arguments. */
export function sec(n: number): string {
  return Math.max(0, n).toFixed(3);
}

/**
 * Pick a working H.264 encoder: VideoToolbox on macOS, NVENC/QSV/AMF on
 * Windows and Linux, libx264 as the fallback. Each candidate is test-encoded
 * because an encoder can be compiled in without the matching hardware.
 */
export async function detectVideoEncoder(): Promise<string> {
  const candidates =
    process.platform === 'darwin'
      ? ['h264_videotoolbox']
      : ['h264_nvenc', 'h264_qsv', 'h264_amf'];
  for (const enc of candidates) {
    const r = await run(
      FFMPEG,
      ['-hide_banner', '-v', 'error', '-f', 'lavfi', '-i', 'color=s=640x360:d=0.2',
        '-c:v', enc, '-f', 'null', '-'],
      15000,
    );
    if (r.code === 0) return enc;
  }
  return 'libx264';
}

export interface RunResult {
  code: number | null;
  stdout: string;
  stderr: string;
}

/**
 * On-air processes (decoders, encoder, outputs) run above normal priority and
 * background work (library analysis) below it, so the stream always wins.
 */
export function setPriority(p: ChildProcess, level: 'onAir' | 'background') {
  if (!p.pid) return;
  try {
    os.setPriority(p.pid, level === 'onAir' ? os.constants.priority.PRIORITY_ABOVE_NORMAL : os.constants.priority.PRIORITY_BELOW_NORMAL);
  } catch {
    // Raising priority may need rights the user lacks (e.g. on macOS): keep the default.
  }
}

export function run(cmd: string, args: string[], timeoutMs = 0, priority?: 'onAir' | 'background'): Promise<RunResult> {
  return new Promise((resolve, reject) => {
    const p = spawn(cmd, args, { windowsHide: true });
    if (priority) setPriority(p, priority);
    let stdout = '';
    let stderr = '';
    p.stdout.on('data', (d) => (stdout += d));
    p.stderr.on('data', (d) => (stderr += d));
    const timer = timeoutMs ? setTimeout(() => p.kill('SIGKILL'), timeoutMs) : undefined;
    p.on('error', reject);
    p.on('close', (code) => {
      if (timer) clearTimeout(timer);
      resolve({ code, stdout, stderr });
    });
  });
}
