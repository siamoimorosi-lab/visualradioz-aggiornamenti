import fs from 'node:fs';
import path from 'node:path';
import { type Config, resolvePath } from './config.ts';
import { FFMPEG, run } from './ffmpeg.ts';
import { clean } from './ticker.ts';

/**
 * The programme of an event, read from its web page: what is on today and
 * tomorrow for the ticker, and the coming headliners with their pictures for
 * a card. The page must be built like winterland.swiss/programma: one
 * `wl-day` section per day (data-date) holding `wl-event` entries with place,
 * time, title and kind (data-tipo), and a picture for the main ones.
 */
export interface ProgramEvent {
  /** yyyy-mm-dd, the day of the programme the event is listed under. */
  date: string;
  /** "20:30", or "17:30-02:00". */
  time: string;
  town: string;
  place: string;
  title: string;
  subtitle: string;
  kind: string;
  image: string;
}

const text = (html: string | undefined) => (html ? clean(html) : '');
const inner = (block: string, cls: string) => block.match(new RegExp(`class="[^"]*\\b${cls}\\b[^"]*"[^>]*>([\\s\\S]*?)</span>`))?.[1];

/** Every event of the page, in page order (by day, then by time). */
export function parseProgram(html: string): ProgramEvent[] {
  const out: ProgramEvent[] = [];
  // The page repeats the days in more than one list (e.g. one per filter): keep each event once.
  const seen = new Set<string>();
  const days = html.split(/<section\b(?=[^>]*\bclass="[^"]*\bwl-day\b)/).slice(1);
  for (const day of days) {
    const date = day.match(/data-date="(\d{4}-\d{2}-\d{2})"/)?.[1];
    if (!date) continue;
    const events = day.split(/<(?:div|details)\b(?=[^>]*\bclass="[^"]*\bwl-event\b)/).slice(1);
    for (const e of events) {
      const title = text(inner(e, 'wl-title'));
      const time = text(inner(e, 'wl-time'));
      if (!title) continue;
      const ev: ProgramEvent = {
        date, time, title,
        town: text(e.match(/class="[^"]*\bwl-badge-town\b[^"]*"[^>]*>([\s\S]*?)<\/span>/)?.[1]),
        place: text(inner(e, 'wl-place-loc')),
        subtitle: text(inner(e, 'wl-subtitle')),
        kind: e.match(/data-tipo="([^"]*)"/)?.[1] ?? '',
        // The largest picture of the entry (the list also carries a small round one).
        image: e.match(/class="wl-image"[\s\S]*?data-src="([^"]+)"/)?.[1] ?? e.match(/data-src="(https?:[^"]+\.(?:webp|jpe?g|png))"/i)?.[1] ?? '',
      };
      const key = `${ev.date}|${ev.time}|${ev.town}|${ev.title}`;
      if (seen.has(key)) continue;
      seen.add(key);
      out.push(ev);
    }
  }
  return out;
}

const pad = (n: number) => String(n).padStart(2, '0');
export const dayKey = (d: Date) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const WEEKDAYS = ['Domenica', 'Lunedì', 'Martedì', 'Mercoledì', 'Giovedì', 'Venerdì', 'Sabato'];

/** "alle 22", "alle 20:30", "dalle 17:30 alle 2": an event's time as said aloud. */
export function timeText(time: string): string {
  const t = [...time.matchAll(/(\d{1,2})[:.](\d{2})/g)].map((m) => (m[2] === '00' ? String(Number(m[1])) : `${Number(m[1])}:${m[2]}`));
  if (!t.length) return time.trim();
  return t.length > 1 ? `dalle ${t[0]} alle ${t[t.length - 1]}` : `alle ${t[0]}`;
}

/** Until this hour of the morning it is still the evening before: "oggi" is that day. */
const DAY_STARTS_AT = 3;

/** The programme day at `now`: after midnight and before 3 it is still the day before. */
export function programmeDay(now: Date): Date {
  const d = new Date(now.getTime() - DAY_STARTS_AT * 3600_000);
  return new Date(d.getFullYear(), d.getMonth(), d.getDate(), 12);
}

/** "Oggi martedì", "Domani mercoledì" or "Giovedì 19.11" for a programme day, seen from `now`. */
export function dayName(date: string, now: Date): string {
  const today = programmeDay(now);
  const tomorrow = new Date(today.getFullYear(), today.getMonth(), today.getDate() + 1, 12);
  const [y, m, d] = date.split('-').map(Number);
  const weekday = WEEKDAYS[new Date(y, m - 1, d).getDay()];
  if (date === dayKey(today)) return `Oggi ${weekday.toLowerCase()}`;
  if (date === dayKey(tomorrow)) return `Domani ${weekday.toLowerCase()}`;
  return `${weekday} ${d}.${pad(m)}`;
}

/**
 * When an event is over, as a time on the clock. Hours before 6 belong to the
 * night of the day they are listed under ("00:00" under Friday is Saturday at midnight).
 */
function endsAt(e: ProgramEvent): number {
  const [y, m, d] = e.date.split('-').map(Number);
  const times = [...e.time.matchAll(/(\d{1,2})[:.](\d{2})/g)].map((t) => Number(t[1]) * 60 + Number(t[2]));
  if (!times.length) return new Date(y, m - 1, d, 23, 59).getTime();
  // A single time: on for an hour. A range: until its end.
  let end = times.length > 1 ? times[times.length - 1] : times[0] + 60;
  if (times.length > 1 && end < times[0]) end += 24 * 60;
  else if (times[0] < 6 * 60) end += 24 * 60;
  return new Date(y, m - 1, d, 0, end).getTime();
}

/** What the ticker says: today's events still to come or on now, then tomorrow's. */
export function comingUp(events: ProgramEvent[], now: Date, max = 12): { day: string; event: ProgramEvent }[] {
  const today = dayKey(programmeDay(now));
  // After midnight the events of the evening before can still be on.
  const live = events.filter((e) => endsAt(e) > now.getTime());
  // Two programme days: today and tomorrow, or the first two with something on.
  const dates = [...new Set(live.map((e) => e.date))].sort().slice(0, 2);
  return live.filter((e) => dates.includes(e.date)).slice(0, max)
    .map((event) => ({ day: event.date < today ? 'Ora' : dayName(event.date, now), event }));
}

/**
 * The events not left out by kind or by town; an entry of several kinds stays when one of
 * them is wanted. Towns are compared without case ("Ascona", "ascona").
 */
export function wantedEvents(events: ProgramEvent[], skipKinds: string[], skipTowns: string[] = []): ProgramEvent[] {
  const towns = skipTowns.map((t) => t.trim().toLowerCase()).filter(Boolean);
  return events.filter((e) =>
    !towns.includes(e.town.trim().toLowerCase()) &&
    (e.kind.trim() ? e.kind.trim().split(/\s+/) : ['']).some((k) => !skipKinds.includes(k)));
}

export class EventProgram {
  private cfg: Config;
  private dir: string;
  events: ProgramEvent[] = [];
  updatedAt = 0;
  error = '';
  /** False until the pictures of the coming main acts were fetched once: the card waits for them. */
  picturesReady = false;
  /** Pictures already fetched and turned into PNG: address → file. */
  private pictures = new Map<string, string>();
  private timers: NodeJS.Timeout[] = [];

  constructor(cfg: Config) {
    this.cfg = cfg;
    this.dir = path.join(resolvePath(cfg.dataDir), 'events');
    fs.mkdirSync(this.dir, { recursive: true });
  }

  get enabled() {
    return /^https?:\/\//i.test(this.cfg.events.url);
  }

  start() {
    if (!this.enabled) return;
    const refresh = () => this.refresh().catch((e) => (this.error = String(e.message ?? e)));
    refresh();
    this.timers.push(setInterval(refresh, Math.max(5, this.cfg.events.refreshMinutes) * 60000));
  }

  stop() {
    for (const t of this.timers) clearInterval(t);
  }

  /** Read the page again; when it fails the programme already read stays. */
  async refresh() {
    const res = await fetch(this.cfg.events.url, { headers: { 'user-agent': 'Mozilla/5.0 (VisualRadioZ)' }, signal: AbortSignal.timeout(30000) });
    if (!res.ok) throw new Error(`programma: HTTP ${res.status}`);
    const events = parseProgram(await res.text());
    if (!events.length) throw new Error('programma: nessun evento trovato nella pagina');
    this.events = events;
    this.updatedAt = Date.now();
    this.error = '';
    for (const e of this.headliners(new Date())) await this.picture(e.image).catch(() => {});
    this.picturesReady = true;
  }

  /** Ticker lines for now. */
  lines(now = new Date()): { text: string; sub: string }[] {
    return comingUp(wantedEvents(this.events, this.cfg.events.skipKinds ?? [], this.cfg.events.skipTowns ?? []), now).map(({ day, event: e }) => ({
      text: `${day}${e.time ? ` ${timeText(e.time)}` : ''} · ${e.title}`,
      sub: [e.town, e.place, e.subtitle].filter(Boolean).join(' · '),
    }));
  }

  /** The next main acts, soonest first. */
  headliners(now = new Date(), max = 3): ProgramEvent[] {
    const kinds = this.cfg.events.cardKinds;
    // An entry can be of more than one kind ("evento headliner").
    return wantedEvents(this.events, [], this.cfg.events.skipTowns ?? [])
      .filter((e) => e.kind.split(/\s+/).some((k) => kinds.includes(k)) && endsAt(e) > now.getTime()).slice(0, max);
  }

  /** The picture of an event as a PNG file, or '' when there is none yet. */
  pictureOf(e: ProgramEvent): string {
    const f = this.pictures.get(e.image);
    return f && fs.existsSync(f) ? f : '';
  }

  private async picture(url: string) {
    if (!/^https?:\/\//i.test(url) || this.pictureOf({ image: url } as ProgramEvent)) return;
    const name = url.replace(/^https?:\/\//, '').replace(/[^a-z0-9]+/gi, '-').slice(-80);
    const raw = path.join(this.dir, `${name}.src`);
    const png = path.join(this.dir, `${name}.png`);
    if (!fs.existsSync(png)) {
      const res = await fetch(url, { headers: { 'user-agent': 'Mozilla/5.0 (VisualRadioZ)' }, signal: AbortSignal.timeout(30000) });
      if (!res.ok) return;
      fs.writeFileSync(raw, Buffer.from(await res.arrayBuffer()));
      // WebP and the like become a PNG no wider than the card needs.
      const r = await run(FFMPEG, ['-hide_banner', '-v', 'error', '-y', '-i', raw, '-vf', 'scale=900:-2:force_original_aspect_ratio=decrease', '-frames:v', '1', png], 60000);
      fs.rmSync(raw, { force: true });
      if (r.code !== 0) return;
    }
    this.pictures.set(url, png);
  }

  status() {
    return { enabled: this.enabled, events: this.events.length, updatedAt: this.updatedAt, error: this.error };
  }
}
