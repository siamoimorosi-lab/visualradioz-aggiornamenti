import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { type Config, resolvePath } from './config.ts';
import type { Clip, Library } from './library.ts';
import { parseDays, parseHours } from './schedule.ts';
import type { Scheduler } from './scheduler.ts';
import { writeQrImage } from './qr.ts';

/**
 * Televoto: in the hours chosen, a round of songs (some new, the rest from other
 * categories) is put to the vote with a number each; people scan the QR on screen and vote
 * on a page of the station's site (remote/vota.html, through the same relay as the remote
 * control). When the round closes the most voted song goes on next, announced as such, and a
 * new round starts.
 */
export interface VoteSong { n: number; id: string; artist: string; title: string; isNew: boolean; tag?: string }
export interface VoteRound { id: string; songs: VoteSong[]; openedAt: number; closesAt: number }
export interface VoteResult { id: string; artist: string; title: string; votes: number; total: number; at: number; airsAt?: string }

export class Vote {
  private cfg: Config;
  private lib: Library;
  private sched: Scheduler;
  private file: string;
  round: VoteRound | null = null;
  counts: number[] = [];
  last: VoteResult | null = null;
  /** Rounds asked for by hand (remote control) outside the hours: how many are left. */
  private forced = 0;
  /** Winners waiting to air, for the "most voted" lower third. */
  private winners = new Map<string, VoteResult>();
  /**
   * The winner queued and not yet on air (the next song is prepared in advance, so it airs one
   * or two songs later): no new round until it does, and the ticker says it is coming.
   */
  waiting: (VoteResult & { since: number; airsAt?: string }) | null = null;
  private timer: NodeJS.Timeout | null = null;
  private qrFor = '';
  /** Until when the page must hear from the program (a round just closed or cancelled). */
  talkUntil = 0;
  note: (m: string) => void = () => {};
  /** Clips already taken for air by the engine (never put to the vote) and when a queued clip would air. */
  comingUp: () => Clip[] = () => [];
  queueStartsAt: () => number = () => Date.now() + 6 * 60_000;
  onChange: () => void = () => {};

  constructor(cfg: Config, lib: Library, sched: Scheduler) {
    this.cfg = cfg;
    this.lib = lib;
    this.sched = sched;
    this.file = path.join(resolvePath(cfg.dataDir), 'vote.json');
    try {
      const s = JSON.parse(fs.readFileSync(this.file, 'utf8'));
      if (s.round && s.round.closesAt > Date.now()) {
        this.round = s.round;
        this.counts = s.counts ?? [];
      }
      this.last = s.last ?? null;
    } catch {
      // first run
    }
  }

  start() {
    this.timer ??= setInterval(() => this.tick(), 5000);
    setInterval(() => this.writeCountdown(), 1000);
    this.tick();
  }

  /** Time left to vote, for the screen (read again by the decoders every second). */
  countdownFile(): string {
    return path.join(resolvePath(this.cfg.dataDir), 'tmp', 'voto-tempo.txt');
  }

  private writeCountdown() {
    if (!this.round) return;
    const left = Math.max(0, Math.round((this.round.closesAt - Date.now()) / 1000));
    const text = `si vota ancora per ${Math.floor(left / 60)}:${String(left % 60).padStart(2, '0')}`;
    try {
      fs.mkdirSync(path.dirname(this.countdownFile()), { recursive: true });
      fs.writeFileSync(this.countdownFile() + '.tmp', text);
      fs.renameSync(this.countdownFile() + '.tmp', this.countdownFile());
    } catch {
      // read by a decoder at this moment: next second
    }
  }

  private save() {
    this.talkUntil = Date.now() + 30 * 60_000;
    try {
      fs.writeFileSync(this.file, JSON.stringify({ round: this.round, counts: this.counts, last: this.last }));
    } catch {
      // not essential
    }
  }

  /** Address of the vote page: next to the remote control page. */
  pageUrl(): string {
    // A short address of the station's own (a redirect on the site) reads better on screen.
    const own = (this.cfg.vote.address ?? '').trim();
    if (own) return /^https?:\/\//i.test(own) ? own : `https://${own}`;
    const u = this.cfg.remote.url.trim();
    return u ? `${u.endsWith('/') ? u : `${u}/`}vota.html` : '';
  }

  /** The QR picture of the page address, made again when the address changes. */
  qrFile(): string {
    const url = this.pageUrl();
    const f = path.join(resolvePath(this.cfg.dataDir), 'vota-qr.pgm');
    if (url && (this.qrFor !== url || !fs.existsSync(f))) {
      writeQrImage(url, f, 720);
      this.qrFor = url;
    }
    return url ? f : '';
  }

  /** In one of the hours chosen for the vote (or a round asked for by hand). */
  inHours(at = Date.now()): boolean {
    const v = this.cfg.vote;
    if (!v.enabled || !this.pageUrl()) return false;
    const d = new Date(at);
    return v.hours.some((h) => parseDays(h.days || '*').has(d.getDay()) && parseHours(h.hours || '*').has(d.getHours()));
  }

  /** Start a round now (remote control), even outside the hours. */
  startNow(): boolean {
    if (!this.pageUrl()) return false;
    if (this.round) return true;
    this.waiting = null;
    this.forced = 1;
    this.open();
    return !!this.round;
  }

  /** Close the round on air without a winner. */
  cancel() {
    if (!this.round) return;
    this.note('televoto annullato');
    this.closedRounds.push({ ids: this.round.songs.map((x) => x.id), closedAt: Date.now() });
    this.round = null;
    this.forced = 0;
    this.save();
    this.onChange();
  }

  /** When each song reached its votes (seconds, from the page): on a tie the first one wins. */
  reached: number[] = [];

  setCounts(roundId: string, counts: unknown, reached?: unknown) {
    if (!this.round || roundId !== this.round.id || !Array.isArray(counts)) return;
    this.counts = this.round.songs.map((_, i) => Math.max(0, Math.round(Number(counts[i]) || 0)));
    this.reached = this.round.songs.map((_, i) => (Array.isArray(reached) ? Number(reached[i]) || 0 : 0));
    this.writeCounts();
  }

  private tick() {
    const now = Date.now();
    if (this.round && now >= this.round.closesAt) this.close();
    // A winner that never made it to air (taken out of the queue) stops holding the next round.
    if (this.waiting && now - this.waiting.since > 20 * 60_000) this.waiting = null;
    if (!this.round && !this.waiting && (this.inHours(now) || this.forced > 0)) this.open();
    this.writeCounts();
  }

  /** Songs for a round: rested, not coming up soon, different artists, in random order. */
  private pick(): VoteSong[] {
    const v = this.cfg.vote;
    const now = Date.now();
    const sepMs = this.cfg.rotation.titleSeparationMinutes * 60_000;
    const recent = new Set(this.sched.history.filter((h) => h.at > now - sepMs).map((h) => h.id));
    const soon = new Set(this.sched.playlist.items.filter((it) => it.at < now + 3600_000).map((it) => it.id));
    for (const id of this.sched.queue) soon.add(id);
    // On air, prepared or chosen to follow: it would air while people vote for it.
    for (const c of this.comingUp()) soon.add(c.id);
    const artists = new Set<string>();
    const ids = new Set<string>();
    const take = (cats: string[], n: number, isNew: boolean, tag = ''): VoteSong[] => {
      const pool = (cats.length ? cats : ['music']).flatMap((c) => this.lib.playable(c))
        .filter((c) => c.type === 'music' && !recent.has(c.id) && !soon.has(c.id) && !ids.has(c.id));
      const out: VoteSong[] = [];
      for (const c of shuffle(pool)) {
        if (out.length >= n) break;
        const a = (c.artist || c.title).toLowerCase();
        if (artists.has(a)) continue;
        artists.add(a);
        ids.add(c.id);
        out.push({ n: 0, id: c.id, artist: c.artist, title: c.title, isNew, ...(tag ? { tag: tag.toUpperCase().slice(0, 12) } : {}) });
      }
      return out;
    };
    const groups = (v.groups ?? []).filter((g) => g.count > 0 && g.categories.length);
    if (groups.length) {
      // Each group in turn, up to ten songs in all; a group short of rested songs leaves its places empty.
      const out: VoteSong[] = [];
      for (const g of groups) out.push(...take(g.categories, Math.min(g.count, 10 - out.length), /nuov/i.test(g.tag), g.tag));
      return shuffle(out).map((s, i) => ({ ...s, n: i + 1 }));
    }
    const total = Math.max(2, Math.min(10, v.candidates));
    const fresh = take(v.newCategories, Math.min(v.newCount, total), true);
    const rest = take(v.otherCategories, total - fresh.length, false);
    return shuffle([...fresh, ...rest]).map((s, i) => ({ ...s, n: i + 1 }));
  }

  private open() {
    const songs = this.pick();
    if (songs.length < 2) {
      this.note('televoto: non ci sono abbastanza brani riposati nelle categorie scelte');
      this.forced = 0;
      return;
    }
    if (this.forced > 0) this.forced--;
    const now = Date.now();
    this.round = { id: crypto.randomBytes(6).toString('hex'), songs, openedAt: now, closesAt: now + Math.max(2, this.cfg.vote.roundMinutes) * 60_000 };
    this.counts = songs.map(() => 0);
    this.reached = [];
    this.note(`televoto aperto: ${songs.length} brani, si vota fino alle ${hhmm(this.round.closesAt)}`);
    this.save();
    this.writeCounts();
    this.onChange();
  }

  private close() {
    const r = this.round!;
    this.round = null;
    this.closedRounds.push({ ids: r.songs.map((x) => x.id), closedAt: Date.now() });
    const total = this.counts.reduce((s, n) => s + n, 0);
    if (!total) {
      this.note('televoto chiuso senza voti');
    } else {
      const max = Math.max(...this.counts);
      // A tie goes to the song that got to those votes first; by lot only if that is not known.
      const tied = r.songs.map((sg, i) => ({ sg, at: this.reached[i] || Infinity })).filter((_, i) => this.counts[i] === max);
      const first = Math.min(...tied.map((t) => t.at));
      const firsts = tied.filter((t) => t.at === first);
      const win = firsts[Math.floor(Math.random() * firsts.length)].sg;
      const clip = this.lib.get(win.id);
      if (clip && this.lib.isPlayable(clip)) {
        this.last = { id: win.id, artist: win.artist, title: win.title, votes: max, total, at: Date.now() };
        this.winners.set(win.id, this.last);
        this.sched.enqueue(win.id, true);
        // A winner breaking a sequence rule (two Italian songs in a row) waits one more clip.
        this.sched.deferrable.add(win.id);
        // Now it is known when it airs: after what is already planned.
        this.last.airsAt = hhmm(Math.ceil(this.queueStartsAt() / 60_000) * 60_000);
        this.waiting = { ...this.last, since: Date.now() };
        this.note(`televoto: la più votata è ${win.artist ? `${win.artist} - ` : ''}${win.title} (${Math.round((max * 100) / total)}%, ${max} voti su ${total}), va in onda appena possibile, dopo il brano già preparato`);
      }
    }
    this.save();
    this.onChange();
  }

  /** Songs of the rounds closed in the last hour, kept out of the rotation after being on screen. */
  private closedRounds: { ids: string[]; closedAt: number }[] = [];

  /** Songs the rotation leaves alone: those of the round open, and of the rounds closed in the last hour. */
  held(): Set<string> {
    const out = new Set(this.round?.songs.map((x) => x.id) ?? []);
    this.closedRounds = this.closedRounds.filter((x) => Date.now() - x.closedAt < 60 * 60_000);
    for (const r of this.closedRounds) for (const id of r.ids) out.add(id);
    return out;
  }

  /** For a clip that won a round, once: its share, for the reveal and the lower third. */
  winnerFor(clip: Clip): (VoteResult & { share: number }) | undefined {
    const w = this.winners.get(clip.id);
    if (!w) return undefined;
    this.winners.delete(clip.id);
    // The winner is planned now: the next round can start (its screens come from the song after).
    if (this.waiting?.id === clip.id) this.waiting = null;
    // The share, never the count: a handful of votes must not show.
    return { ...w, share: Math.round((w.votes * 100) / Math.max(1, w.total)) };
  }

  /** Text files with each song's share of the votes, read again by the decoders every second. */
  countsFile(i: number): string {
    return path.join(resolvePath(this.cfg.dataDir), 'tmp', `voto-${i + 1}.txt`);
  }

  private writeCounts() {
    if (!this.round) return;
    const total = this.counts.reduce((s, n) => s + n, 0);
    fs.mkdirSync(path.join(resolvePath(this.cfg.dataDir), 'tmp'), { recursive: true });
    const put = (f: string, text: string) => {
      try {
        if (!fs.existsSync(f) || fs.readFileSync(f, 'utf8') !== text) {
          fs.writeFileSync(f + '.tmp', text);
          fs.renameSync(f + '.tmp', f);
        }
      } catch {
        // read by the decoder at this moment: next time
      }
    };
    this.round.songs.forEach((_, i) => {
      const pct = total ? Math.round(((this.counts[i] ?? 0) * 100) / total) : 0;
      put(this.countsFile(i), `${pct}%`);
      // The bar: as many equal letters as half the share, drawn invisible on a coloured box.
      put(this.barFile(i), 'M'.repeat(Math.round(pct / 2)));
    });
  }

  barFile(i: number): string {
    return path.join(resolvePath(this.cfg.dataDir), 'tmp', `voto-barra-${i + 1}.txt`);
  }

  /**
   * What a segment starting at wall time `startsAt` shows of the round: the songs, the QR, the
   * closing time and when (segment time) the panel slides in, away from the other graphics.
   */
  overlay(startsAt: number, length: number, busy: [number, number, boolean?][]): VoteOverlay | null {
    const r = this.round;
    if (!r) return null;
    const qr = this.qrFile();
    if (!qr) return null;
    const closesIn = (r.closesAt - startsAt) / 1000;
    const until = Math.min(length - 45, closesIn - 5);
    // The vote screen: every so often, moved past the other graphics when they are on.
    const windows: [number, number, boolean?][] = [];
    const len = this.cfg.vote.showSeconds;
    for (let s = 14; s + len <= until; ) {
      const hit = busy.find(([a, b]) => s < b + 1 && s + len > a - 1);
      if (hit) {
        s = hit[1] + 1.5;
        continue;
      }
      windows.push([s, s + len]);
      s += this.cfg.vote.showEverySeconds;
    }
    // The last seconds of the round get a screen of their own, with a big countdown, when the
    // close falls inside this clip and away from a card.
    const fs0 = closesIn - len - 1;
    if (fs0 >= 6 && closesIn <= length - 6 && !busy.some(([a, b, card]) => card && fs0 < b + 1 && closesIn > a - 1)) {
      for (let i = windows.length - 1; i >= 0; i--) if (windows[i][1] > fs0 - 3) windows.splice(i, 1);
      windows.push([fs0, closesIn - 1, true]);
    }
    // The small invitation card: the rest of the time until the close, but not over a card that
    // squeezes the picture, the lower third or the winner's card (the third value of `busy`).
    const end = Math.min(length - 1, closesIn);
    const blocks = [...windows.map(([a, b]): [number, number] => [a - 1, b + 1]), ...busy.filter((b) => b[2]).map(([a, b]): [number, number] => [a - 1, b + 1])].sort((x, y) => x[0] - y[0]);
    const invites: [number, number][] = [];
    let from = 3;
    for (const [a, b] of [...blocks, [end, end] as [number, number]]) {
      if (Math.min(a, end) - from >= 6) invites.push([from, Math.min(a, end)]);
      from = Math.max(from, b);
    }
    if (!windows.length && !invites.length) return null;
    this.writeCountdown();
    return {
      songs: r.songs, qr, closesAt: hhmm(r.closesAt), counts: r.songs.map((_, i) => this.countsFile(i)), bars: r.songs.map((_, i) => this.barFile(i)),
      countdown: this.countdownFile(), closesIn, roundSecs: (r.closesAt - r.openedAt) / 1000, airsAt: this.airsAt(r), windows, invites, url: this.pageUrl(),
    };
  }

  /**
   * About when the winner airs: after the clip on air at the close and the one already prepared
   * after it, so the close plus about one clip, to the next five minutes.
   */
  airsAt(r: VoteRound): string {
    // The clip on air at the close and the one after it play first: about six minutes.
    const t = r.closesAt + 6 * 60_000;
    return hhmm(Math.ceil(t / 300_000) * 300_000);
  }

  /** The line for the ticker while a round is open. */
  tickerLine(): { text: string; sub: string } | null {
    const w = this.waiting;
    if (w) return { text: `Ha vinto il televoto: ${w.artist ? `${w.artist} - ` : ''}${w.title}`, sub: `va in onda ${w.airsAt ? `verso le ${w.airsAt}` : 'tra poco'} · grazie a tutti per aver votato` };
    const r = this.round;
    if (!r) return null;
    // No "scan the QR" here: the QR is not always on screen. Who leads, as a share, never a count.
    const total = this.counts.reduce((a, b) => a + b, 0);
    if (!total) return { text: 'Televoto aperto: vota il brano che vuoi sentire', sub: `si vota fino alle ${hhmm(r.closesAt)} · il più votato va in onda verso le ${this.airsAt(r)}` };
    const max = Math.max(...this.counts);
    const lead = r.songs[this.counts.indexOf(max)];
    return { text: `Per il momento il più votato: ${lead.artist ? `${lead.artist} - ` : ''}${lead.title}`, sub: `${Math.round((max * 100) / total)}% dei voti · si vota fino alle ${hhmm(r.closesAt)}` };
  }

  /** What the vote page shows. */
  publicState() {
    return {
      round: this.round && { id: this.round.id, songs: this.round.songs, openedAt: this.round.openedAt, closesAt: this.round.closesAt, airsAt: this.airsAt(this.round) },
      last: this.last,
    };
  }
}

export interface VoteOverlay { songs: VoteSong[]; qr: string; closesAt: string; counts: string[]; bars?: string[]; countdown?: string; closesIn?: number; roundSecs?: number; airsAt?: string; windows: [number, number, boolean?][]; invites?: [number, number][]; url: string }

function shuffle<T>(a: T[]): T[] {
  const out = [...a];
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}
const hhmm = (t: number) => new Date(t).toTimeString().slice(0, 5);
